(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["default~home-home-module~modal-ms-teams-ms-teams-module"],{

/***/ "4MGu":
/*!*****************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/modal/ms-teams/ms-teams.page.html ***!
  \*****************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\n  <ion-toolbar style=\"padding: 20px\">\n    <ion-buttons slot=\"start\">\n      <ion-button fill=\"clear\" (click)=\"dismiss();\">\n        <ion-icon class=\"white-text\" name=\"chevron-down-outline\"></ion-icon>\n      </ion-button>\n    </ion-buttons>\n    <ion-title>\n      <span *ngIf=\"specificAppData.appName == 'Microsoft Teams'\"\n        ><img\n          style=\"width: 50px; vertical-align: middle\"\n          src=\"assets/images/TEAMS-icon.png\"\n        />{{specificAppData.appName}}</span\n      >\n      <span *ngIf=\"specificAppData.appName == 'Powerpoint'\"\n        ><img\n          style=\"width: 50px; vertical-align: middle\"\n          src=\"assets/images/POWERPOINT-icon.png\"\n        />{{specificAppData.appName}}</span\n      >\n      <span *ngIf=\"specificAppData.appName == 'Netflix'\"\n        ><img\n          style=\"width: 50px; vertical-align: middle\"\n          src=\"assets/images/NETFLIX-icon.png\"\n        />{{specificAppData.appName}}</span\n      >\n    </ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content class=\"no-scroll\">\n  <div *ngIf=\"specificAppData.appName == 'PowerPoint'\">\n    <ion-row class=\"text-center\">\n      <ion-col class=\"touch-icon\">\n        <div class=\"modal-title\">Title</div>\n        <div title=\"modal-sub-title\">Last saved</div>\n      </ion-col>\n    </ion-row>\n    <ion-row class=\"text-center pp-boxes\">\n      <ion-col offset-4>\n        <div (click)=\"ppPlayFromStart();\">Play from start</div>\n      </ion-col>\n      <ion-col offset-4>\n        <div (click)=\"ppPlayFromCurrentSlide();\">Play from current slide</div>\n      </ion-col>\n    </ion-row>\n    <ion-row class=\"text-center pp-boxes\">\n      <ion-col offset-4> <div (click)=\"ppSave();\">Save</div> </ion-col>\n      <ion-col offset-4> <div (click)=\"ppPrint();\">Print</div> </ion-col>\n    </ion-row>\n    <ion-row class=\"text-center pp-boxes\">\n      <ion-col offset-4> <div (click)=\"ppNewSlide();\">New slide</div> </ion-col>\n      <ion-col offset-4>\n        <div (click)=\"ppDuplicateSlide();\">Duplicate slide</div>\n      </ion-col>\n    </ion-row>\n    <ion-row class=\"text-center pp-boxes\">\n      <ion-col offset-4>\n        <div class=\"blank\"><img src=\"assets/images/add-icon.png\" /></div\n      ></ion-col>\n    </ion-row>\n  </div>\n  <div *ngIf=\"specificAppData.appName == 'Microsoft Teams'\">\n    <div class=\"row\">\n      <div class=\"col-md-12 text-center\">\n        <p>Team Catchup</p>\n        <p>02:41</p>\n      </div>\n    </div>\n    <ion-row class=\"text-center\">\n      <ion-col offset-4>\n        <div>\n          <img\n            class=\"touch-icon\"\n            *ngIf=\"hand == false\"\n            src=\"assets/images/microsoft-teams/raise-hand.png\"\n            (click)=\"switchHand();\"\n          />\n          <img\n            class=\"touch-icon\"\n            *ngIf=\"hand == true\"\n            src=\"assets/images/microsoft-teams/raise-hand-on.png\"\n            (click)=\"switchHand();\"\n          />\n          <p *ngIf=\"hand == false\">Raise Hand</p>\n          <p *ngIf=\"hand == true\">Lower Hand</p>\n        </div>\n      </ion-col>\n      <ion-col>\n        <div>\n          <img\n            class=\"touch-icon\"\n            src=\"assets/images/microsoft-teams/leave-meeting.png\"\n            (click)=\"leaveMeeting();\"\n          />\n          <p>Leave Meeting</p>\n        </div>\n      </ion-col>\n    </ion-row>\n    <ion-row class=\"text-center\">\n      <ion-col offset-4>\n        <div>\n          <img\n            class=\"touch-icon\"\n            *ngIf=\"mic == false\"\n            src=\"assets/images/microsoft-teams/mute-mic.png\"\n            (click)=\"switchMic();\"\n          />\n          <img\n            class=\"touch-icon\"\n            *ngIf=\"mic == true\"\n            src=\"assets/images/microsoft-teams/unmute-mic.png\"\n            (click)=\"switchMic();\"\n          />\n          <p *ngIf=\"mic == true\">Unmute Mic</p>\n          <p *ngIf=\"mic == false\">Mute Mic</p>\n        </div>\n      </ion-col>\n      <ion-col>\n        <div>\n          <img\n            class=\"touch-icon\"\n            *ngIf=\"camera == false\"\n            src=\"assets/images/microsoft-teams/camera-off.png\"\n            (click)=\"switchCamera();\"\n          />\n          <img\n            class=\"touch-icon\"\n            *ngIf=\"camera == true\"\n            src=\"assets/images/microsoft-teams/camera-on.png\"\n            (click)=\"switchCamera();\"\n          />\n          <p *ngIf=\"camera == false\">Turn Camera Off</p>\n          <p *ngIf=\"camera == true\">Turn Camera On</p>\n        </div>\n      </ion-col>\n    </ion-row>\n    <ion-row>\n      <ion-col>\n        <ion-item>\n          <ion-range value=\"20\">\n            <ion-icon\n              slot=\"start\"\n              size=\"small\"\n              name=\"volume-low-outline\"\n            ></ion-icon>\n\n            <ion-icon slot=\"end\" name=\"volume-high-outline\"></ion-icon>\n          </ion-range>\n        </ion-item>\n      </ion-col>\n    </ion-row>\n  </div>\n  <div *ngIf=\"specificAppData.appName == 'Netflix'\">\n    <ion-row class=\"text-center\">\n      <ion-col>\n        <div class=\"modal-title\">Title</div>\n        <div title=\"modal-sub-title\">Sub title</div>\n      </ion-col>\n    </ion-row>\n    <ion-row class=\"text-center\">\n      <ion-col>\n        <div class=\"netflix-poster\">\n          <img src=\"assets/images/NETFLIX.jpg\" />\n        </div>\n      </ion-col>\n    </ion-row>\n    <ion-row class=\"text-center\">\n      <ion-col offset-4>\n        <div (click)=\"netflixRewind();\">\n          <img src=\"assets/images/rewind-30-icon.png\" />\n        </div>\n      </ion-col>\n      <ion-col offset-4>\n        <div (click)=\"netflixPause();\">\n          <img width=\"30px\" src=\"assets/images/pause.png\" />\n        </div>\n      </ion-col>\n      <ion-col offset-4>\n        <div (click)=\"netflixStop();\"><img src=\"assets/images/stop.png\" /></div>\n      </ion-col>\n    </ion-row>\n  </div>\n  <!-- <div *ngIf=\"app[1].id == 'SPOTIFY'\">\n    <div class=\"row\">\n      <div class=\"col-md-12 text-center\">\n        <p>[Title]</p>\n        <p>[Artist]</p>\n      </div>\n    </div>\n    <div style=\"text-align: center\">\n      <img width=\"160\" src=\"assets/images/spotify-playing.jpg\" />\n    </div>\n    <ion-row class=\"text-center\">\n      <ion-col offset-4>\n        <div>\n          <img\n            style=\"width: 50px; height: 50px\"\n            src=\"assets/images/rewind.png\"\n            (click)=\"switchHand();\"\n          />\n        </div>\n      </ion-col>\n      <ion-col offset-4>\n        <div>\n          <img\n            style=\"width: 40px; height: 50px\"\n            class=\"touch-icon\"\n            src=\"assets/images/pause.png\"\n            (click)=\"switchHand();\"\n          />\n        </div>\n      </ion-col>\n      <ion-col offset-4>\n        <div>\n          <img\n            style=\"width: 50px; height: 50px\"\n            class=\"touch-icon\"\n            src=\"assets/images/forward.png\"\n            (click)=\"switchHand();\"\n          />\n        </div>\n      </ion-col>\n    </ion-row>\n\n    <ion-row>\n      <ion-col>\n        <ion-item>\n          <ion-range value=\"20\">\n            <ion-icon\n              slot=\"start\"\n              size=\"small\"\n              name=\"volume-low-outline\"\n            ></ion-icon>\n\n            <ion-icon slot=\"end\" name=\"volume-high-outline\"></ion-icon>\n          </ion-range>\n        </ion-item>\n      </ion-col>\n    </ion-row>\n  </div>\n  <div *ngIf=\"app[1].id == 'SPOTIFY'\">\n    <div class=\"row\">\n      <div class=\"col-md-12 text-center\">\n        <p>[Title]</p>\n        <p>[Artist]</p>\n      </div>\n    </div>\n    <div style=\"text-align: center\">\n      <img width=\"160\" src=\"assets/images/spotify-playing.jpg\" />\n    </div>\n    <ion-row class=\"text-center\">\n      <ion-col offset-4>\n        <div>\n          <img\n            style=\"width: 50px; height: 50px\"\n            src=\"assets/images/rewind.png\"\n            (click)=\"switchHand();\"\n          />\n        </div>\n      </ion-col>\n      <ion-col offset-4>\n        <div>\n          <img\n            style=\"width: 40px; height: 50px\"\n            class=\"touch-icon\"\n            src=\"assets/images/pause.png\"\n            (click)=\"switchHand();\"\n          />\n        </div>\n      </ion-col>\n      <ion-col offset-4>\n        <div>\n          <img\n            style=\"width: 50px; height: 50px\"\n            class=\"touch-icon\"\n            src=\"assets/images/forward.png\"\n            (click)=\"switchHand();\"\n          />\n        </div>\n      </ion-col>\n    </ion-row>\n\n    <ion-row>\n      <ion-col>\n        <ion-item>\n          <ion-range value=\"20\">\n            <ion-icon\n              slot=\"start\"\n              size=\"small\"\n              name=\"volume-low-outline\"\n            ></ion-icon>\n\n            <ion-icon slot=\"end\" name=\"volume-high-outline\"></ion-icon>\n          </ion-range>\n        </ion-item>\n      </ion-col>\n    </ion-row>\n  </div> -->\n</ion-content>\n");

/***/ }),

/***/ "H+bZ":
/*!*****************************************!*\
  !*** ./src/app/services/api.service.ts ***!
  \*****************************************/
/*! exports provided: ApiService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ApiService", function() { return ApiService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common/http */ "tk/3");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs/operators */ "kU1M");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rxjs */ "qCKp");





let ApiService = class ApiService {
    constructor(httpClient) {
        this.httpClient = httpClient;
        this.REST_API_IP = "207.180.244.152";
        this.REST_API_SERVER = "http://" + this.REST_API_IP + ":5000/api/system";
        this.headers = new _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpHeaders"]({ 'Content-Type': 'application/json; charset=utf-8' });
    }
    getAppsRunning() {
        return this.httpClient.get(this.REST_API_SERVER + "/apps/running/");
    }
    getSnapshot(id) {
        return this.httpClient.get(this.REST_API_SERVER + "/apps/running/" + id + "/screen", { observe: 'response' }).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["map"])((result) => {
            console.log(result);
            // return result;
        }));
        return this.httpClient.get(this.REST_API_SERVER + "/apps/running/" + id + "/screen");
    }
    getSpecificAppDetail(app) {
        console.log(app.appID);
        return this.httpClient.get(this.REST_API_SERVER + "/apps/running/" + app.appID + "?windowId=0");
    }
    executeCommand(data) {
        //var theURL = "http://207.180.244.152:5000/api/System/application/2944/shortcuts?windowId=4589428&commandName=Raise"
        var theURL = this.REST_API_SERVER + "/application/" + data.appID + "/shortcuts?windowId=" + data.windowsID + "&commandName=" + data.appCommand;
        return Object(rxjs__WEBPACK_IMPORTED_MODULE_4__["from"])(fetch(theURL, // the url you are trying to access
        {
            headers: {
                'Content-Type': 'application/json',
            },
            method: 'POST',
            mode: 'no-cors' // the most important option
        }));
        // const httpOptions = {
        //   headers: new HttpHeaders({
        //     'Content-Type': 'application/json',
        //     Authorization: 'my-auth-token'
        //   })
        // };
        // console.log(data)
        // var theURL = "/application/" + data.appID + "/shortcuts?windowId=" + data.windowsID + "&commandName=Raise"
        // return this.httpClient.post<any>(this.REST_API_SERVER + theURL, data, httpOptions);
    }
};
ApiService.ctorParameters = () => [
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"] }
];
ApiService = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
        providedIn: 'root'
    })
], ApiService);



/***/ }),

/***/ "jiDk":
/*!***************************************************!*\
  !*** ./src/app/modal/ms-teams/ms-teams.page.scss ***!
  \***************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".text-center {\n  text-align: center;\n  margin: 0 auto;\n}\n\nion-range {\n  --bar-background: transparent;\n  --background: transparent;\n  --background-activated: transparent;\n  --background-focused: transparent;\n  --background-hover: transparent;\n  --background-activated-opacity: 0.12;\n  --background-focused-opacity: 0.15;\n  --background-hover-opacity: 0.04;\n}\n\nion-toolbar {\n  --background: transparent !important;\n  --border-color: transparent;\n  height: 90px;\n}\n\n.white-text {\n  color: white;\n}\n\n.netflix-poster img {\n  width: 70%;\n}\n\n.pp-boxes div {\n  margin: 10px;\n  background: #327eb3;\n  padding: 20px;\n  height: 80px;\n  border-radius: 10px;\n}\n\n.pp-boxes div.blank {\n  background: transparent;\n}\n\n.toolbar-background {\n  border: 0 !important;\n}\n\n.touch-icon {\n  width: 100px;\n}\n\n.custom-toolbar {\n  background: black;\n  padding: 20px;\n}\n\n.custom-toolbar .toolbar-container {\n  padding: 50px !important;\n}\n\n.sc-ion-modal-ios-h {\n  height: 90% !important;\n  bottom: 0;\n  width: 100%;\n  margin: 0 auto;\n  border-radius: 30px;\n  margin-top: 60px;\n}\n\nion-item::part(native) {\n  background-color: transparent;\n  padding: 0;\n}\n\nion-item::part(native) .item-inner {\n  padding: 0;\n  border: 0;\n}\n\nmain::part(scroll) {\n  overflow: hidden i !important;\n}\n\n:root ion-range {\n  --bar-background: transparent;\n  --background: transparent;\n  --background-activated: transparent;\n  --background-focused: transparent;\n  --background-hover: transparent;\n  --background-activated-opacity: 0.12;\n  --background-focused-opacity: 0.15;\n  --background-hover-opacity: 0.04;\n}\n\n:root ion-toolbar ion-title {\n  padding: 0;\n}\n\n:root ion-toolbar .toolbar-container {\n  padding: 50px;\n}\n\n:root ion-toolbar:last-child .toolbar-background {\n  box-shadow: var(--box-shadow);\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uL21zLXRlYW1zLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNJLGtCQUFBO0VBQ0EsY0FBQTtBQUNKOztBQUNBO0VBQ0ksNkJBQUE7RUFFQSx5QkFBQTtFQUNBLG1DQUFBO0VBQ0EsaUNBQUE7RUFDQSwrQkFBQTtFQUNBLG9DQUFBO0VBQ0Esa0NBQUE7RUFDQSxnQ0FBQTtBQUNKOztBQUNBO0VBQ0ksb0NBQUE7RUFDQSwyQkFBQTtFQUNBLFlBQUE7QUFFSjs7QUFBQTtFQUNJLFlBQUE7QUFHSjs7QUFBSTtFQUNJLFVBQUE7QUFHUjs7QUFDSTtFQUNJLFlBQUE7RUFDQSxtQkFBQTtFQUNBLGFBQUE7RUFDQSxZQUFBO0VBQ0EsbUJBQUE7QUFFUjs7QUFEUTtFQUNJLHVCQUFBO0FBR1o7O0FBQ0E7RUFDSSxvQkFBQTtBQUVKOztBQUFBO0VBQ0ksWUFBQTtBQUdKOztBQURBO0VBQ0ksaUJBQUE7RUFDQSxhQUFBO0FBSUo7O0FBSEk7RUFDSSx3QkFBQTtBQUtSOztBQUZBO0VBQ0ksc0JBQUE7RUFDQSxTQUFBO0VBQ0EsV0FBQTtFQUNBLGNBQUE7RUFDQSxtQkFBQTtFQUNBLGdCQUFBO0FBS0o7O0FBSEE7RUFLSSw2QkFBQTtFQUNBLFVBQUE7QUFFSjs7QUFQSTtFQUNJLFVBQUE7RUFDQSxTQUFBO0FBU1I7O0FBSkE7RUFDSSw2QkFBQTtBQU9KOztBQUpJO0VBQ0ksNkJBQUE7RUFFQSx5QkFBQTtFQUNBLG1DQUFBO0VBQ0EsaUNBQUE7RUFDQSwrQkFBQTtFQUNBLG9DQUFBO0VBQ0Esa0NBQUE7RUFDQSxnQ0FBQTtBQU1SOztBQUhRO0VBQ0ksVUFBQTtBQUtaOztBQUhRO0VBQ0ksYUFBQTtBQUtaOztBQUZZO0VBQ0ksNkJBQUE7QUFJaEIiLCJmaWxlIjoibXMtdGVhbXMucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLnRleHQtY2VudGVyIHtcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gICAgbWFyZ2luOiAwIGF1dG87XG59XG5pb24tcmFuZ2Uge1xuICAgIC0tYmFyLWJhY2tncm91bmQ6IHRyYW5zcGFyZW50O1xuXG4gICAgLS1iYWNrZ3JvdW5kOiB0cmFuc3BhcmVudDtcbiAgICAtLWJhY2tncm91bmQtYWN0aXZhdGVkOiB0cmFuc3BhcmVudDtcbiAgICAtLWJhY2tncm91bmQtZm9jdXNlZDogdHJhbnNwYXJlbnQ7XG4gICAgLS1iYWNrZ3JvdW5kLWhvdmVyOiB0cmFuc3BhcmVudDtcbiAgICAtLWJhY2tncm91bmQtYWN0aXZhdGVkLW9wYWNpdHk6IDAuMTI7XG4gICAgLS1iYWNrZ3JvdW5kLWZvY3VzZWQtb3BhY2l0eTogMC4xNTtcbiAgICAtLWJhY2tncm91bmQtaG92ZXItb3BhY2l0eTogMC4wNDtcbn1cbmlvbi10b29sYmFyIHtcbiAgICAtLWJhY2tncm91bmQ6IHRyYW5zcGFyZW50ICFpbXBvcnRhbnQ7XG4gICAgLS1ib3JkZXItY29sb3I6IHRyYW5zcGFyZW50O1xuICAgIGhlaWdodDogOTBweDtcbn1cbi53aGl0ZS10ZXh0IHtcbiAgICBjb2xvcjogd2hpdGU7XG59XG4ubmV0ZmxpeC1wb3N0ZXIge1xuICAgIGltZyB7XG4gICAgICAgIHdpZHRoOiA3MCU7XG4gICAgfVxufVxuLnBwLWJveGVzIHtcbiAgICBkaXYge1xuICAgICAgICBtYXJnaW46IDEwcHg7XG4gICAgICAgIGJhY2tncm91bmQ6IHJnYig1MCwgMTI2LCAxNzkpO1xuICAgICAgICBwYWRkaW5nOiAyMHB4O1xuICAgICAgICBoZWlnaHQ6IDgwcHg7XG4gICAgICAgIGJvcmRlci1yYWRpdXM6IDEwcHg7XG4gICAgICAgICYuYmxhbmsge1xuICAgICAgICAgICAgYmFja2dyb3VuZDogdHJhbnNwYXJlbnQ7XG4gICAgICAgIH1cbiAgICB9XG59XG4udG9vbGJhci1iYWNrZ3JvdW5kIHtcbiAgICBib3JkZXI6IDAgIWltcG9ydGFudDtcbn1cbi50b3VjaC1pY29uIHtcbiAgICB3aWR0aDogMTAwcHg7XG59XG4uY3VzdG9tLXRvb2xiYXIge1xuICAgIGJhY2tncm91bmQ6IGJsYWNrO1xuICAgIHBhZGRpbmc6IDIwcHg7XG4gICAgLnRvb2xiYXItY29udGFpbmVyIHtcbiAgICAgICAgcGFkZGluZzogNTBweCAhaW1wb3J0YW50O1xuICAgIH1cbn1cbi5zYy1pb24tbW9kYWwtaW9zLWgge1xuICAgIGhlaWdodDogOTAlICFpbXBvcnRhbnQ7XG4gICAgYm90dG9tOiAwO1xuICAgIHdpZHRoOiAxMDAlO1xuICAgIG1hcmdpbjogMCBhdXRvO1xuICAgIGJvcmRlci1yYWRpdXM6IDMwcHg7XG4gICAgbWFyZ2luLXRvcDogNjBweDtcbn1cbmlvbi1pdGVtOjpwYXJ0KG5hdGl2ZSkge1xuICAgIC5pdGVtLWlubmVyIHtcbiAgICAgICAgcGFkZGluZzogMDtcbiAgICAgICAgYm9yZGVyOiAwO1xuICAgIH1cbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiB0cmFuc3BhcmVudDtcbiAgICBwYWRkaW5nOiAwO1xufVxubWFpbjo6cGFydChzY3JvbGwpIHtcbiAgICBvdmVyZmxvdzogaGlkZGVuIGkgIWltcG9ydGFudDtcbn1cbjpyb290IHtcbiAgICBpb24tcmFuZ2Uge1xuICAgICAgICAtLWJhci1iYWNrZ3JvdW5kOiB0cmFuc3BhcmVudDtcblxuICAgICAgICAtLWJhY2tncm91bmQ6IHRyYW5zcGFyZW50O1xuICAgICAgICAtLWJhY2tncm91bmQtYWN0aXZhdGVkOiB0cmFuc3BhcmVudDtcbiAgICAgICAgLS1iYWNrZ3JvdW5kLWZvY3VzZWQ6IHRyYW5zcGFyZW50O1xuICAgICAgICAtLWJhY2tncm91bmQtaG92ZXI6IHRyYW5zcGFyZW50O1xuICAgICAgICAtLWJhY2tncm91bmQtYWN0aXZhdGVkLW9wYWNpdHk6IDAuMTI7XG4gICAgICAgIC0tYmFja2dyb3VuZC1mb2N1c2VkLW9wYWNpdHk6IDAuMTU7XG4gICAgICAgIC0tYmFja2dyb3VuZC1ob3Zlci1vcGFjaXR5OiAwLjA0O1xuICAgIH1cbiAgICBpb24tdG9vbGJhciB7XG4gICAgICAgIGlvbi10aXRsZSB7XG4gICAgICAgICAgICBwYWRkaW5nOiAwO1xuICAgICAgICB9XG4gICAgICAgIC50b29sYmFyLWNvbnRhaW5lciB7XG4gICAgICAgICAgICBwYWRkaW5nOiA1MHB4O1xuICAgICAgICB9XG4gICAgICAgICY6bGFzdC1jaGlsZCB7XG4gICAgICAgICAgICAudG9vbGJhci1iYWNrZ3JvdW5kIHtcbiAgICAgICAgICAgICAgICBib3gtc2hhZG93OiB2YXIoLS1ib3gtc2hhZG93KTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgIH1cbn1cbiJdfQ== */");

/***/ }),

/***/ "oz6t":
/*!*************************************************!*\
  !*** ./src/app/modal/ms-teams/ms-teams.page.ts ***!
  \*************************************************/
/*! exports provided: MsTeamsPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MsTeamsPage", function() { return MsTeamsPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_ms_teams_page_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./ms-teams.page.html */ "4MGu");
/* harmony import */ var _ms_teams_page_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./ms-teams.page.scss */ "jiDk");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/common/http */ "tk/3");
/* harmony import */ var _services_api_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../services/api.service */ "H+bZ");







let MsTeamsPage = class MsTeamsPage {
    constructor(modalController, httpClient, apiService) {
        this.modalController = modalController;
        this.httpClient = httpClient;
        this.apiService = apiService;
        this.mic = false;
        this.camera = false;
        this.hand = false;
        this.commandData = {
            appId: '',
            windowId: '',
            command: ''
        };
        this.commandDataSend = {};
        this.specificAppData = {};
    }
    dismiss() {
        this.modalController.dismiss({
            'dismissed': true
        });
    }
    getSpecificApp(app) {
        console.log(app);
        this.apiService.getSpecificAppDetail(app).subscribe((data) => {
            console.log(data);
            this.specificAppData = data;
        });
    }
    doExecuteCommand(params) {
        this.apiService.executeCommand(params).subscribe((data) => {
            console.log(data);
        });
    }
    //Teams
    leaveMeeting() {
        var myOpt = JSON.parse(localStorage.getItem('currentAppID'));
        this.commandDataSend = {
            appId: this.commandData.appId,
            windowId: this.commandData.windowId,
            command: "Leave"
        };
        myOpt.appCommand = "Leave";
        console.log(myOpt);
        this.doExecuteCommand(myOpt);
    }
    switchMic() {
        var myOpt = JSON.parse(localStorage.getItem('currentAppID'));
        console.log(this.mic);
        this.mic = !this.mic;
        this.commandDataSend = {
            appId: this.commandData.appId,
            windowId: this.commandData.windowId,
            command: "Mute Unmute mic"
        };
        myOpt.appCommand = "Mute Unmute mic";
        console.log(myOpt);
        this.doExecuteCommand(myOpt);
    }
    switchCamera() {
        var myOpt = JSON.parse(localStorage.getItem('currentAppID'));
        console.log(this.camera);
        this.camera = !this.camera;
        this.commandDataSend = {
            appId: this.commandData.appId,
            windowId: this.commandData.windowId,
            command: "Camera"
        };
        myOpt.appCommand = "Camera";
        console.log(myOpt);
        this.doExecuteCommand(myOpt);
    }
    switchHand() {
        var myOpt = JSON.parse(localStorage.getItem('currentAppID'));
        this.hand = !this.hand;
        this.commandDataSend = {
            appId: this.commandData.appId,
            windowId: this.commandData.windowId,
            command: "Raise"
        };
        myOpt.appCommand = "Raise";
        console.log(myOpt);
        this.doExecuteCommand(myOpt);
    }
    //Powerpoint
    ppPlayFromStart() {
        var myOpt = JSON.parse(localStorage.getItem('currentAppID'));
        this.hand = !this.hand;
        this.commandDataSend = {
            appId: this.commandData.appId,
            windowId: this.commandData.windowId,
            command: "PlayFromStart"
        };
        myOpt.appCommand = "PlayFromStart";
        console.log(myOpt);
        this.doExecuteCommand(myOpt);
    }
    ppPlayFromCurrentSlide() {
        var myOpt = JSON.parse(localStorage.getItem('currentAppID'));
        this.hand = !this.hand;
        this.commandDataSend = {
            appId: this.commandData.appId,
            windowId: this.commandData.windowId,
            command: "PlayFromCurrentSlide"
        };
        myOpt.appCommand = "PlayFromCurrentSlide";
        console.log(myOpt);
        this.doExecuteCommand(myOpt);
    }
    ppPrint() {
        var myOpt = JSON.parse(localStorage.getItem('currentAppID'));
        this.hand = !this.hand;
        this.commandDataSend = {
            appId: this.commandData.appId,
            windowId: this.commandData.windowId,
            command: "Print"
        };
        myOpt.appCommand = "Print";
        console.log(myOpt);
        this.doExecuteCommand(myOpt);
    }
    ppSave() {
        var myOpt = JSON.parse(localStorage.getItem('currentAppID'));
        this.hand = !this.hand;
        this.commandDataSend = {
            appId: this.commandData.appId,
            windowId: this.commandData.windowId,
            command: "Save"
        };
        myOpt.appCommand = "Save";
        console.log(myOpt);
        this.doExecuteCommand(myOpt);
    }
    ppNewSlide() {
        var myOpt = JSON.parse(localStorage.getItem('currentAppID'));
        this.hand = !this.hand;
        this.commandDataSend = {
            appId: this.commandData.appId,
            windowId: this.commandData.windowId,
            command: "NewSlide"
        };
        myOpt.appCommand = "NewSlide";
        console.log(myOpt);
        this.doExecuteCommand(myOpt);
    }
    ppDuplicateSlide() {
        var myOpt = JSON.parse(localStorage.getItem('currentAppID'));
        this.hand = !this.hand;
        this.commandDataSend = {
            appId: this.commandData.appId,
            windowId: this.commandData.windowId,
            command: "DuplicateSlide"
        };
        myOpt.appCommand = "DuplicateSlide";
        console.log(myOpt);
        this.doExecuteCommand(myOpt);
    }
    //Netflix
    netflixRewind() {
        var myOpt = JSON.parse(localStorage.getItem('currentAppID'));
        this.hand = !this.hand;
        this.commandDataSend = {
            appId: this.commandData.appId,
            windowId: this.commandData.windowId,
            command: "Rewind10"
        };
        myOpt.appCommand = "Rewind10";
        console.log(myOpt);
        this.doExecuteCommand(myOpt);
    }
    netflixPause() {
        var myOpt = JSON.parse(localStorage.getItem('currentAppID'));
        this.hand = !this.hand;
        this.commandDataSend = {
            appId: this.commandData.appId,
            windowId: this.commandData.windowId,
            command: "PlayPause"
        };
        myOpt.appCommand = "PlayPause";
        console.log(myOpt);
        this.doExecuteCommand(myOpt);
    }
    netflixStop() {
        var myOpt = JSON.parse(localStorage.getItem('currentAppID'));
        this.hand = !this.hand;
        this.commandDataSend = {
            appId: this.commandData.appId,
            windowId: this.commandData.windowId,
            command: "Stop"
        };
        myOpt.appCommand = "Stop";
        console.log(myOpt);
        this.doExecuteCommand(myOpt);
    }
    ngOnInit() {
        this.commandData = JSON.parse(localStorage.getItem('currentAppID'));
        console.log(JSON.parse(localStorage.getItem('currentAppID')));
        this.getSpecificApp(this.commandData);
    }
};
MsTeamsPage.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["ModalController"] },
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_5__["HttpClient"] },
    { type: _services_api_service__WEBPACK_IMPORTED_MODULE_6__["ApiService"] }
];
MsTeamsPage.propDecorators = {
    app: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["Input"] }]
};
MsTeamsPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-ms-teams',
        template: _raw_loader_ms_teams_page_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_ms_teams_page_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], MsTeamsPage);



/***/ })

}]);
//# sourceMappingURL=default~home-home-module~modal-ms-teams-ms-teams-module.js.map
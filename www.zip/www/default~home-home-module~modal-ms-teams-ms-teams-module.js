(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["default~home-home-module~modal-ms-teams-ms-teams-module"],{

/***/ "4MGu":
/*!*****************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/modal/ms-teams/ms-teams.page.html ***!
  \*****************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\n  <ion-toolbar style=\"padding: 20px\">\n    <ion-buttons slot=\"start\">\n      <ion-button fill=\"clear\" (click)=\"dismiss();\">\n        <ion-icon class=\"white-text\" name=\"chevron-down-outline\"></ion-icon>\n      </ion-button>\n    </ion-buttons>\n    <ion-title class=\"text-center\">\n      <span *ngIf=\"specificAppData.appName == 'Microsoft Teams'\"\n        ><img\n          style=\"width: 50px; vertical-align: middle\"\n          src=\"assets/images/TEAMS-icon.png\"\n        />{{specificAppData.appName}}</span\n      >\n      <span *ngIf=\"specificAppData.appName == 'PowerPoint'\"\n        ><img\n          style=\"width: 50px; vertical-align: middle\"\n          src=\"assets/images/POWERPOINT-icon.png\"\n        />{{specificAppData.appName}}</span\n      >\n      <span *ngIf=\"specificAppData.appName == 'Netflix'\"\n        ><img\n          style=\"width: 50px; vertical-align: middle\"\n          src=\"assets/images/NETFLIX-icon.png\"\n        />{{specificAppData.appName}}</span\n      >\n      <span *ngIf=\"specificAppData.appName == 'Spotify'\"\n        ><img\n          style=\"width: 50px; vertical-align: middle\"\n          src=\"assets/images/SPOTIFY-icon.png\"\n        />{{specificAppData.appName}}</span\n      >\n    </ion-title>\n    <ion-buttons slot=\"end\">\n      <ion-button fill=\"clear\" (click)=\"dismiss();\"> </ion-button>\n    </ion-buttons>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content class=\"no-scroll\">\n  <div *ngIf=\"specificAppData.appName == 'PowerPoint'\">\n    <ion-row class=\"text-center m-t-20\">\n      <ion-col class=\"touch-icon\">\n        <div class=\"modal-title\">Title</div>\n        <div class=\"modal-sub-title\">Last saved</div>\n      </ion-col>\n    </ion-row>\n    <ion-row class=\"text-center pp-boxes m-t-20\">\n      <ion-col offset-4>\n        <div (click)=\"ppPlayFromStart();\"><p>Play from start</p></div>\n      </ion-col>\n      <ion-col offset-4>\n        <div (click)=\"ppPlayFromCurrentSlide();\">\n          <p>Play from current slide</p>\n        </div>\n      </ion-col>\n    </ion-row>\n    <ion-row class=\"text-center pp-boxes\">\n      <ion-col offset-4>\n        <div (click)=\"ppSave();\"><p>Save</p></div>\n      </ion-col>\n      <ion-col offset-4>\n        <div (click)=\"ppPrint();\"><p>Print</p></div>\n      </ion-col>\n    </ion-row>\n    <ion-row class=\"text-center pp-boxes\">\n      <ion-col offset-4>\n        <div (click)=\"ppNewSlide();\"><p>dNew slide</p></div>\n      </ion-col>\n      <ion-col offset-4>\n        <div (click)=\"ppDuplicateSlide();\"><p>Duplicate slide</p></div>\n      </ion-col>\n    </ion-row>\n    <ion-row class=\"text-center pp-boxes\">\n      <ion-col offset-4>\n        <div class=\"blank\"><img src=\"assets/images/add-icon.png\" /></div\n      ></ion-col>\n    </ion-row>\n  </div>\n  <div *ngIf=\"specificAppData.appName == 'Microsoft Teams'\">\n    <ion-row class=\"m-t-10\">\n      <ion-col size=\"12\" class=\"text-center\">\n        <p class=\"m-b-20 p-l-0 p-r-0 p-t-0 p-b-0 text-bold\">\n          {{specificAppData.title}}\n        </p>\n        <!-- <p>02:41</p> -->\n      </ion-col>\n    </ion-row>\n    <ion-row class=\"text-center m-t-30\">\n      <ion-col size=\"2\"> </ion-col>\n      <ion-col size=\"4\">\n        <img\n          class=\"touch-icon\"\n          *ngIf=\"hand == 'false'\"\n          src=\"assets/images/microsoft-teams/raise-hand.png\"\n          (click)=\"switchHand();\"\n        />\n        <img\n          class=\"touch-icon\"\n          *ngIf=\"hand == 'true'\"\n          src=\"assets/images/microsoft-teams/raise-hand-on.png\"\n          (click)=\"switchHand();\"\n        />\n        <p *ngIf=\"hand == 'false'\">Raise Hand</p>\n        <p *ngIf=\"hand == 'true'\">Lower Hand</p>\n      </ion-col>\n      <ion-col size=\"4\">\n        <img\n          class=\"touch-icon\"\n          src=\"assets/images/microsoft-teams/leave-meeting.png\"\n          (click)=\"leaveMeeting();\"\n        />\n        <p>Leave Meeting</p>\n      </ion-col>\n      <ion-col size=\"2\"> </ion-col>\n    </ion-row>\n    <ion-row class=\"text-center\">\n      <ion-col size=\"2\"> </ion-col>\n      <ion-col size=\"4\">\n        <img\n          class=\"touch-icon\"\n          *ngIf=\"mic == 'false'\"\n          src=\"assets/images/microsoft-teams/mute-mic.png\"\n          (click)=\"switchMic();\"\n        />\n        <img\n          class=\"touch-icon\"\n          *ngIf=\"mic == 'true'\"\n          src=\"assets/images/microsoft-teams/unmute-mic.png\"\n          (click)=\"switchMic();\"\n        />\n        <p *ngIf=\"mic == 'true'\">Unmute Mic</p>\n        <p *ngIf=\"mic == 'false'\">Mute Mic</p>\n      </ion-col>\n      <ion-col size=\"4\">\n        <img\n          class=\"touch-icon\"\n          *ngIf=\"camera == 'true'\"\n          src=\"assets/images/microsoft-teams/camera-on.png\"\n          (click)=\"switchCamera();\"\n        />\n        <img\n          class=\"touch-icon\"\n          *ngIf=\"camera == 'false'\"\n          src=\"assets/images/microsoft-teams/camera-off.png\"\n          (click)=\"switchCamera();\"\n        />\n        <p *ngIf=\"camera == 'true'\">Turn Camera Off</p>\n        <p *ngIf=\"camera == 'false'\">Turn Camera On</p>\n      </ion-col>\n      <ion-col size=\"2\"></ion-col>\n    </ion-row>\n    <ion-row class=\"m-t-20\">\n      <ion-col size=\"1\"></ion-col>\n      <ion-col size=\"10\" class=\"\">\n        <ion-item>\n          <ion-range value=\"20\">\n            <ion-icon\n              slot=\"start\"\n              size=\"medium\"\n              name=\"volume-low-outline\"\n            ></ion-icon>\n\n            <ion-icon slot=\"end\" name=\"volume-high-outline\"></ion-icon>\n          </ion-range>\n        </ion-item>\n      </ion-col>\n      <ion-col size=\"1\"></ion-col>\n    </ion-row>\n  </div>\n  <div *ngIf=\"specificAppData.appName == 'Netflix'\" class=\"modal-control-icons\">\n    <ion-row class=\"text-center\">\n      <ion-col>\n        <div class=\"modal-title\">Title</div>\n      </ion-col>\n    </ion-row>\n    <ion-row class=\"text-center\">\n      <ion-col>\n        <div class=\"netflix-poster\">\n          <img src=\"assets/images/NETFLIX.jpg\" />\n        </div>\n      </ion-col>\n    </ion-row>\n    <ion-row class=\"text-center m-t-30\">\n      <ion-col size=\"4\" class=\"text-right\">\n        <ion-icon\n          class=\"control-icon\"\n          (click)=\"netflixRewind();\"\n          name=\"play-back-circle-outline\"\n        ></ion-icon>\n      </ion-col>\n      <ion-col size=\"4\">\n        <ion-icon\n          class=\"control-icon\"\n          *ngIf=\"netflixPlay == 'true'\"\n          (click)=\"netflixPause();\"\n          name=\"pause\"\n        ></ion-icon>\n        <ion-icon\n          class=\"control-icon\"\n          *ngIf=\"netflixPlay == 'false'\"\n          (click)=\"netflixPause();\"\n          name=\"play\"\n        ></ion-icon>\n      </ion-col>\n      <ion-col size=\"4\" class=\"text-left\">\n        <ion-icon\n          class=\"control-icon\"\n          (click)=\"netflixStop();\"\n          name=\"stop-outline\"\n        ></ion-icon>\n      </ion-col>\n    </ion-row>\n  </div>\n  <div *ngIf=\"specificAppData.appName == 'Spotify'\">\n    <ion-row class=\"text-center\">\n      <ion-col>\n        <div class=\"modal-title\">Title</div>\n        <div class=\"modal-sub-title\">Sub title</div>\n      </ion-col>\n    </ion-row>\n    <ion-row class=\"text-center\">\n      <ion-col>\n        <div class=\"netflix-poster\">\n          <img src=\"assets/images/SPOTIFY.jpg\" />\n        </div>\n      </ion-col>\n    </ion-row>\n    <ion-row class=\"text-center\">\n      <ion-col offset-4>\n        <div (click)=\"spotifyShuffle();\">\n          <img src=\"assets/images/rewind-30-icon.png\" />\n        </div>\n      </ion-col>\n      <ion-col offset-4>\n        <div (click)=\"spotifyPlay();\">\n          <img width=\"30px\" src=\"assets/images/pause.png\" />\n        </div>\n      </ion-col>\n      <ion-col offset-4>\n        <div (click)=\"spotifyStop();\"><img src=\"assets/images/stop.png\" /></div>\n      </ion-col>\n    </ion-row>\n  </div>\n</ion-content>\n");

/***/ }),

/***/ "jiDk":
/*!***************************************************!*\
  !*** ./src/app/modal/ms-teams/ms-teams.page.scss ***!
  \***************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".text-center {\n  text-align: center;\n  margin: 0 auto;\n}\n\nion-range {\n  --bar-background: transparent;\n  --background: transparent;\n  --background-activated: transparent;\n  --background-focused: transparent;\n  --background-hover: transparent;\n  --background-activated-opacity: 0.12;\n  --background-focused-opacity: 0.15;\n  --background-hover-opacity: 0.04;\n}\n\nion-toolbar {\n  --background: transparent !important;\n  --border-color: transparent;\n  height: 90px;\n}\n\n.text-left {\n  text-align: left;\n}\n\n.text-right {\n  text-align: right;\n}\n\n.white-text {\n  color: white;\n}\n\n.text-bold {\n  font-weight: bold;\n}\n\n.modal-control-icons .control-icon {\n  font-size: 50px !important;\n}\n\n.netflix-poster img {\n  width: 70%;\n}\n\n.pp-boxes div {\n  margin: 10px;\n  background: #327eb3;\n  padding: 20px;\n  height: 80px;\n  border-radius: 10px;\n}\n\n.pp-boxes div.blank {\n  background: transparent;\n}\n\n.pp-boxes div p {\n  margin: 0;\n  position: relative;\n  top: 50%;\n  transform: translateY(-50%);\n}\n\n.toolbar-background {\n  border: 0 !important;\n}\n\n.touch-icon {\n  width: 100px;\n}\n\n.custom-toolbar {\n  background: #101010;\n  padding: 20px;\n  padding-top: 20px !important;\n}\n\n.custom-toolbar .toolbar-container {\n  padding: 50px !important;\n}\n\n.modal-title {\n  font-size: 24px;\n  margin: 20px 0px 20px 0px;\n}\n\n.modal-sub-title {\n  font-size: 18px;\n  margin: 20px 0px 20px 0px;\n}\n\n.sc-ion-modal-md-h {\n  height: 100% !important;\n  bottom: 0;\n  width: 100%;\n  margin: 0 auto;\n  margin-top: 0px;\n}\n\n.sc-ion-modal-md-h:first-of-type {\n  --backdrop-opacity: var(--ion-backdrop-opacity, 0.7);\n}\n\n.sc-ion-modal-md-h .modal-wrapper {\n  margin-top: 150px;\n  border-radius: 40px;\n  border-bottom-left-radius: 0;\n  border-bottom-right-radius: 0;\n}\n\n.sc-ion-modal-ios-h {\n  height: 100% !important;\n  bottom: 0;\n  width: 100%;\n  margin: 0 auto;\n  margin-top: 0px;\n}\n\n.sc-ion-modal-ios-h:first-of-type {\n  --backdrop-opacity: var(--ion-backdrop-opacity, 0.7);\n}\n\n.sc-ion-modal-ios-h .modal-wrapper {\n  margin-top: 150px;\n  border-radius: 40px;\n  border-bottom-left-radius: 0;\n  border-bottom-right-radius: 0;\n}\n\n.the-range-slider-container {\n  margin: 0;\n  padding: 0;\n}\n\nion-item::part(native) {\n  background-color: transparent;\n  padding: 0;\n}\n\nion-item::part(native) .item-inner {\n  display: none !important;\n  padding: 0;\n  border: 0;\n}\n\nmain::part(scroll) {\n  padding: 20px !important;\n}\n\n:root ion-range {\n  --bar-background: transparent;\n  --background: transparent;\n  --background-activated: transparent;\n  --background-focused: transparent;\n  --background-hover: transparent;\n  --background-activated-opacity: 0.12;\n  --background-focused-opacity: 0.15;\n  --background-hover-opacity: 0.04;\n}\n\n:root ion-toolbar ion-title {\n  padding: 0;\n}\n\n:root ion-toolbar .toolbar-container {\n  padding: 50px;\n}\n\n:root ion-toolbar:last-child .toolbar-background {\n  box-shadow: var(--box-shadow);\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uL21zLXRlYW1zLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNJLGtCQUFBO0VBQ0EsY0FBQTtBQUNKOztBQUNBO0VBQ0ksNkJBQUE7RUFFQSx5QkFBQTtFQUNBLG1DQUFBO0VBQ0EsaUNBQUE7RUFDQSwrQkFBQTtFQUNBLG9DQUFBO0VBQ0Esa0NBQUE7RUFDQSxnQ0FBQTtBQUNKOztBQUNBO0VBQ0ksb0NBQUE7RUFDQSwyQkFBQTtFQUNBLFlBQUE7QUFFSjs7QUFBQTtFQUNJLGdCQUFBO0FBR0o7O0FBREE7RUFDSSxpQkFBQTtBQUlKOztBQUZBO0VBQ0ksWUFBQTtBQUtKOztBQUhBO0VBQ0ksaUJBQUE7QUFNSjs7QUFISTtFQUNJLDBCQUFBO0FBTVI7O0FBRkk7RUFDSSxVQUFBO0FBS1I7O0FBREk7RUFDSSxZQUFBO0VBQ0EsbUJBQUE7RUFDQSxhQUFBO0VBQ0EsWUFBQTtFQUNBLG1CQUFBO0FBSVI7O0FBSFE7RUFDSSx1QkFBQTtBQUtaOztBQUhRO0VBQ0ksU0FBQTtFQUNBLGtCQUFBO0VBQ0EsUUFBQTtFQUNBLDJCQUFBO0FBS1o7O0FBQUE7RUFDSSxvQkFBQTtBQUdKOztBQURBO0VBQ0ksWUFBQTtBQUlKOztBQUZBO0VBQ0ksbUJBQUE7RUFDQSxhQUFBO0VBQ0EsNEJBQUE7QUFLSjs7QUFKSTtFQUNJLHdCQUFBO0FBTVI7O0FBSEE7RUFDSSxlQUFBO0VBQ0EseUJBQUE7QUFNSjs7QUFKQTtFQUNJLGVBQUE7RUFDQSx5QkFBQTtBQU9KOztBQUxBO0VBSUksdUJBQUE7RUFDQSxTQUFBO0VBQ0EsV0FBQTtFQUNBLGNBQUE7RUFFQSxlQUFBO0FBSUo7O0FBWkk7RUFDSSxvREFBQTtBQWNSOztBQU5JO0VBQ0ksaUJBQUE7RUFDQSxtQkFBQTtFQUNBLDRCQUFBO0VBQ0EsNkJBQUE7QUFRUjs7QUFMQTtFQUlJLHVCQUFBO0VBQ0EsU0FBQTtFQUNBLFdBQUE7RUFDQSxjQUFBO0VBRUEsZUFBQTtBQUlKOztBQVpJO0VBQ0ksb0RBQUE7QUFjUjs7QUFOSTtFQUNJLGlCQUFBO0VBQ0EsbUJBQUE7RUFDQSw0QkFBQTtFQUNBLDZCQUFBO0FBUVI7O0FBTEE7RUFDSSxTQUFBO0VBQ0EsVUFBQTtBQVFKOztBQU5BO0VBTUksNkJBQUE7RUFDQSxVQUFBO0FBSUo7O0FBVkk7RUFDSSx3QkFBQTtFQUNBLFVBQUE7RUFDQSxTQUFBO0FBWVI7O0FBUEE7RUFDSSx3QkFBQTtBQVVKOztBQUxJO0VBQ0ksNkJBQUE7RUFFQSx5QkFBQTtFQUNBLG1DQUFBO0VBQ0EsaUNBQUE7RUFDQSwrQkFBQTtFQUNBLG9DQUFBO0VBQ0Esa0NBQUE7RUFDQSxnQ0FBQTtBQU9SOztBQUpRO0VBQ0ksVUFBQTtBQU1aOztBQUpRO0VBQ0ksYUFBQTtBQU1aOztBQUhZO0VBQ0ksNkJBQUE7QUFLaEIiLCJmaWxlIjoibXMtdGVhbXMucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLnRleHQtY2VudGVyIHtcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gICAgbWFyZ2luOiAwIGF1dG87XG59XG5pb24tcmFuZ2Uge1xuICAgIC0tYmFyLWJhY2tncm91bmQ6IHRyYW5zcGFyZW50O1xuXG4gICAgLS1iYWNrZ3JvdW5kOiB0cmFuc3BhcmVudDtcbiAgICAtLWJhY2tncm91bmQtYWN0aXZhdGVkOiB0cmFuc3BhcmVudDtcbiAgICAtLWJhY2tncm91bmQtZm9jdXNlZDogdHJhbnNwYXJlbnQ7XG4gICAgLS1iYWNrZ3JvdW5kLWhvdmVyOiB0cmFuc3BhcmVudDtcbiAgICAtLWJhY2tncm91bmQtYWN0aXZhdGVkLW9wYWNpdHk6IDAuMTI7XG4gICAgLS1iYWNrZ3JvdW5kLWZvY3VzZWQtb3BhY2l0eTogMC4xNTtcbiAgICAtLWJhY2tncm91bmQtaG92ZXItb3BhY2l0eTogMC4wNDtcbn1cbmlvbi10b29sYmFyIHtcbiAgICAtLWJhY2tncm91bmQ6IHRyYW5zcGFyZW50ICFpbXBvcnRhbnQ7XG4gICAgLS1ib3JkZXItY29sb3I6IHRyYW5zcGFyZW50O1xuICAgIGhlaWdodDogOTBweDtcbn1cbi50ZXh0LWxlZnQge1xuICAgIHRleHQtYWxpZ246IGxlZnQ7XG59XG4udGV4dC1yaWdodCB7XG4gICAgdGV4dC1hbGlnbjogcmlnaHQ7XG59XG4ud2hpdGUtdGV4dCB7XG4gICAgY29sb3I6IHdoaXRlO1xufVxuLnRleHQtYm9sZCB7XG4gICAgZm9udC13ZWlnaHQ6IGJvbGQ7XG59XG4ubW9kYWwtY29udHJvbC1pY29ucyB7XG4gICAgLmNvbnRyb2wtaWNvbiB7XG4gICAgICAgIGZvbnQtc2l6ZTogNTBweCAhaW1wb3J0YW50O1xuICAgIH1cbn1cbi5uZXRmbGl4LXBvc3RlciB7XG4gICAgaW1nIHtcbiAgICAgICAgd2lkdGg6IDcwJTtcbiAgICB9XG59XG4ucHAtYm94ZXMge1xuICAgIGRpdiB7XG4gICAgICAgIG1hcmdpbjogMTBweDtcbiAgICAgICAgYmFja2dyb3VuZDogcmdiKDUwLCAxMjYsIDE3OSk7XG4gICAgICAgIHBhZGRpbmc6IDIwcHg7XG4gICAgICAgIGhlaWdodDogODBweDtcbiAgICAgICAgYm9yZGVyLXJhZGl1czogMTBweDtcbiAgICAgICAgJi5ibGFuayB7XG4gICAgICAgICAgICBiYWNrZ3JvdW5kOiB0cmFuc3BhcmVudDtcbiAgICAgICAgfVxuICAgICAgICBwIHtcbiAgICAgICAgICAgIG1hcmdpbjogMDtcbiAgICAgICAgICAgIHBvc2l0aW9uOiByZWxhdGl2ZTtcbiAgICAgICAgICAgIHRvcDogNTAlO1xuICAgICAgICAgICAgdHJhbnNmb3JtOiB0cmFuc2xhdGVZKC01MCUpO1xuICAgICAgICB9XG4gICAgfVxufVxuXG4udG9vbGJhci1iYWNrZ3JvdW5kIHtcbiAgICBib3JkZXI6IDAgIWltcG9ydGFudDtcbn1cbi50b3VjaC1pY29uIHtcbiAgICB3aWR0aDogMTAwcHg7XG59XG4uY3VzdG9tLXRvb2xiYXIge1xuICAgIGJhY2tncm91bmQ6ICMxMDEwMTA7XG4gICAgcGFkZGluZzogMjBweDtcbiAgICBwYWRkaW5nLXRvcDogMjBweCAhaW1wb3J0YW50O1xuICAgIC50b29sYmFyLWNvbnRhaW5lciB7XG4gICAgICAgIHBhZGRpbmc6IDUwcHggIWltcG9ydGFudDtcbiAgICB9XG59XG4ubW9kYWwtdGl0bGUge1xuICAgIGZvbnQtc2l6ZTogMjRweDtcbiAgICBtYXJnaW46IDIwcHggMHB4IDIwcHggMHB4O1xufVxuLm1vZGFsLXN1Yi10aXRsZSB7XG4gICAgZm9udC1zaXplOiAxOHB4O1xuICAgIG1hcmdpbjogMjBweCAwcHggMjBweCAwcHg7XG59XG4uc2MtaW9uLW1vZGFsLW1kLWgge1xuICAgICY6Zmlyc3Qtb2YtdHlwZSB7XG4gICAgICAgIC0tYmFja2Ryb3Atb3BhY2l0eTogdmFyKC0taW9uLWJhY2tkcm9wLW9wYWNpdHksIDAuNyk7XG4gICAgfVxuICAgIGhlaWdodDogMTAwJSAhaW1wb3J0YW50O1xuICAgIGJvdHRvbTogMDtcbiAgICB3aWR0aDogMTAwJTtcbiAgICBtYXJnaW46IDAgYXV0bztcblxuICAgIG1hcmdpbi10b3A6IDBweDtcbiAgICAubW9kYWwtd3JhcHBlciB7XG4gICAgICAgIG1hcmdpbi10b3A6IDE1MHB4O1xuICAgICAgICBib3JkZXItcmFkaXVzOiA0MHB4O1xuICAgICAgICBib3JkZXItYm90dG9tLWxlZnQtcmFkaXVzOiAwO1xuICAgICAgICBib3JkZXItYm90dG9tLXJpZ2h0LXJhZGl1czogMDtcbiAgICB9XG59XG4uc2MtaW9uLW1vZGFsLWlvcy1oIHtcbiAgICAmOmZpcnN0LW9mLXR5cGUge1xuICAgICAgICAtLWJhY2tkcm9wLW9wYWNpdHk6IHZhcigtLWlvbi1iYWNrZHJvcC1vcGFjaXR5LCAwLjcpO1xuICAgIH1cbiAgICBoZWlnaHQ6IDEwMCUgIWltcG9ydGFudDtcbiAgICBib3R0b206IDA7XG4gICAgd2lkdGg6IDEwMCU7XG4gICAgbWFyZ2luOiAwIGF1dG87XG5cbiAgICBtYXJnaW4tdG9wOiAwcHg7XG4gICAgLm1vZGFsLXdyYXBwZXIge1xuICAgICAgICBtYXJnaW4tdG9wOiAxNTBweDtcbiAgICAgICAgYm9yZGVyLXJhZGl1czogNDBweDtcbiAgICAgICAgYm9yZGVyLWJvdHRvbS1sZWZ0LXJhZGl1czogMDtcbiAgICAgICAgYm9yZGVyLWJvdHRvbS1yaWdodC1yYWRpdXM6IDA7XG4gICAgfVxufVxuLnRoZS1yYW5nZS1zbGlkZXItY29udGFpbmVyIHtcbiAgICBtYXJnaW46IDA7XG4gICAgcGFkZGluZzogMDtcbn1cbmlvbi1pdGVtOjpwYXJ0KG5hdGl2ZSkge1xuICAgIC5pdGVtLWlubmVyIHtcbiAgICAgICAgZGlzcGxheTogbm9uZSAhaW1wb3J0YW50O1xuICAgICAgICBwYWRkaW5nOiAwO1xuICAgICAgICBib3JkZXI6IDA7XG4gICAgfVxuICAgIGJhY2tncm91bmQtY29sb3I6IHRyYW5zcGFyZW50O1xuICAgIHBhZGRpbmc6IDA7XG59XG5tYWluOjpwYXJ0KHNjcm9sbCkge1xuICAgIHBhZGRpbmc6IDIwcHggIWltcG9ydGFudDtcbiAgICAvL292ZXJmbG93OiBoaWRkZW4gaSAhaW1wb3J0YW50O1xufVxuXG46cm9vdCB7XG4gICAgaW9uLXJhbmdlIHtcbiAgICAgICAgLS1iYXItYmFja2dyb3VuZDogdHJhbnNwYXJlbnQ7XG5cbiAgICAgICAgLS1iYWNrZ3JvdW5kOiB0cmFuc3BhcmVudDtcbiAgICAgICAgLS1iYWNrZ3JvdW5kLWFjdGl2YXRlZDogdHJhbnNwYXJlbnQ7XG4gICAgICAgIC0tYmFja2dyb3VuZC1mb2N1c2VkOiB0cmFuc3BhcmVudDtcbiAgICAgICAgLS1iYWNrZ3JvdW5kLWhvdmVyOiB0cmFuc3BhcmVudDtcbiAgICAgICAgLS1iYWNrZ3JvdW5kLWFjdGl2YXRlZC1vcGFjaXR5OiAwLjEyO1xuICAgICAgICAtLWJhY2tncm91bmQtZm9jdXNlZC1vcGFjaXR5OiAwLjE1O1xuICAgICAgICAtLWJhY2tncm91bmQtaG92ZXItb3BhY2l0eTogMC4wNDtcbiAgICB9XG4gICAgaW9uLXRvb2xiYXIge1xuICAgICAgICBpb24tdGl0bGUge1xuICAgICAgICAgICAgcGFkZGluZzogMDtcbiAgICAgICAgfVxuICAgICAgICAudG9vbGJhci1jb250YWluZXIge1xuICAgICAgICAgICAgcGFkZGluZzogNTBweDtcbiAgICAgICAgfVxuICAgICAgICAmOmxhc3QtY2hpbGQge1xuICAgICAgICAgICAgLnRvb2xiYXItYmFja2dyb3VuZCB7XG4gICAgICAgICAgICAgICAgYm94LXNoYWRvdzogdmFyKC0tYm94LXNoYWRvdyk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICB9XG59XG4iXX0= */");

/***/ }),

/***/ "oz6t":
/*!*************************************************!*\
  !*** ./src/app/modal/ms-teams/ms-teams.page.ts ***!
  \*************************************************/
/*! exports provided: MsTeamsPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MsTeamsPage", function() { return MsTeamsPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_ms_teams_page_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./ms-teams.page.html */ "4MGu");
/* harmony import */ var _ms_teams_page_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./ms-teams.page.scss */ "jiDk");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/common/http */ "tk/3");
/* harmony import */ var _services_api_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../services/api.service */ "H+bZ");
/* harmony import */ var _global_constants__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../global-constants */ "TqJ6");








let MsTeamsPage = class MsTeamsPage {
    constructor(modalController, httpClient, apiService, globals) {
        this.modalController = modalController;
        this.httpClient = httpClient;
        this.apiService = apiService;
        this.globals = globals;
        this.mic = localStorage.getItem("teamsMic");
        this.camera = localStorage.getItem("teamsCamera");
        this.hand = localStorage.getItem("teamsHand");
        this.netflixPlay = localStorage.getItem("netflixPlay");
        this.commandData = {
            appId: '',
            windowId: '',
            command: ''
        };
        this.commandDataSend = {};
        this.specificAppData = {};
    }
    ;
    dismiss() {
        this.modalController.dismiss({
            'dismissed': true
        });
    }
    // Get window specific data
    getSpecificApp(app) {
        this.globals.APPS_AVAILABLE_SINGULAR.forEach((key, value) => {
            if (key[0].appName == app.appName) {
                this.specificAppData = key[0];
            }
        });
        this.globals.APPS_AVAILABLE_MULTIPLE.forEach((key, value) => {
            if (key[0].appName == app.appName) {
                this.specificAppData = key[0];
            }
        });
    }
    doExecuteCommand(params) {
        this.apiService.executeCommand(params).subscribe((data) => {
        });
    }
    //Teams
    leaveMeeting() {
        var myOpt = JSON.parse(localStorage.getItem('currentAppID'));
        this.commandDataSend = {
            appId: this.commandData.appId,
            windowId: this.commandData.windowId,
            command: "Leave"
        };
        myOpt.appCommand = "Leave";
        this.doExecuteCommand(myOpt);
    }
    switchMic() {
        if (localStorage.getItem("teamsMic") == "false") {
            localStorage.setItem("teamsMic", "true");
            this.mic = "true";
        }
        else {
            localStorage.setItem("teamsMic", "false");
            this.mic = "false";
        }
        var myOpt = JSON.parse(localStorage.getItem('currentAppID'));
        // this.mic = !this.mic;
        this.commandDataSend = {
            appId: this.commandData.appId,
            windowId: this.commandData.windowId,
            command: "Mute Unmute mic"
        };
        myOpt.appCommand = "Mute Unmute mic";
        this.doExecuteCommand(myOpt);
    }
    switchCamera() {
        if (localStorage.getItem("teamsCamera") == "false") {
            localStorage.setItem("teamsCamera", "true");
            this.camera = "true";
        }
        else {
            localStorage.setItem("teamsCamera", "false");
            this.camera = "false";
        }
        var myOpt = JSON.parse(localStorage.getItem('currentAppID'));
        // this.camera = !this.camera;
        this.commandDataSend = {
            appId: this.commandData.appId,
            windowId: this.commandData.windowId,
            command: "Camera"
        };
        myOpt.appCommand = "Camera";
        this.doExecuteCommand(myOpt);
    }
    switchHand() {
        if (localStorage.getItem("teamsHand") == "false" || !localStorage.getItem("teamsHand")) {
            localStorage.setItem("teamsHand", "true");
            this.hand = "true";
        }
        else {
            localStorage.setItem("teamsHand", "false");
            this.hand = "false";
        }
        var myOpt = JSON.parse(localStorage.getItem('currentAppID'));
        // this.hand = !this.hand;
        // this.hand = true
        this.commandDataSend = {
            appId: this.commandData.appId,
            windowId: this.commandData.windowId,
            command: "Raise"
        };
        myOpt.appCommand = "Raise";
        this.doExecuteCommand(myOpt);
    }
    //Powerpoint
    ppPlayFromStart() {
        var myOpt = JSON.parse(localStorage.getItem('currentAppID'));
        this.commandDataSend = {
            appId: this.commandData.appId,
            windowId: this.commandData.windowId,
            command: "PlayFromStart"
        };
        myOpt.appCommand = "PlayFromStart";
        this.doExecuteCommand(myOpt);
    }
    ppPlayFromCurrentSlide() {
        var myOpt = JSON.parse(localStorage.getItem('currentAppID'));
        this.commandDataSend = {
            appId: this.commandData.appId,
            windowId: this.commandData.windowId,
            command: "PlayFromCurrentSlide"
        };
        myOpt.appCommand = "PlayFromCurrentSlide";
        this.doExecuteCommand(myOpt);
    }
    ppPrint() {
        var myOpt = JSON.parse(localStorage.getItem('currentAppID'));
        this.commandDataSend = {
            appId: this.commandData.appId,
            windowId: this.commandData.windowId,
            command: "Print"
        };
        myOpt.appCommand = "Print";
        this.doExecuteCommand(myOpt);
    }
    ppSave() {
        var myOpt = JSON.parse(localStorage.getItem('currentAppID'));
        this.commandDataSend = {
            appId: this.commandData.appId,
            windowId: this.commandData.windowId,
            command: "Save"
        };
        myOpt.appCommand = "Save";
        this.doExecuteCommand(myOpt);
    }
    ppNewSlide() {
        var myOpt = JSON.parse(localStorage.getItem('currentAppID'));
        this.commandDataSend = {
            appId: this.commandData.appId,
            windowId: this.commandData.windowId,
            command: "NewSlide"
        };
        myOpt.appCommand = "NewSlide";
        this.doExecuteCommand(myOpt);
    }
    ppDuplicateSlide() {
        var myOpt = JSON.parse(localStorage.getItem('currentAppID'));
        this.commandDataSend = {
            appId: this.commandData.appId,
            windowId: this.commandData.windowId,
            command: "DuplicateSlide"
        };
        myOpt.appCommand = "DuplicateSlide";
        this.doExecuteCommand(myOpt);
    }
    //Netflix
    netflixRewind() {
        var myOpt = JSON.parse(localStorage.getItem('currentAppID'));
        this.commandDataSend = {
            appId: this.commandData.appId,
            windowId: this.commandData.windowId,
            command: "Rewind10"
        };
        myOpt.appCommand = "Rewind10";
        this.doExecuteCommand(myOpt);
    }
    netflixPause() {
        if (localStorage.getItem("netflixPlay") == "false") {
            localStorage.setItem("netflixPlay", "true");
            this.netflixPlay = "true";
        }
        else {
            localStorage.setItem("netflixPlay", "false");
            this.netflixPlay = "false";
        }
        ;
        var myOpt = JSON.parse(localStorage.getItem('currentAppID'));
        this.commandDataSend = {
            appId: this.commandData.appId,
            windowId: this.commandData.windowId,
            command: "PlayPause"
        };
        myOpt.appCommand = "PlayPause";
        this.doExecuteCommand(myOpt);
    }
    netflixStop() {
        var myOpt = JSON.parse(localStorage.getItem('currentAppID'));
        this.commandDataSend = {
            appId: this.commandData.appId,
            windowId: this.commandData.windowId,
            command: "Stop"
        };
        myOpt.appCommand = "Stop";
        this.doExecuteCommand(myOpt);
    }
    // Spotify
    spotifyShuffle() {
        var myOpt = JSON.parse(localStorage.getItem('currentAppID'));
        this.commandDataSend = {
            appId: this.commandData.appId,
            windowId: this.commandData.windowId,
            command: "Shuffle"
        };
        myOpt.appCommand = "Shuffle";
        this.doExecuteCommand(myOpt);
    }
    spotifyPlay() {
        var myOpt = JSON.parse(localStorage.getItem('currentAppID'));
        this.commandDataSend = {
            appId: this.commandData.appId,
            windowId: this.commandData.windowId,
            command: "Play"
        };
        myOpt.appCommand = "Play";
        this.doExecuteCommand(myOpt);
    }
    spotifyStop() {
        var myOpt = JSON.parse(localStorage.getItem('currentAppID'));
        this.commandDataSend = {
            appId: this.commandData.appId,
            windowId: this.commandData.windowId,
            command: "Stop"
        };
        myOpt.appCommand = "Stop";
        this.doExecuteCommand(myOpt);
    }
    ngOnInit() {
        // localStorage.removeItem("teamsHand")
        // localStorage.removeItem("teamsCamera")
        // localStorage.removeItem("teamsMic")
        if (!localStorage.getItem("teamsHand") == true) {
            localStorage.setItem("teamsHand", "false");
            this.hand = "false";
        }
        if (!localStorage.getItem("teamsCamera") == true) {
            localStorage.setItem("teamsCamera", "false");
            this.camera = "false";
        }
        if (!localStorage.getItem("teamsMic") == true) {
            localStorage.setItem("teamsMic", "false");
            this.mic = "false";
        }
        if (!localStorage.getItem("netflixPlay") == true) {
            localStorage.setItem("netflixPlay", "false");
            this.netflixPlay = "false";
        }
        this.commandData = JSON.parse(localStorage.getItem('currentAppID'));
        // Initial call to get running apps
        this.getSpecificApp(this.commandData);
    }
};
MsTeamsPage.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["ModalController"] },
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_5__["HttpClient"] },
    { type: _services_api_service__WEBPACK_IMPORTED_MODULE_6__["ApiService"] },
    { type: _global_constants__WEBPACK_IMPORTED_MODULE_7__["GlobalConstants"] }
];
MsTeamsPage.propDecorators = {
    app: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["Input"] }]
};
MsTeamsPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-ms-teams',
        template: _raw_loader_ms_teams_page_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_ms_teams_page_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], MsTeamsPage);



/***/ })

}]);
//# sourceMappingURL=default~home-home-module~modal-ms-teams-ms-teams-module.js.map
(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["main"],{

/***/ 0:
/*!***************************!*\
  !*** multi ./src/main.ts ***!
  \***************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__(/*! /Users/an0rak/Google Drive/github/5 Zone/Native/native-controller/src/main.ts */"zUnb");


/***/ }),

/***/ "1Aq0":
/*!*******************************************************!*\
  !*** ./src/app/services/currently-viewing.service.ts ***!
  \*******************************************************/
/*! exports provided: CurrentlyViewingService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CurrentlyViewingService", function() { return CurrentlyViewingService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _global_constants__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../global-constants */ "TqJ6");



let CurrentlyViewingService = class CurrentlyViewingService {
    constructor(globals) {
        this.globals = globals;
        this.appSingular = this.globals.APPS_AVAILABLE_SINGULAR;
        this.appMultiple = this.globals.APPS_AVAILABLE_MULTIPLE;
        this.rawApps = [];
    }
    findNestedObj(entireObj, keyToFind, valToFind) {
        let foundObj;
        JSON.stringify(entireObj, (_, nestedValue) => {
            if (nestedValue && nestedValue[keyToFind] === valToFind) {
                foundObj = nestedValue;
            }
            return nestedValue;
        });
        return foundObj;
    }
    ;
    clearSingleViewing() {
        var myData = this.globals.APPS_AVAILABLE_SINGULAR;
        for (var i = 0; i < myData.length; i++) {
            if (myData[i].length == 1) {
                delete myData[i][0].windows[0].currentView;
            }
            if (myData[i].length > 1) {
                for (var ii = 0; ii < myData[i].length; ii++) {
                    delete myData[i][ii].windows[0].currentView;
                }
            }
        }
        return myData;
    }
    clearMultipleViewing() {
        var myDataMultiple = this.globals.APPS_AVAILABLE_MULTIPLE;
        for (var i = 0; i < myDataMultiple.length; i++) {
            if (myDataMultiple[i].length == 1) {
                for (var ii = 0; ii < myDataMultiple[i][0].windows.length; ii++) {
                    delete myDataMultiple[i][0].windows[ii].currentView;
                }
            }
        }
        return myDataMultiple;
    }
    jiggleArray(type) {
        var currentViewedAppID = JSON.parse(localStorage.getItem("currentlyViewedApp"));
        var currentViewedAppWindowID = JSON.parse(localStorage.getItem("currentlyViewedWindow"));
        if (type == 'single') {
            setTimeout(() => {
                var sData = this.clearSingleViewing();
                this.clearMultipleViewing();
                var theVal = this.findNestedObj(sData, 'id', currentViewedAppID);
                theVal.windows[0].currentView = true;
            }, 0);
        }
        if (type == 'multiple') {
            setTimeout(() => {
                var sData = this.clearMultipleViewing();
                this.clearSingleViewing();
                var theVal = this.findNestedObj(sData, 'id', currentViewedAppID);
                var theWindowVal = this.findNestedObj(theVal.windows, 'id', JSON.stringify(currentViewedAppWindowID));
                theWindowVal.currentView = true;
            }, 0);
        }
    }
    checkCurrentlyViewing(appData, type) {
        localStorage.setItem("currentlyViewedApp", appData.appID);
        localStorage.setItem("currentlyViewedWindow", appData.windowsID);
        if (type == 'multiple') {
            this.jiggleArray(type);
        }
        if (type == 'single') {
            this.jiggleArray(type);
        }
    }
};
CurrentlyViewingService.ctorParameters = () => [
    { type: _global_constants__WEBPACK_IMPORTED_MODULE_2__["GlobalConstants"] }
];
CurrentlyViewingService = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
        providedIn: 'root'
    })
], CurrentlyViewingService);



/***/ }),

/***/ "9kFZ":
/*!***************************************************!*\
  !*** ./src/app/modal/ipconfig/ipconfig.page.scss ***!
  \***************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJpcGNvbmZpZy5wYWdlLnNjc3MifQ== */");

/***/ }),

/***/ "AytR":
/*!*****************************************!*\
  !*** ./src/environments/environment.ts ***!
  \*****************************************/
/*! exports provided: environment */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "environment", function() { return environment; });
// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.
const environment = {
    production: false
};
/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.


/***/ }),

/***/ "EAHs":
/*!*****************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/modal/ipconfig/ipconfig.page.html ***!
  \*****************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\n  <ion-toolbar class=\"modal-toolbar\">\n    <ion-buttons slot=\"start\">\n      <ion-button fill=\"clear\" (click)=\"dismiss();\">\n        <ion-icon class=\"white-text\" name=\"chevron-down-outline\"></ion-icon>\n      </ion-button>\n    </ion-buttons>\n    <ion-title class=\"text-center\">\n      <p>Set IP</p>\n    </ion-title>\n  </ion-toolbar>\n</ion-header>\n<ion-content class=\"no-scroll\">\n  <ion-row class=\"text-center\">\n    <ion-col class=\"modal-title\" style=\"padding: 20px\">\n      <ion-item>\n        <ion-label class=\"ion-input-label\" position=\"stacked\"\n          >Current IP Address</ion-label\n        >\n        <ion-input\n          style=\"height: 80px; font-size: 30px\"\n          [value]=\"globals.REST_API_IP\"\n          [(ngModel)]=\"currentIpAddress\"\n          (keyup.enter)=\"updateIpPort()\"\n          placeholder=\"Enter IP\"\n          required\n          tabindex=\"0\"\n        ></ion-input>\n      </ion-item>\n      <ion-item>\n        <ion-label class=\"ion-input-label\" position=\"stacked\" tabindex=\"-1\"\n          >Current Port Setting</ion-label\n        >\n        <ion-input\n          style=\"height: 80px; font-size: 30px\"\n          [value]=\"globals.REST_API_PORT\"\n          [(ngModel)]=\"currentPortAddress\"\n          (keyup.enter)=\"updateIpPort()\"\n          placeholder=\"Enter PORT\"\n          required\n          tabindex=\"1\"\n        ></ion-input>\n      </ion-item>\n      <h6 class=\"m-t-20\">\n        Simply enter the new IP address <br />and PORT (if required) then hit\n        UPDATE button below\n      </h6>\n      <ion-button expand=\"medium\" color=\"success\" (click)=\"updateIpPort();\"\n        >UPDATE</ion-button\n      >\n      <h6 class=\"m-t-20\">Change takes effect immediately</h6>\n    </ion-col>\n  </ion-row>\n</ion-content>\n");

/***/ }),

/***/ "GW1a":
/*!***********************************************!*\
  !*** ./src/app/services/interceptor/index.ts ***!
  \***********************************************/
/*! exports provided: httpInterceptorProviders */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "httpInterceptorProviders", function() { return httpInterceptorProviders; });
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/common/http */ "tk/3");
/* harmony import */ var _noop_interceptor__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./noop-interceptor */ "XN2a");
/* "Barrel" of Http Interceptors */


/** Http interceptor providers in outside-in order */
const httpInterceptorProviders = [
    { provide: _angular_common_http__WEBPACK_IMPORTED_MODULE_0__["HTTP_INTERCEPTORS"], useClass: _noop_interceptor__WEBPACK_IMPORTED_MODULE_1__["HttpConfigInterceptor"], multi: true },
];


/***/ }),

/***/ "H+bZ":
/*!*****************************************!*\
  !*** ./src/app/services/api.service.ts ***!
  \*****************************************/
/*! exports provided: ApiService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ApiService", function() { return ApiService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _global_constants__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./../global-constants */ "TqJ6");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common/http */ "tk/3");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rxjs */ "qCKp");
/* harmony import */ var _services_current_ip_port_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../services/current-ip-port.service */ "kKPw");






let ApiService = class ApiService {
    constructor(currentIPPORT, httpClient, globals) {
        this.currentIPPORT = currentIPPORT;
        this.httpClient = httpClient;
        this.globals = globals;
        this.headers = new _angular_common_http__WEBPACK_IMPORTED_MODULE_3__["HttpHeaders"]({ 'Content-Type': 'application/json; charset=utf-8' });
        if (localStorage.getItem("currentIpAddress")) {
            this.globals.REST_API_IP = localStorage.getItem("currentIpAddress");
        }
        if (localStorage.getItem("currentPortAddress")) {
            this.globals.REST_API_PORT = localStorage.getItem("currentPortAddress");
        }
        this.globals.REST_API_SERVER = "http://" + this.globals.REST_API_IP + ":" + this.globals.REST_API_PORT + "/api/system";
    }
    handleError(error) {
        if (error.error instanceof ErrorEvent) {
            // A client-side or network error occurred. Handle it accordingly.
            console.error('An error occurred:', error.error.message);
        }
        else {
            // The backend returned an unsuccessful response code.
            // The response body may contain clues as to what went wrong.
            console.error(`Backend returned code ${error.status}, ` +
                `body was: ${error.error}`);
        }
        // Return an observable with a user-facing error message.
        return Object(rxjs__WEBPACK_IMPORTED_MODULE_4__["throwError"])('Something bad happened; please try again later.');
    }
    // Get all applications running on host
    getAppsRunning() {
        this.currentIPPORT.setValue({ "active": false });
        this.globals.API_CURRENT_PATH = "/apps/running/";
        return this.httpClient.get(this.globals.REST_API_SERVER + this.globals.API_CURRENT_PATH).pipe(
        // catchError(this.handleError)
        );
    }
    // Set focus to app window
    doSetWindowFocus(data) {
        this.globals.API_CURRENT_PATH = "/apps/running/" + data.appID + "/" + data.windowsID;
        var theURL = this.globals.REST_API_SERVER + this.globals.API_CURRENT_PATH;
        const body = { title: 'Angular PUT Request Example' };
        return this.httpClient.put(theURL, body);
    }
    // Execute application command 
    executeCommand(data) {
        this.globals.API_CURRENT_PATH = "/application/" + data.appID + "/shortcuts?windowId=" + data.windowsID + "&commandName=" + data.appCommand;
        var theURL = this.globals.REST_API_SERVER + this.globals.API_CURRENT_PATH;
        var body = {};
        return this.httpClient.post(theURL, body);
    }
};
ApiService.ctorParameters = () => [
    { type: _services_current_ip_port_service__WEBPACK_IMPORTED_MODULE_5__["CurrentIpPortService"] },
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_3__["HttpClient"] },
    { type: _global_constants__WEBPACK_IMPORTED_MODULE_1__["GlobalConstants"] }
];
ApiService = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["Injectable"])({
        providedIn: 'root'
    })
], ApiService);



/***/ }),

/***/ "Sy1n":
/*!**********************************!*\
  !*** ./src/app/app.component.ts ***!
  \**********************************/
/*! exports provided: AppComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppComponent", function() { return AppComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_app_component_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./app.component.html */ "VzVu");
/* harmony import */ var _app_component_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./app.component.scss */ "ynWL");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/common/http */ "tk/3");
/* harmony import */ var _services_api_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./services/api.service */ "H+bZ");
/* harmony import */ var _services_cleandata_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./services/cleandata.service */ "oEKA");
/* harmony import */ var _global_constants__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./global-constants */ "TqJ6");
/* harmony import */ var _services_current_ip_port_service__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./services/current-ip-port.service */ "kKPw");
/* harmony import */ var _modal_ipconfig_ipconfig_page__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./modal/ipconfig/ipconfig.page */ "xG7c");












let AppComponent = class AppComponent {
    constructor(menu, currentIPPORT, cleanData, modalController, httpClient, apiService, globals) {
        this.menu = menu;
        this.currentIPPORT = currentIPPORT;
        this.cleanData = cleanData;
        this.modalController = modalController;
        this.httpClient = httpClient;
        this.apiService = apiService;
        this.globals = globals;
        this.theRunningApps = [];
        this.theRunningApps2 = [];
        this.appsSingular = [];
        this.appsMultiple = [];
        this.currentModal = null;
    }
    openFirst() {
        this.menu.enable(true, 'first');
        this.menu.open('first');
    }
    openEnd() {
        this.menu.open('end');
    }
    openCustom() {
        this.menu.enable(true, 'custom');
        this.menu.open('custom');
    }
    doReloadData() {
        this.cleanData.cleanUpData();
        this.menu.close();
    }
    doPresentIPModal() {
        this.presentModal(null, null, _modal_ipconfig_ipconfig_page__WEBPACK_IMPORTED_MODULE_10__["IpconfigPage"]);
    }
    presentModal(event, trusted, type) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            var options;
            if (type.name == 'IpconfigPage') {
                options = {
                    component: _modal_ipconfig_ipconfig_page__WEBPACK_IMPORTED_MODULE_10__["IpconfigPage"],
                    cssClass: 'my-custom-class'
                };
            }
            localStorage.setItem('currentAppID', JSON.stringify(event));
            this.globals.CURRENT_MODAL = yield this.modalController.create(options);
            this.globals.CURRENT_MODAL.onDidDismiss().then((dataReturned) => {
                this.menu.close();
                this.globals.API_DELAY_CALL = true;
                this.currentIPPORT.subscription = this.currentIPPORT.getAsyncData().subscribe(u => (this.currMachine = u));
                console.log(this.currentIPPORT.subscription = this.currentIPPORT.getAsyncData().subscribe(u => (this.currMachine = u)));
                this.cleanData.cleanUpData();
            });
            this.currentModal = this.globals.CURRENT_MODAL;
            return yield this.globals.CURRENT_MODAL.present();
        });
    }
    isAllowedAppName(appName) {
        return this.globals.APPS_ALLOWED_APPS.includes(appName) == true;
    }
    getRunningProcesses() {
        this.cleanData.cleanUpData();
    }
    grabUserIpAddress() {
        this.httpClient.get("assets/ipAddress.json").subscribe(data => {
            this.globals.REST_API_IP = data[0].ip;
            this.globals.REST_API_PORT = data[0].port;
            if (!localStorage.getItem("currentIpAddress")) {
                localStorage.setItem("currentIpAddress", this.globals.REST_API_IP);
            }
            if (!localStorage.getItem("currentPortAddress")) {
                localStorage.setItem("currentPortAddress", this.globals.REST_API_PORT);
            }
            this.currentIPPORT.subscription = this.currentIPPORT.getAsyncData().subscribe(u => (this.currMachine = u));
        });
    }
    ngOnInit() {
        this.currentIPPORT.subscriptionApiError = this.currentIPPORT.checkIfApiError(this.globals.API_ERROR).subscribe(u => (this.apiError = u));
        if (localStorage.getItem("currentIpAddress")) {
            this.globals.REST_API_IP = localStorage.getItem("currentIpAddress");
        }
        if (localStorage.getItem("currentPortAddress")) {
            this.globals.REST_API_PORT = localStorage.getItem("currentPortAddress");
        }
        this.grabUserIpAddress();
        this.getRunningProcesses();
    }
};
AppComponent.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["MenuController"] },
    { type: _services_current_ip_port_service__WEBPACK_IMPORTED_MODULE_9__["CurrentIpPortService"] },
    { type: _services_cleandata_service__WEBPACK_IMPORTED_MODULE_7__["CleandataService"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["ModalController"] },
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_5__["HttpClient"] },
    { type: _services_api_service__WEBPACK_IMPORTED_MODULE_6__["ApiService"] },
    { type: _global_constants__WEBPACK_IMPORTED_MODULE_8__["GlobalConstants"] }
];
AppComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-root',
        template: _raw_loader_app_component_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_app_component_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], AppComponent);



/***/ }),

/***/ "TqJ6":
/*!*************************************!*\
  !*** ./src/app/global-constants.ts ***!
  \*************************************/
/*! exports provided: GlobalConstants */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "GlobalConstants", function() { return GlobalConstants; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");


let GlobalConstants = class GlobalConstants {
    constructor() {
        this.REST_API_IP = "127.0.0.1";
        this.REST_API_PORT = "";
        this.REST_API_SERVER = "http://" + this.REST_API_IP + ":" + this.REST_API_PORT + "/api/system";
        this.APPS_AVAILABLE_SINGULAR = [];
        this.APPS_AVAILABLE_MULTIPLE = [];
        this.APP_CURRENTLY_VIEWING = {};
        this.API_DELAY_CALL = false;
        this.API_CURRENT_PATH = "/apps/running/";
        this.API_ERROR = [];
        this.API_ERROR_TYPE = null;
        this.LOADING = true;
        this.LOADINGDATA = false;
        this.errorActive = false;
    }
};
GlobalConstants = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])()
], GlobalConstants);



/***/ }),

/***/ "VzVu":
/*!**************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/app.component.html ***!
  \**************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-app>\n  <ion-menu side=\"start\" content-id=\"main-content\">\n    <ion-header class=\"menu-custom-header\">\n      <ion-toolbar translucent style=\"padding: 20px\">\n        <ion-title>Menu</ion-title>\n      </ion-toolbar>\n    </ion-header>\n    <ion-content style=\"background: #0e0e0e\">\n      <ion-list style=\"padding: 20px; background: transparent\">\n        <ion-item (click)=\"doPresentIPModal()\">\n          <ion-icon name=\"wifi-outline\" slot=\"start\"></ion-icon>\n          <ion-label>IP / PORT Settings</ion-label>\n        </ion-item>\n        <ion-item (click)=\"doReloadData()\">\n          <ion-icon name=\"refresh-outline\" slot=\"start\"></ion-icon>\n          <ion-label>Reload Apps</ion-label>\n        </ion-item>\n      </ion-list>\n      <div style=\"padding: 20px\">Sidecar v1.0.2</div>\n    </ion-content>\n  </ion-menu>\n  <ion-router-outlet id=\"main-content\"></ion-router-outlet>\n</ion-app>\n");

/***/ }),

/***/ "XN2a":
/*!**********************************************************!*\
  !*** ./src/app/services/interceptor/noop-interceptor.ts ***!
  \**********************************************************/
/*! exports provided: HttpConfigInterceptor */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "HttpConfigInterceptor", function() { return HttpConfigInterceptor; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common/http */ "tk/3");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs */ "qCKp");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rxjs/operators */ "kU1M");
/* harmony import */ var _global_constants__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../global-constants */ "TqJ6");
/* harmony import */ var _services_cleandata_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../services/cleandata.service */ "oEKA");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var _services_current_ip_port_service__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../services/current-ip-port.service */ "kKPw");


// import { ErrorDialogService } from './errordialog.service';







let HttpConfigInterceptor = class HttpConfigInterceptor {
    constructor(currentIPPORT, modalController, cleanData, globals) {
        this.currentIPPORT = currentIPPORT;
        this.modalController = modalController;
        this.cleanData = cleanData;
        this.globals = globals;
    }
    intercept(request, next) {
        const token = localStorage.getItem('token');
        //
        request = request.clone({ headers: request.headers.set('withCredentials', 'true' + token) });
        if (!request.headers.has('Content-Type')) {
            request = request.clone({ headers: request.headers.set('Content-Type', 'application/json') });
        }
        request = request.clone({ headers: request.headers.set('Accept', 'application/json') });
        return next.handle(request).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["map"])((event) => {
            var currReqPath = request.url;
            this.globals.API_ERROR = [{
                    "active": false,
                    "type": "API"
                }];
            if (currReqPath.includes('commandName=Leave')) {
                this.globals.API_DELAY_CALL = true;
                // Close modal and call api for fresh app list
                this.modalController.dismiss({ 'dismissed': 'leaveTeamsCall' });
            }
            if (event instanceof _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpResponse"]) {
            }
            return event;
        }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["catchError"])((error) => {
            let data = {};
            data = {
                reason: error && error.error && error.error.reason ? error.error.reason : '',
                status: error.status
            };
            this.currentIPPORT.subscription = this.currentIPPORT.getAsyncData().subscribe(u => (this.globals.REST_API_IP = u.currIP));
            this.currentIPPORT.subscription = this.currentIPPORT.getAsyncData().subscribe(u => (this.globals.REST_API_PORT = u.currPORT));
            if (new String("http://" + this.globals.REST_API_IP + "/api/system/apps/running/").valueOf() == new String("http://" + this.globals.REST_API_IP + "/api/system/apps/running/").valueOf()) {
                if (error.statusText == 'Unknown Error') {
                    this.globals.API_ERROR = [{
                            "active": true,
                            "type": "NOCONNECT"
                        }];
                    this.currentIPPORT.setValue({ "active": true });
                    this.currentIPPORT.subscriptionApiError = this.currentIPPORT.checkIfApiError(this.globals.API_ERROR).subscribe(u => u);
                    this.globals.LOADING = false;
                }
                if (error.statusText == 'Not Found') {
                    this.globals.API_ERROR = [{
                            "active": true,
                            "type": "NOTFOUND"
                        }];
                    this.currentIPPORT.setValue({ "active": true });
                    this.currentIPPORT.subscriptionApiError = this.currentIPPORT.checkIfApiError(this.globals.API_ERROR).subscribe(u => u);
                    this.globals.LOADING = false;
                }
            }
            if (error.url) {
                if (new String("http://" + this.globals.REST_API_IP + "/api/system/apps/running/").valueOf() == new String("http://null/api/system/apps/running/").valueOf()) {
                    this.globals.API_ERROR = [{
                            "active": true,
                            "type": "GETSERVER"
                        }];
                    this.currentIPPORT.setValue({ "active": true });
                    this.currentIPPORT.subscriptionApiError = this.currentIPPORT.checkIfApiError(this.globals.API_ERROR).subscribe(u => u);
                    this.globals.LOADING = false;
                }
            }
            // this.globals.API_ERROR = true;
            // this.globals.API_ERROR_TYPE = error.status;
            return Object(rxjs__WEBPACK_IMPORTED_MODULE_3__["throwError"])(error);
        }));
    }
};
HttpConfigInterceptor.ctorParameters = () => [
    { type: _services_current_ip_port_service__WEBPACK_IMPORTED_MODULE_8__["CurrentIpPortService"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_7__["ModalController"] },
    { type: _services_cleandata_service__WEBPACK_IMPORTED_MODULE_6__["CleandataService"] },
    { type: _global_constants__WEBPACK_IMPORTED_MODULE_5__["GlobalConstants"] }
];
HttpConfigInterceptor = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])()
], HttpConfigInterceptor);



/***/ }),

/***/ "ZAI4":
/*!*******************************!*\
  !*** ./src/app/app.module.ts ***!
  \*******************************/
/*! exports provided: AppModule, httpTranslateLoader */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppModule", function() { return AppModule; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "httpTranslateLoader", function() { return httpTranslateLoader; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/platform-browser */ "jhN1");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var _app_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./app.component */ "Sy1n");
/* harmony import */ var _app_routing_module__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./app-routing.module */ "vY5A");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/common/http */ "tk/3");
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @ngx-translate/core */ "sYmb");
/* harmony import */ var _ngx_translate_http_loader__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @ngx-translate/http-loader */ "mqiu");
/* harmony import */ var _global_constants__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./global-constants */ "TqJ6");
/* harmony import */ var _ionic_native_http_ngx__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @ionic-native/http/ngx */ "XSEc");
/* harmony import */ var _services_interceptor_index__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ./services/interceptor/index */ "GW1a");













let AppModule = class AppModule {
};
AppModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        declarations: [_app_component__WEBPACK_IMPORTED_MODULE_5__["AppComponent"]],
        entryComponents: [],
        imports: [
            _angular_platform_browser__WEBPACK_IMPORTED_MODULE_2__["BrowserModule"],
            _angular_common_http__WEBPACK_IMPORTED_MODULE_7__["HttpClientModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"].forRoot(),
            _app_routing_module__WEBPACK_IMPORTED_MODULE_6__["AppRoutingModule"],
            _ngx_translate_core__WEBPACK_IMPORTED_MODULE_8__["TranslateModule"].forRoot({
                loader: {
                    provide: _ngx_translate_core__WEBPACK_IMPORTED_MODULE_8__["TranslateLoader"],
                    useFactory: httpTranslateLoader,
                    deps: [_angular_common_http__WEBPACK_IMPORTED_MODULE_7__["HttpClient"]]
                }
            }),
        ],
        providers: [_services_interceptor_index__WEBPACK_IMPORTED_MODULE_12__["httpInterceptorProviders"], _global_constants__WEBPACK_IMPORTED_MODULE_10__["GlobalConstants"], _ionic_native_http_ngx__WEBPACK_IMPORTED_MODULE_11__["HTTP"], { provide: _angular_router__WEBPACK_IMPORTED_MODULE_3__["RouteReuseStrategy"], useClass: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicRouteStrategy"] }],
        bootstrap: [_app_component__WEBPACK_IMPORTED_MODULE_5__["AppComponent"]],
    })
], AppModule);

// AOT compilation support
function httpTranslateLoader(http) {
    return new _ngx_translate_http_loader__WEBPACK_IMPORTED_MODULE_9__["TranslateHttpLoader"](http);
}


/***/ }),

/***/ "kKPw":
/*!*****************************************************!*\
  !*** ./src/app/services/current-ip-port.service.ts ***!
  \*****************************************************/
/*! exports provided: CurrentIpPortService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CurrentIpPortService", function() { return CurrentIpPortService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs */ "qCKp");
/* harmony import */ var _global_constants__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./../global-constants */ "TqJ6");





let CurrentIpPortService = class CurrentIpPortService {
    constructor(globals) {
        this.globals = globals;
        this.apiError = this.globals.API_ERROR;
        this.routerInfo = new rxjs__WEBPACK_IMPORTED_MODULE_2__["BehaviorSubject"]({ "active": false });
        this.currentViewingApp = new rxjs__WEBPACK_IMPORTED_MODULE_2__["BehaviorSubject"]({});
        this.subscription = this.getAsyncData().subscribe(u => (this.currMachine = u));
        this.subscriptionApiError = this.checkIfApiError(this.globals.API_ERROR).subscribe(u => u);
    }
    getViewingNow() {
        return this.currentViewingApp.asObservable();
    }
    setViewingNow(newValue) {
        this.currentViewingApp.next(newValue);
    }
    getValue() {
        return this.routerInfo.asObservable();
    }
    setValue(newValue) {
        this.routerInfo.next(newValue);
    }
    checkIfApiError(errorFlag) {
        return Object(rxjs__WEBPACK_IMPORTED_MODULE_2__["of"])({
            active: errorFlag.active,
            type: errorFlag.type
        });
    }
    getAsyncData() {
        return Object(rxjs__WEBPACK_IMPORTED_MODULE_2__["of"])({
            currIP: localStorage.getItem("currentIpAddress"),
            currPORT: localStorage.getItem("currentPortAddress")
        });
    }
};
CurrentIpPortService.ctorParameters = () => [
    { type: _global_constants__WEBPACK_IMPORTED_MODULE_3__["GlobalConstants"] }
];
CurrentIpPortService = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
        providedIn: 'root'
    })
], CurrentIpPortService);



/***/ }),

/***/ "kLfG":
/*!*****************************************************************************************************************************************!*\
  !*** ./node_modules/@ionic/core/dist/esm lazy ^\.\/.*\.entry\.js$ include: \.entry\.js$ exclude: \.system\.entry\.js$ namespace object ***!
  \*****************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var map = {
	"./ion-action-sheet.entry.js": [
		"dUtr",
		"common",
		0
	],
	"./ion-alert.entry.js": [
		"Q8AI",
		"common",
		1
	],
	"./ion-app_8.entry.js": [
		"hgI1",
		"common",
		2
	],
	"./ion-avatar_3.entry.js": [
		"CfoV",
		"common",
		3
	],
	"./ion-back-button.entry.js": [
		"Nt02",
		"common",
		4
	],
	"./ion-backdrop.entry.js": [
		"Q2Bp",
		5
	],
	"./ion-button_2.entry.js": [
		"0Pbj",
		"common",
		6
	],
	"./ion-card_5.entry.js": [
		"ydQj",
		"common",
		7
	],
	"./ion-checkbox.entry.js": [
		"4fMi",
		"common",
		8
	],
	"./ion-chip.entry.js": [
		"czK9",
		"common",
		9
	],
	"./ion-col_3.entry.js": [
		"/CAe",
		10
	],
	"./ion-datetime_3.entry.js": [
		"WgF3",
		"common",
		11
	],
	"./ion-fab_3.entry.js": [
		"uQcF",
		"common",
		12
	],
	"./ion-img.entry.js": [
		"wHD8",
		13
	],
	"./ion-infinite-scroll_2.entry.js": [
		"2lz6",
		14
	],
	"./ion-input.entry.js": [
		"ercB",
		"common",
		15
	],
	"./ion-item-option_3.entry.js": [
		"MGMP",
		"common",
		16
	],
	"./ion-item_8.entry.js": [
		"9bur",
		"common",
		17
	],
	"./ion-loading.entry.js": [
		"cABk",
		"common",
		18
	],
	"./ion-menu_3.entry.js": [
		"kyFE",
		"common",
		19
	],
	"./ion-modal.entry.js": [
		"TvZU",
		"common",
		20
	],
	"./ion-nav_2.entry.js": [
		"vnES",
		"common",
		21
	],
	"./ion-popover.entry.js": [
		"qCuA",
		"common",
		22
	],
	"./ion-progress-bar.entry.js": [
		"0tOe",
		"common",
		23
	],
	"./ion-radio_2.entry.js": [
		"h11V",
		"common",
		24
	],
	"./ion-range.entry.js": [
		"XGij",
		"common",
		25
	],
	"./ion-refresher_2.entry.js": [
		"nYbb",
		"common",
		26
	],
	"./ion-reorder_2.entry.js": [
		"smMY",
		"common",
		27
	],
	"./ion-ripple-effect.entry.js": [
		"STjf",
		28
	],
	"./ion-route_4.entry.js": [
		"k5eQ",
		"common",
		29
	],
	"./ion-searchbar.entry.js": [
		"OR5t",
		"common",
		30
	],
	"./ion-segment_2.entry.js": [
		"fSgp",
		"common",
		31
	],
	"./ion-select_3.entry.js": [
		"lfGF",
		"common",
		32
	],
	"./ion-slide_2.entry.js": [
		"5xYT",
		33
	],
	"./ion-spinner.entry.js": [
		"nI0H",
		"common",
		34
	],
	"./ion-split-pane.entry.js": [
		"NAQR",
		35
	],
	"./ion-tab-bar_2.entry.js": [
		"knkW",
		"common",
		36
	],
	"./ion-tab_2.entry.js": [
		"TpdJ",
		"common",
		37
	],
	"./ion-text.entry.js": [
		"ISmu",
		"common",
		38
	],
	"./ion-textarea.entry.js": [
		"U7LX",
		"common",
		39
	],
	"./ion-toast.entry.js": [
		"L3sA",
		"common",
		40
	],
	"./ion-toggle.entry.js": [
		"IUOf",
		"common",
		41
	],
	"./ion-virtual-scroll.entry.js": [
		"8Mb5",
		42
	]
};
function webpackAsyncContext(req) {
	if(!__webpack_require__.o(map, req)) {
		return Promise.resolve().then(function() {
			var e = new Error("Cannot find module '" + req + "'");
			e.code = 'MODULE_NOT_FOUND';
			throw e;
		});
	}

	var ids = map[req], id = ids[0];
	return Promise.all(ids.slice(1).map(__webpack_require__.e)).then(function() {
		return __webpack_require__(id);
	});
}
webpackAsyncContext.keys = function webpackAsyncContextKeys() {
	return Object.keys(map);
};
webpackAsyncContext.id = "kLfG";
module.exports = webpackAsyncContext;

/***/ }),

/***/ "oEKA":
/*!***********************************************!*\
  !*** ./src/app/services/cleandata.service.ts ***!
  \***********************************************/
/*! exports provided: CleandataService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CleandataService", function() { return CleandataService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _global_constants__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../global-constants */ "TqJ6");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common/http */ "tk/3");
/* harmony import */ var _api_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./api.service */ "H+bZ");
/* harmony import */ var _currently_viewing_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./currently-viewing.service */ "1Aq0");






let CleandataService = class CleandataService {
    constructor(httpClient, apiService, globals, currentlyViewing) {
        this.httpClient = httpClient;
        this.apiService = apiService;
        this.globals = globals;
        this.currentlyViewing = currentlyViewing;
        this.preStripArr = [];
        this.theAppData = [];
        this.theAppDataRemodelled = [];
    }
    isAllowedAppName(appName) {
        return this.globals.APPS_ALLOWED_APPS.includes(appName) == true;
    }
    getAllowedApps() {
        this.httpClient.get("../assets/allowedApps.json").subscribe(data => {
            this.globals.APPS_ALLOWED_APPS = data;
        });
    }
    callAppsApi() {
        this.globals.APPS_AVAILABLE_SINGULAR = [];
        this.globals.APPS_AVAILABLE_MULTIPLE = [];
        var currentViewedAppID = JSON.parse(localStorage.getItem("currentlyViewedApp"));
        var currentViewedAppWindowID = JSON.parse(localStorage.getItem("currentlyViewedWindow"));
        this.apiService.getAppsRunning().subscribe((data) => {
            this.globals.LOADING = false;
            this.globals.LOADINGDATA = true;
            this.preStripArr = [];
            this.theAppData = [];
            this.preStripArr = data;
            for (const [i, v] of this.preStripArr.entries()) {
                var allowed = this.isAllowedAppName(v.name);
                if (v.name == "APPLICATIONFRAMEHOST") {
                    for (const [ii, vv] of v.windowTitles.entries()) {
                        var allowed = this.isAllowedAppName(vv);
                        if (allowed === true) {
                            v.title = vv;
                            v.appName = vv;
                            v.name = vv.toUpperCase();
                            v.switched = true;
                            v.windowTitles = [];
                            var [windowTitleTemp] = [vv];
                            v.windowTitles = ([windowTitleTemp]);
                            v.windows = [v.windows[ii]];
                            this.theAppData.push(v);
                        }
                    }
                }
                else {
                    if (allowed === true) {
                        this.theAppData.push(v);
                    }
                }
            }
            // Remodelled
            this.theAppDataRemodelled = [];
            for (const [appKey, appValue] of Object.entries(this.theAppData)) {
                if (appValue.windows.length > 1) {
                    if (appValue.id == currentViewedAppID) {
                        for (const [appWindowKey, appWindowValue] of Object.entries(appValue.windows)) {
                            if (appWindowValue["id"] == currentViewedAppWindowID) {
                                appValue.windows[appWindowKey].currentView = true;
                            }
                        }
                    }
                    this.theAppDataRemodelled.push(appValue);
                }
                if (appValue.windows.length == 1) {
                    if (appValue.id == currentViewedAppID) {
                        if (appValue.windows[0].id == currentViewedAppWindowID) {
                            appValue.windows[0].currentView = true;
                        }
                    }
                    this.theAppDataRemodelled.push(appValue);
                }
            }
            // Reduce to make Singular and Multiple arrays
            let group = this.theAppDataRemodelled.reduce((r, a) => {
                r[a.name] = [...r[a.name] || [], a];
                return r;
            }, {});
            const objectArray = Object.entries(group);
            objectArray.forEach(([key, value]) => {
                if (value[0].windows.length > 1) {
                    this.globals.APPS_AVAILABLE_MULTIPLE.push(value);
                }
                if (value[0].windows.length == 1) {
                    this.globals.APPS_AVAILABLE_SINGULAR.push(value);
                }
            });
            setTimeout(() => {
                this.globals.LOADINGDATA = false;
                this.globals.API_DELAY_CALL = false;
            }, 2000);
        });
    }
    cleanUpData() {
        this.getAllowedApps();
        if (this.globals.API_DELAY_CALL == true) {
            this.globals.LOADING = true;
            setTimeout(() => {
                this.callAppsApi();
            }, 1000);
        }
        else {
            this.callAppsApi();
        }
    }
};
CleandataService.ctorParameters = () => [
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_3__["HttpClient"] },
    { type: _api_service__WEBPACK_IMPORTED_MODULE_4__["ApiService"] },
    { type: _global_constants__WEBPACK_IMPORTED_MODULE_2__["GlobalConstants"] },
    { type: _currently_viewing_service__WEBPACK_IMPORTED_MODULE_5__["CurrentlyViewingService"] }
];
CleandataService = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
        providedIn: 'root'
    })
], CleandataService);



/***/ }),

/***/ "vY5A":
/*!***************************************!*\
  !*** ./src/app/app-routing.module.ts ***!
  \***************************************/
/*! exports provided: AppRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppRoutingModule", function() { return AppRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "tyNb");



const routes = [
    {
        path: '',
        loadChildren: () => Promise.all(/*! import() | home-home-module */[__webpack_require__.e("default~home-home-module~modal-modals-ms-teams-module"), __webpack_require__.e("home-home-module")]).then(__webpack_require__.bind(null, /*! ./home/home.module */ "ct+p")).then(m => m.HomePageModule)
    },
    {
        path: '',
        redirectTo: '',
        pathMatch: 'full'
    },
    {
        path: 'modals',
        loadChildren: () => Promise.all(/*! import() | modal-modals-ms-teams-module */[__webpack_require__.e("default~home-home-module~modal-modals-ms-teams-module"), __webpack_require__.e("modal-modals-ms-teams-module")]).then(__webpack_require__.bind(null, /*! ./modal/modals/ms-teams.module */ "WEGs")).then(m => m.MsTeamsPageModule)
    },
    {
        path: 'ipconfig',
        loadChildren: () => __webpack_require__.e(/*! import() | modal-ipconfig-ipconfig-module */ "modal-ipconfig-ipconfig-module").then(__webpack_require__.bind(null, /*! ./modal/ipconfig/ipconfig.module */ "Wt6d")).then(m => m.IpconfigPageModule)
    },
];
let AppRoutingModule = class AppRoutingModule {
};
AppRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forRoot(routes, { preloadingStrategy: _angular_router__WEBPACK_IMPORTED_MODULE_2__["PreloadAllModules"] })
        ],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
    })
], AppRoutingModule);



/***/ }),

/***/ "xG7c":
/*!*************************************************!*\
  !*** ./src/app/modal/ipconfig/ipconfig.page.ts ***!
  \*************************************************/
/*! exports provided: IpconfigPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "IpconfigPage", function() { return IpconfigPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_ipconfig_page_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./ipconfig.page.html */ "EAHs");
/* harmony import */ var _ipconfig_page_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./ipconfig.page.scss */ "9kFZ");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var _global_constants__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../global-constants */ "TqJ6");
/* harmony import */ var _services_current_ip_port_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../services/current-ip-port.service */ "kKPw");







let IpconfigPage = class IpconfigPage {
    constructor(currentIPPORT, modalController, globals) {
        this.currentIPPORT = currentIPPORT;
        this.modalController = modalController;
        this.globals = globals;
    }
    dismiss() {
        this.modalController.dismiss({
            'dismissed': 'updatedIpPort'
        });
    }
    setPreviousIPPORT() {
        this.globals.REST_API_IP = localStorage.getItem("currentIpAddress");
        this.globals.REST_API_PORT = localStorage.getItem("currentPortAddress");
    }
    updateIpPort() {
        localStorage.setItem("currentIpAddress", this.currentIpAddress);
        localStorage.setItem("currentPortAddress", this.currentPortAddress);
        this.globals.REST_API_IP = this.currentIpAddress;
        this.globals.REST_API_PORT = this.currentPortAddress;
        if (this.currentPortAddress == undefined || this.currentPortAddress == '') {
            this.globals.REST_API_SERVER = "http://" + localStorage.getItem("currentIpAddress") + "/api/system";
        }
        else {
            this.globals.REST_API_SERVER = "http://" + localStorage.getItem("currentIpAddress") + ":" + localStorage.getItem("currentPortAddress") + "/api/system";
        }
        this.dismiss();
    }
    ngOnInit() {
        console.log(localStorage.getItem("currentIpAddress"));
        this.currentIpAddress = localStorage.getItem("currentIpAddress");
        this.currentPortAddress = localStorage.getItem("currentPortAddress");
        if (this.currentIpAddress) {
            this.previousSettingsExist = true;
        }
    }
};
IpconfigPage.ctorParameters = () => [
    { type: _services_current_ip_port_service__WEBPACK_IMPORTED_MODULE_6__["CurrentIpPortService"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["ModalController"] },
    { type: _global_constants__WEBPACK_IMPORTED_MODULE_5__["GlobalConstants"] }
];
IpconfigPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-ipconfig',
        template: _raw_loader_ipconfig_page_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_ipconfig_page_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], IpconfigPage);



/***/ }),

/***/ "ynWL":
/*!************************************!*\
  !*** ./src/app/app.component.scss ***!
  \************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".menu-custom-header {\n  background: linear-gradient(0deg, #0f0f0f 0%, #4c4646 100%, #7b1e1e 100%);\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy4uL2FwcC5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNJLHlFQUFBO0FBQ0oiLCJmaWxlIjoiYXBwLmNvbXBvbmVudC5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLm1lbnUtY3VzdG9tLWhlYWRlciB7XG4gICAgYmFja2dyb3VuZDogbGluZWFyLWdyYWRpZW50KDBkZWcsICMwZjBmMGYgMCUsICM0YzQ2NDYgMTAwJSwgIzdiMWUxZSAxMDAlKTtcbn1cbiJdfQ== */");

/***/ }),

/***/ "zUnb":
/*!*********************!*\
  !*** ./src/main.ts ***!
  \*********************/
/*! no exports provided */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/platform-browser-dynamic */ "a3Wg");
/* harmony import */ var _app_app_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./app/app.module */ "ZAI4");
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./environments/environment */ "AytR");




if (_environments_environment__WEBPACK_IMPORTED_MODULE_3__["environment"].production) {
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["enableProdMode"])();
}
Object(_angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_1__["platformBrowserDynamic"])().bootstrapModule(_app_app_module__WEBPACK_IMPORTED_MODULE_2__["AppModule"])
    .catch(err => console.log(err));


/***/ }),

/***/ "zn8P":
/*!******************************************************!*\
  !*** ./$$_lazy_route_resource lazy namespace object ***!
  \******************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

function webpackEmptyAsyncContext(req) {
	// Here Promise.resolve().then() is used instead of new Promise() to prevent
	// uncaught exception popping up in devtools
	return Promise.resolve().then(function() {
		var e = new Error("Cannot find module '" + req + "'");
		e.code = 'MODULE_NOT_FOUND';
		throw e;
	});
}
webpackEmptyAsyncContext.keys = function() { return []; };
webpackEmptyAsyncContext.resolve = webpackEmptyAsyncContext;
module.exports = webpackEmptyAsyncContext;
webpackEmptyAsyncContext.id = "zn8P";

/***/ })

},[[0,"runtime","vendor"]]]);
//# sourceMappingURL=main.js.map
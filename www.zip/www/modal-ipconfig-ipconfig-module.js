(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["modal-ipconfig-ipconfig-module"],{

/***/ "Wpt+":
/*!***********************************************************!*\
  !*** ./src/app/modal/ipconfig/ipconfig-routing.module.ts ***!
  \***********************************************************/
/*! exports provided: IpconfigPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "IpconfigPageRoutingModule", function() { return IpconfigPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _ipconfig_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./ipconfig.page */ "xG7c");




const routes = [
    {
        path: '',
        component: _ipconfig_page__WEBPACK_IMPORTED_MODULE_3__["IpconfigPage"]
    }
];
let IpconfigPageRoutingModule = class IpconfigPageRoutingModule {
};
IpconfigPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], IpconfigPageRoutingModule);



/***/ }),

/***/ "Wt6d":
/*!***************************************************!*\
  !*** ./src/app/modal/ipconfig/ipconfig.module.ts ***!
  \***************************************************/
/*! exports provided: IpconfigPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "IpconfigPageModule", function() { return IpconfigPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "ofXK");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "3Pt+");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var _ipconfig_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./ipconfig-routing.module */ "Wpt+");
/* harmony import */ var _ipconfig_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./ipconfig.page */ "xG7c");







let IpconfigPageModule = class IpconfigPageModule {
};
IpconfigPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _ipconfig_routing_module__WEBPACK_IMPORTED_MODULE_5__["IpconfigPageRoutingModule"]
        ],
        declarations: [_ipconfig_page__WEBPACK_IMPORTED_MODULE_6__["IpconfigPage"]]
    })
], IpconfigPageModule);



/***/ })

}]);
//# sourceMappingURL=modal-ipconfig-ipconfig-module.js.map
(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["default~home-home-module~modal-modals-ms-teams-module"],{

/***/ "4L1u":
/*!*************************************************!*\
  !*** ./src/app/modal/modals/ms-teams.page.scss ***!
  \*************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".text-center {\n  text-align: center;\n  margin: 0 auto;\n}\n\nion-range {\n  --bar-background: transparent;\n  --background: transparent;\n  --background-activated: transparent;\n  --background-focused: transparent;\n  --background-hover: transparent;\n  --background-activated-opacity: 0.12;\n  --background-focused-opacity: 0.15;\n  --background-hover-opacity: 0.04;\n}\n\nion-toolbar {\n  --background: transparent !important;\n  --border-color: transparent;\n  height: 90px;\n}\n\n.text-left {\n  text-align: left;\n}\n\n.text-right {\n  text-align: right;\n}\n\n.white-text {\n  color: white;\n}\n\n.text-bold {\n  font-weight: bold;\n}\n\n.modal-control-icons .control-icon {\n  font-size: 50px !important;\n}\n\n.netflix-poster img {\n  width: 70%;\n}\n\n.pp-boxes div {\n  margin: 10px;\n  background: #327eb3;\n  padding: 20px;\n  height: 80px;\n  border-radius: 10px;\n}\n\n.pp-boxes div.blank {\n  background: transparent;\n}\n\n.pp-boxes div p {\n  margin: 0;\n  position: relative;\n  top: 50%;\n  transform: translateY(-50%);\n}\n\n.modal-toolbar {\n  padding: 20px;\n}\n\n.modal-toolbar ion-item ion-label {\n  font-weight: bold;\n  color: #969696;\n}\n\n.modal-toolbar ion-title {\n  padding: 30px !important;\n}\n\n.modal-toolbar ion-title p {\n  margin: 0;\n  padding: 0;\n  font-size: 28px;\n}\n\n.modal-toolbar ion-button {\n  padding: 0px !important;\n  margin-top: 10px;\n}\n\n.modal-toolbar ion-button .button {\n  font-size: 20px;\n}\n\nion-content {\n  --offset-bottom: auto !important;\n  --overflow: hidden;\n  overflow: auto;\n}\n\nion-content::-webkit-scrollbar {\n  display: none;\n}\n\n.toolbar-background {\n  border: 0 !important;\n}\n\n.touch-icon {\n  width: 100px;\n}\n\n.custom-toolbar {\n  padding: 20px;\n  padding-top: 14px !important;\n}\n\n.custom-toolbar .toolbar-container {\n  padding: 50px !important;\n}\n\n.modal-title {\n  font-size: 24px;\n  margin: 20px 0px 20px 0px;\n}\n\n.modal-sub-title {\n  font-size: 18px;\n  margin: 20px 0px 20px 0px;\n}\n\n.sc-ion-modal-md-h {\n  height: 100% !important;\n  bottom: 0;\n  width: 100%;\n  margin: 0 auto;\n  margin-top: 0px;\n}\n\n.sc-ion-modal-md-h:first-of-type {\n  --backdrop-opacity: var(--ion-backdrop-opacity, 0.7);\n}\n\n.sc-ion-modal-md-h .modal-wrapper {\n  margin-top: 150px;\n  border-radius: 40px;\n  border-bottom-left-radius: 0;\n  border-bottom-right-radius: 0;\n}\n\n.sc-ion-modal-ios-h {\n  height: 100% !important;\n  bottom: 0;\n  width: 100%;\n  margin: 0 auto;\n  margin-top: 0px;\n}\n\n.sc-ion-modal-ios-h:first-of-type {\n  --backdrop-opacity: var(--ion-backdrop-opacity, 0.7);\n}\n\n.sc-ion-modal-ios-h .modal-wrapper {\n  margin-top: 150px;\n  border-radius: 40px;\n  border-bottom-left-radius: 0;\n  border-bottom-right-radius: 0;\n}\n\n.the-range-slider-container {\n  margin: 0;\n  padding: 0;\n}\n\n.ion-input-label {\n  font-weight: bold;\n  color: #969696 !important;\n}\n\nion-item::part(native) {\n  background-color: transparent;\n  padding: 0;\n}\n\nion-item::part(native) .item-inner {\n  display: none !important;\n  padding: 0;\n  border: 0;\n}\n\nmain::part(scroll) {\n  padding: 20px !important;\n}\n\n:root ion-range {\n  --bar-background: transparent;\n  --background: transparent;\n  --background-activated: transparent;\n  --background-focused: transparent;\n  --background-hover: transparent;\n  --background-activated-opacity: 0.12;\n  --background-focused-opacity: 0.15;\n  --background-hover-opacity: 0.04;\n}\n\n:root ion-toolbar ion-title {\n  padding: 0;\n}\n\n:root ion-toolbar .toolbar-container {\n  padding: 50px;\n}\n\n:root ion-toolbar:last-child .toolbar-background {\n  box-shadow: var(--box-shadow);\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uL21zLXRlYW1zLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNJLGtCQUFBO0VBQ0EsY0FBQTtBQUNKOztBQUNBO0VBQ0ksNkJBQUE7RUFFQSx5QkFBQTtFQUNBLG1DQUFBO0VBQ0EsaUNBQUE7RUFDQSwrQkFBQTtFQUNBLG9DQUFBO0VBQ0Esa0NBQUE7RUFDQSxnQ0FBQTtBQUNKOztBQUNBO0VBQ0ksb0NBQUE7RUFDQSwyQkFBQTtFQUNBLFlBQUE7QUFFSjs7QUFBQTtFQUNJLGdCQUFBO0FBR0o7O0FBREE7RUFDSSxpQkFBQTtBQUlKOztBQUZBO0VBQ0ksWUFBQTtBQUtKOztBQUhBO0VBQ0ksaUJBQUE7QUFNSjs7QUFISTtFQUNJLDBCQUFBO0FBTVI7O0FBRkk7RUFDSSxVQUFBO0FBS1I7O0FBREk7RUFDSSxZQUFBO0VBQ0EsbUJBQUE7RUFDQSxhQUFBO0VBQ0EsWUFBQTtFQUNBLG1CQUFBO0FBSVI7O0FBSFE7RUFDSSx1QkFBQTtBQUtaOztBQUhRO0VBQ0ksU0FBQTtFQUNBLGtCQUFBO0VBQ0EsUUFBQTtFQUNBLDJCQUFBO0FBS1o7O0FBREE7RUFRSSxhQUFBO0FBSEo7O0FBSFE7RUFDSSxpQkFBQTtFQUNBLGNBQUE7QUFLWjs7QUFBSTtFQUNJLHdCQUFBO0FBRVI7O0FBRFE7RUFDSSxTQUFBO0VBQ0EsVUFBQTtFQUNBLGVBQUE7QUFHWjs7QUFBSTtFQUlJLHVCQUFBO0VBQ0EsZ0JBQUE7QUFEUjs7QUFIUTtFQUNJLGVBQUE7QUFLWjs7QUFDQTtFQUNJLGdDQUFBO0VBQ0Esa0JBQUE7RUFDQSxjQUFBO0FBRUo7O0FBREk7RUFDSSxhQUFBO0FBR1I7O0FBQ0E7RUFDSSxvQkFBQTtBQUVKOztBQUFBO0VBQ0ksWUFBQTtBQUdKOztBQURBO0VBRUksYUFBQTtFQUNBLDRCQUFBO0FBR0o7O0FBRkk7RUFDSSx3QkFBQTtBQUlSOztBQURBO0VBQ0ksZUFBQTtFQUNBLHlCQUFBO0FBSUo7O0FBRkE7RUFDSSxlQUFBO0VBQ0EseUJBQUE7QUFLSjs7QUFIQTtFQUlJLHVCQUFBO0VBQ0EsU0FBQTtFQUNBLFdBQUE7RUFDQSxjQUFBO0VBRUEsZUFBQTtBQUVKOztBQVZJO0VBQ0ksb0RBQUE7QUFZUjs7QUFKSTtFQUNJLGlCQUFBO0VBQ0EsbUJBQUE7RUFDQSw0QkFBQTtFQUNBLDZCQUFBO0FBTVI7O0FBSEE7RUFJSSx1QkFBQTtFQUNBLFNBQUE7RUFDQSxXQUFBO0VBQ0EsY0FBQTtFQUVBLGVBQUE7QUFFSjs7QUFWSTtFQUNJLG9EQUFBO0FBWVI7O0FBSkk7RUFDSSxpQkFBQTtFQUNBLG1CQUFBO0VBQ0EsNEJBQUE7RUFDQSw2QkFBQTtBQU1SOztBQUhBO0VBQ0ksU0FBQTtFQUNBLFVBQUE7QUFNSjs7QUFKQTtFQUNJLGlCQUFBO0VBQ0EseUJBQUE7QUFPSjs7QUFKQTtFQU1JLDZCQUFBO0VBQ0EsVUFBQTtBQUVKOztBQVJJO0VBQ0ksd0JBQUE7RUFDQSxVQUFBO0VBQ0EsU0FBQTtBQVVSOztBQUxBO0VBQ0ksd0JBQUE7QUFRSjs7QUFISTtFQUNJLDZCQUFBO0VBRUEseUJBQUE7RUFDQSxtQ0FBQTtFQUNBLGlDQUFBO0VBQ0EsK0JBQUE7RUFDQSxvQ0FBQTtFQUNBLGtDQUFBO0VBQ0EsZ0NBQUE7QUFLUjs7QUFGUTtFQUNJLFVBQUE7QUFJWjs7QUFGUTtFQUNJLGFBQUE7QUFJWjs7QUFEWTtFQUNJLDZCQUFBO0FBR2hCIiwiZmlsZSI6Im1zLXRlYW1zLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi50ZXh0LWNlbnRlciB7XG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xuICAgIG1hcmdpbjogMCBhdXRvO1xufVxuaW9uLXJhbmdlIHtcbiAgICAtLWJhci1iYWNrZ3JvdW5kOiB0cmFuc3BhcmVudDtcblxuICAgIC0tYmFja2dyb3VuZDogdHJhbnNwYXJlbnQ7XG4gICAgLS1iYWNrZ3JvdW5kLWFjdGl2YXRlZDogdHJhbnNwYXJlbnQ7XG4gICAgLS1iYWNrZ3JvdW5kLWZvY3VzZWQ6IHRyYW5zcGFyZW50O1xuICAgIC0tYmFja2dyb3VuZC1ob3ZlcjogdHJhbnNwYXJlbnQ7XG4gICAgLS1iYWNrZ3JvdW5kLWFjdGl2YXRlZC1vcGFjaXR5OiAwLjEyO1xuICAgIC0tYmFja2dyb3VuZC1mb2N1c2VkLW9wYWNpdHk6IDAuMTU7XG4gICAgLS1iYWNrZ3JvdW5kLWhvdmVyLW9wYWNpdHk6IDAuMDQ7XG59XG5pb24tdG9vbGJhciB7XG4gICAgLS1iYWNrZ3JvdW5kOiB0cmFuc3BhcmVudCAhaW1wb3J0YW50O1xuICAgIC0tYm9yZGVyLWNvbG9yOiB0cmFuc3BhcmVudDtcbiAgICBoZWlnaHQ6IDkwcHg7XG59XG4udGV4dC1sZWZ0IHtcbiAgICB0ZXh0LWFsaWduOiBsZWZ0O1xufVxuLnRleHQtcmlnaHQge1xuICAgIHRleHQtYWxpZ246IHJpZ2h0O1xufVxuLndoaXRlLXRleHQge1xuICAgIGNvbG9yOiB3aGl0ZTtcbn1cbi50ZXh0LWJvbGQge1xuICAgIGZvbnQtd2VpZ2h0OiBib2xkO1xufVxuLm1vZGFsLWNvbnRyb2wtaWNvbnMge1xuICAgIC5jb250cm9sLWljb24ge1xuICAgICAgICBmb250LXNpemU6IDUwcHggIWltcG9ydGFudDtcbiAgICB9XG59XG4ubmV0ZmxpeC1wb3N0ZXIge1xuICAgIGltZyB7XG4gICAgICAgIHdpZHRoOiA3MCU7XG4gICAgfVxufVxuLnBwLWJveGVzIHtcbiAgICBkaXYge1xuICAgICAgICBtYXJnaW46IDEwcHg7XG4gICAgICAgIGJhY2tncm91bmQ6IHJnYig1MCwgMTI2LCAxNzkpO1xuICAgICAgICBwYWRkaW5nOiAyMHB4O1xuICAgICAgICBoZWlnaHQ6IDgwcHg7XG4gICAgICAgIGJvcmRlci1yYWRpdXM6IDEwcHg7XG4gICAgICAgICYuYmxhbmsge1xuICAgICAgICAgICAgYmFja2dyb3VuZDogdHJhbnNwYXJlbnQ7XG4gICAgICAgIH1cbiAgICAgICAgcCB7XG4gICAgICAgICAgICBtYXJnaW46IDA7XG4gICAgICAgICAgICBwb3NpdGlvbjogcmVsYXRpdmU7XG4gICAgICAgICAgICB0b3A6IDUwJTtcbiAgICAgICAgICAgIHRyYW5zZm9ybTogdHJhbnNsYXRlWSgtNTAlKTtcbiAgICAgICAgfVxuICAgIH1cbn1cbi5tb2RhbC10b29sYmFyIHtcbiAgICBpb24taXRlbSB7XG4gICAgICAgIGlvbi1sYWJlbCB7XG4gICAgICAgICAgICBmb250LXdlaWdodDogYm9sZDtcbiAgICAgICAgICAgIGNvbG9yOiAjOTY5Njk2O1xuICAgICAgICB9XG4gICAgfVxuICAgIC8vIGJhY2tncm91bmQ6IGxpbmVhci1ncmFkaWVudCgxODBkZWcsICM0MjQyNDIgMCUsICMxYjFiMWIgMTAwJSwgIzFiMWIxYiAxMDAlKTtcbiAgICBwYWRkaW5nOiAyMHB4O1xuICAgIGlvbi10aXRsZSB7XG4gICAgICAgIHBhZGRpbmc6IDMwcHggIWltcG9ydGFudDtcbiAgICAgICAgcCB7XG4gICAgICAgICAgICBtYXJnaW46IDA7XG4gICAgICAgICAgICBwYWRkaW5nOiAwO1xuICAgICAgICAgICAgZm9udC1zaXplOiAyOHB4O1xuICAgICAgICB9XG4gICAgfVxuICAgIGlvbi1idXR0b24ge1xuICAgICAgICAuYnV0dG9uIHtcbiAgICAgICAgICAgIGZvbnQtc2l6ZTogMjBweDtcbiAgICAgICAgfVxuICAgICAgICBwYWRkaW5nOiAwcHggIWltcG9ydGFudDtcbiAgICAgICAgbWFyZ2luLXRvcDogMTBweDtcbiAgICB9XG59XG5pb24tY29udGVudCB7XG4gICAgLS1vZmZzZXQtYm90dG9tOiBhdXRvICFpbXBvcnRhbnQ7XG4gICAgLS1vdmVyZmxvdzogaGlkZGVuO1xuICAgIG92ZXJmbG93OiBhdXRvO1xuICAgICY6Oi13ZWJraXQtc2Nyb2xsYmFyIHtcbiAgICAgICAgZGlzcGxheTogbm9uZTtcbiAgICB9XG59XG5cbi50b29sYmFyLWJhY2tncm91bmQge1xuICAgIGJvcmRlcjogMCAhaW1wb3J0YW50O1xufVxuLnRvdWNoLWljb24ge1xuICAgIHdpZHRoOiAxMDBweDtcbn1cbi5jdXN0b20tdG9vbGJhciB7XG4gICAgLy8gYmFja2dyb3VuZDogIzEwMTAxMDtcbiAgICBwYWRkaW5nOiAyMHB4O1xuICAgIHBhZGRpbmctdG9wOiAxNHB4ICFpbXBvcnRhbnQ7XG4gICAgLnRvb2xiYXItY29udGFpbmVyIHtcbiAgICAgICAgcGFkZGluZzogNTBweCAhaW1wb3J0YW50O1xuICAgIH1cbn1cbi5tb2RhbC10aXRsZSB7XG4gICAgZm9udC1zaXplOiAyNHB4O1xuICAgIG1hcmdpbjogMjBweCAwcHggMjBweCAwcHg7XG59XG4ubW9kYWwtc3ViLXRpdGxlIHtcbiAgICBmb250LXNpemU6IDE4cHg7XG4gICAgbWFyZ2luOiAyMHB4IDBweCAyMHB4IDBweDtcbn1cbi5zYy1pb24tbW9kYWwtbWQtaCB7XG4gICAgJjpmaXJzdC1vZi10eXBlIHtcbiAgICAgICAgLS1iYWNrZHJvcC1vcGFjaXR5OiB2YXIoLS1pb24tYmFja2Ryb3Atb3BhY2l0eSwgMC43KTtcbiAgICB9XG4gICAgaGVpZ2h0OiAxMDAlICFpbXBvcnRhbnQ7XG4gICAgYm90dG9tOiAwO1xuICAgIHdpZHRoOiAxMDAlO1xuICAgIG1hcmdpbjogMCBhdXRvO1xuXG4gICAgbWFyZ2luLXRvcDogMHB4O1xuICAgIC5tb2RhbC13cmFwcGVyIHtcbiAgICAgICAgbWFyZ2luLXRvcDogMTUwcHg7XG4gICAgICAgIGJvcmRlci1yYWRpdXM6IDQwcHg7XG4gICAgICAgIGJvcmRlci1ib3R0b20tbGVmdC1yYWRpdXM6IDA7XG4gICAgICAgIGJvcmRlci1ib3R0b20tcmlnaHQtcmFkaXVzOiAwO1xuICAgIH1cbn1cbi5zYy1pb24tbW9kYWwtaW9zLWgge1xuICAgICY6Zmlyc3Qtb2YtdHlwZSB7XG4gICAgICAgIC0tYmFja2Ryb3Atb3BhY2l0eTogdmFyKC0taW9uLWJhY2tkcm9wLW9wYWNpdHksIDAuNyk7XG4gICAgfVxuICAgIGhlaWdodDogMTAwJSAhaW1wb3J0YW50O1xuICAgIGJvdHRvbTogMDtcbiAgICB3aWR0aDogMTAwJTtcbiAgICBtYXJnaW46IDAgYXV0bztcblxuICAgIG1hcmdpbi10b3A6IDBweDtcbiAgICAubW9kYWwtd3JhcHBlciB7XG4gICAgICAgIG1hcmdpbi10b3A6IDE1MHB4O1xuICAgICAgICBib3JkZXItcmFkaXVzOiA0MHB4O1xuICAgICAgICBib3JkZXItYm90dG9tLWxlZnQtcmFkaXVzOiAwO1xuICAgICAgICBib3JkZXItYm90dG9tLXJpZ2h0LXJhZGl1czogMDtcbiAgICB9XG59XG4udGhlLXJhbmdlLXNsaWRlci1jb250YWluZXIge1xuICAgIG1hcmdpbjogMDtcbiAgICBwYWRkaW5nOiAwO1xufVxuLmlvbi1pbnB1dC1sYWJlbCB7XG4gICAgZm9udC13ZWlnaHQ6IGJvbGQ7XG4gICAgY29sb3I6ICM5Njk2OTYgIWltcG9ydGFudDtcbn1cblxuaW9uLWl0ZW06OnBhcnQobmF0aXZlKSB7XG4gICAgLml0ZW0taW5uZXIge1xuICAgICAgICBkaXNwbGF5OiBub25lICFpbXBvcnRhbnQ7XG4gICAgICAgIHBhZGRpbmc6IDA7XG4gICAgICAgIGJvcmRlcjogMDtcbiAgICB9XG4gICAgYmFja2dyb3VuZC1jb2xvcjogdHJhbnNwYXJlbnQ7XG4gICAgcGFkZGluZzogMDtcbn1cbm1haW46OnBhcnQoc2Nyb2xsKSB7XG4gICAgcGFkZGluZzogMjBweCAhaW1wb3J0YW50O1xuICAgIC8vb3ZlcmZsb3c6IGhpZGRlbiBpICFpbXBvcnRhbnQ7XG59XG5cbjpyb290IHtcbiAgICBpb24tcmFuZ2Uge1xuICAgICAgICAtLWJhci1iYWNrZ3JvdW5kOiB0cmFuc3BhcmVudDtcblxuICAgICAgICAtLWJhY2tncm91bmQ6IHRyYW5zcGFyZW50O1xuICAgICAgICAtLWJhY2tncm91bmQtYWN0aXZhdGVkOiB0cmFuc3BhcmVudDtcbiAgICAgICAgLS1iYWNrZ3JvdW5kLWZvY3VzZWQ6IHRyYW5zcGFyZW50O1xuICAgICAgICAtLWJhY2tncm91bmQtaG92ZXI6IHRyYW5zcGFyZW50O1xuICAgICAgICAtLWJhY2tncm91bmQtYWN0aXZhdGVkLW9wYWNpdHk6IDAuMTI7XG4gICAgICAgIC0tYmFja2dyb3VuZC1mb2N1c2VkLW9wYWNpdHk6IDAuMTU7XG4gICAgICAgIC0tYmFja2dyb3VuZC1ob3Zlci1vcGFjaXR5OiAwLjA0O1xuICAgIH1cbiAgICBpb24tdG9vbGJhciB7XG4gICAgICAgIGlvbi10aXRsZSB7XG4gICAgICAgICAgICBwYWRkaW5nOiAwO1xuICAgICAgICB9XG4gICAgICAgIC50b29sYmFyLWNvbnRhaW5lciB7XG4gICAgICAgICAgICBwYWRkaW5nOiA1MHB4O1xuICAgICAgICB9XG4gICAgICAgICY6bGFzdC1jaGlsZCB7XG4gICAgICAgICAgICAudG9vbGJhci1iYWNrZ3JvdW5kIHtcbiAgICAgICAgICAgICAgICBib3gtc2hhZG93OiB2YXIoLS1ib3gtc2hhZG93KTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgIH1cbn1cbiJdfQ== */");

/***/ }),

/***/ "Ho7z":
/*!***************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/modal/modals/ms-teams.page.html ***!
  \***************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\n  <ion-toolbar class=\"modal-toolbar\">\n    <ion-buttons slot=\"start\">\n      <ion-button fill=\"clear\" (click)=\"dismiss();\">\n        <ion-icon class=\"white-text\" name=\"chevron-down-outline\"></ion-icon>\n      </ion-button>\n    </ion-buttons>\n    <ion-title class=\"text-center\">\n      <span *ngIf=\"specificAppData.appName == 'Microsoft Teams'\"\n        ><img\n          style=\"width: 50px; vertical-align: middle\"\n          src=\"assets/images/TEAMS-icon.png\"\n        />{{specificAppData.appName}}</span\n      >\n      <span *ngIf=\"specificAppData.appName == 'PowerPoint'\"\n        ><img\n          style=\"width: 50px; vertical-align: middle\"\n          src=\"assets/images/POWERPOINT-icon.png\"\n        />{{specificAppData.appName}}</span\n      >\n      <span *ngIf=\"specificAppData.appName == 'Netflix'\"\n        ><img\n          style=\"width: 50px; vertical-align: middle\"\n          src=\"assets/images/NETFLIX-icon.png\"\n        />{{specificAppData.appName}}</span\n      >\n      <span *ngIf=\"specificAppData.appName == 'Spotify'\"\n        ><img\n          style=\"width: 50px; vertical-align: middle\"\n          src=\"assets/images/SPOTIFY-icon.png\"\n        />{{specificAppData.appName}}</span\n      >\n    </ion-title>\n    <ion-buttons slot=\"end\">\n      <ion-button fill=\"clear\" (click)=\"dismiss();\"> </ion-button>\n    </ion-buttons>\n  </ion-toolbar>\n</ion-header>\n<ion-content class=\"no-scroll\">\n  <div *ngIf=\"specificAppData.appName == 'PowerPoint'\">\n    <ion-row class=\"text-center m-t-20\">\n      <ion-col class=\"touch-icon\">\n        <div class=\"modal-title\">{{specificAppData.title}}</div>\n      </ion-col>\n    </ion-row>\n    <ion-row class=\"text-center pp-boxes m-t-20\">\n      <ion-col offset-4>\n        <div (click)=\"ppPlayFromStart();\"><p>Play from start</p></div>\n      </ion-col>\n      <ion-col offset-4>\n        <div (click)=\"ppPlayFromCurrentSlide();\">\n          <p>Play from current slide</p>\n        </div>\n      </ion-col>\n    </ion-row>\n    <ion-row class=\"text-center pp-boxes\">\n      <ion-col offset-4>\n        <div (click)=\"ppSave();\"><p>Save</p></div>\n      </ion-col>\n      <ion-col offset-4>\n        <div (click)=\"ppPrint();\"><p>Print</p></div>\n      </ion-col>\n    </ion-row>\n    <ion-row class=\"text-center pp-boxes\">\n      <ion-col offset-4>\n        <div (click)=\"ppNewSlide();\"><p>New slide</p></div>\n      </ion-col>\n      <ion-col offset-4>\n        <div (click)=\"ppDuplicateSlide();\"><p>Duplicate slide</p></div>\n      </ion-col>\n    </ion-row>\n    <ion-row class=\"text-center pp-boxes\">\n      <ion-col offset-4>\n        <div class=\"blank\"><img src=\"assets/images/add-icon.png\" /></div\n      ></ion-col>\n    </ion-row>\n  </div>\n  <div *ngIf=\"specificAppData.appName == 'Microsoft Teams'\">\n    <ion-row class=\"m-t-10\">\n      <ion-col size=\"12\" class=\"text-center\">\n        <p class=\"m-b-20 p-l-0 p-r-0 p-t-0 p-b-0 text-bold\">\n          {{specificAppData.title}}\n        </p>\n        <!-- <p>02:41</p> -->\n      </ion-col>\n    </ion-row>\n    <ion-row class=\"text-center m-t-30\">\n      <ion-col size=\"2\"> </ion-col>\n      <ion-col size=\"4\">\n        <img\n          class=\"touch-icon\"\n          *ngIf=\"currState.hand == 'false' || !currState.hand\"\n          src=\"assets/images/microsoft-teams/raise-hand.png\"\n          (click)=\"switchHand();\"\n        />\n        <img\n          class=\"touch-icon\"\n          *ngIf=\"currState.hand == 'true'\"\n          src=\"assets/images/microsoft-teams/raise-hand-on.png\"\n          (click)=\"switchHand();\"\n        />\n        <p *ngIf=\"currState.hand == 'false' || !currState.hand \">Raise Hand</p>\n        <p *ngIf=\"currState.hand == 'true'\">Lower Hand</p>\n      </ion-col>\n      <ion-col size=\"4\">\n        <img\n          class=\"touch-icon\"\n          src=\"assets/images/microsoft-teams/leave-meeting.png\"\n          (click)=\"leaveMeeting();\"\n        />\n        <p>Leave Meeting</p>\n      </ion-col>\n      <ion-col size=\"2\"> </ion-col>\n    </ion-row>\n    <ion-row class=\"text-center\">\n      <ion-col size=\"2\"> </ion-col>\n      <ion-col size=\"4\">\n        <img\n          class=\"touch-icon\"\n          *ngIf=\"currState.mic == 'false' || !currState.mic\"\n          src=\"assets/images/microsoft-teams/mute-mic.png\"\n          (click)=\"switchMic();\"\n        />\n        <img\n          class=\"touch-icon\"\n          *ngIf=\"currState.mic == 'true'\"\n          src=\"assets/images/microsoft-teams/unmute-mic.png\"\n          (click)=\"switchMic();\"\n        />\n        <p *ngIf=\"currState.mic == 'true'\">Unmute Mic</p>\n        <p *ngIf=\"currState.mic == 'false'  || !currState.mic \">Mute Mic</p>\n      </ion-col>\n      <ion-col size=\"4\">\n        <img\n          class=\"touch-icon\"\n          *ngIf=\"currState.camera == 'true'\"\n          src=\"assets/images/microsoft-teams/camera-on.png\"\n          (click)=\"switchCamera();\"\n        />\n        <img\n          class=\"touch-icon\"\n          *ngIf=\"currState.camera == 'false'  || !currState.camera\"\n          src=\"assets/images/microsoft-teams/camera-off.png\"\n          (click)=\"switchCamera();\"\n        />\n        <p *ngIf=\"currState.camera == 'true'\">Hide Camera</p>\n        <p *ngIf=\"currState.camera == 'false'  || !currState.camera\">\n          Show Camera\n        </p>\n      </ion-col>\n      <ion-col size=\"2\"></ion-col>\n    </ion-row>\n    <ion-row class=\"m-t-20\">\n      <ion-col size=\"1\"></ion-col>\n      <ion-col size=\"10\" class=\"\">\n        <ion-item>\n          <ion-range value=\"20\">\n            <ion-icon\n              slot=\"start\"\n              size=\"medium\"\n              name=\"volume-low-outline\"\n            ></ion-icon>\n            <ion-icon slot=\"end\" name=\"volume-high-outline\"></ion-icon>\n          </ion-range>\n        </ion-item>\n      </ion-col>\n      <ion-col size=\"1\"></ion-col>\n    </ion-row>\n  </div>\n  <div *ngIf=\"specificAppData.appName == 'Netflix'\" class=\"modal-control-icons\">\n    <ion-row class=\"text-center\">\n      <ion-col>\n        <div class=\"netflix-poster\">\n          <img src=\"assets/images/NETFLIX.jpg\" />\n        </div>\n      </ion-col>\n    </ion-row>\n    <ion-row class=\"text-center m-t-30\">\n      <ion-col size=\"4\" class=\"text-right\">\n        <img\n          class=\"m-t-8\"\n          (click)=\"netflixRewind();\"\n          src=\"assets/images/back-30.png\"\n        />\n      </ion-col>\n      <ion-col size=\"4\">\n        <img\n          *ngIf=\"netflixPlay == 'true'\"\n          (click)=\"netflixPause();\"\n          src=\"assets/images/netflix-pause.png\"\n        />\n        <img\n          *ngIf=\"netflixPlay == 'false'\"\n          (click)=\"netflixPause();\"\n          src=\"assets/images/netflix-pause.png\"\n        />\n      </ion-col>\n      <ion-col size=\"4\" class=\"text-left\">\n        <img\n          class=\"m-t-10\"\n          (click)=\"netflixStop();\"\n          src=\"assets/images/netflix-stop.png\"\n        />\n      </ion-col>\n    </ion-row>\n  </div>\n  <div *ngIf=\"specificAppData.appName == 'Spotify'\">\n    <ion-row class=\"text-center\">\n      <ion-col>\n        <div class=\"modal-title\">Title</div>\n        <div class=\"modal-sub-title\">Sub title</div>\n      </ion-col>\n    </ion-row>\n    <ion-row class=\"text-center\">\n      <ion-col>\n        <div class=\"netflix-poster\">\n          <img src=\"assets/images/SPOTIFY.jpg\" />\n        </div>\n      </ion-col>\n    </ion-row>\n    <ion-row class=\"text-center\">\n      <ion-col offset-4>\n        <div (click)=\"spotifyShuffle();\">\n          <img src=\"assets/images/rewind-30-icon.png\" />\n        </div>\n      </ion-col>\n      <ion-col offset-4>\n        <div (click)=\"spotifyPlay();\">\n          <img width=\"30px\" src=\"assets/images/pause.png\" />\n        </div>\n      </ion-col>\n      <ion-col offset-4>\n        <div (click)=\"spotifyStop();\"><img src=\"assets/images/stop.png\" /></div>\n      </ion-col>\n    </ion-row>\n  </div>\n</ion-content>\n");

/***/ }),

/***/ "qdIs":
/*!***********************************************!*\
  !*** ./src/app/modal/modals/ms-teams.page.ts ***!
  \***********************************************/
/*! exports provided: MsTeamsPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MsTeamsPage", function() { return MsTeamsPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_ms_teams_page_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./ms-teams.page.html */ "Ho7z");
/* harmony import */ var _ms_teams_page_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./ms-teams.page.scss */ "4L1u");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/common/http */ "tk/3");
/* harmony import */ var _services_api_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../services/api.service */ "H+bZ");
/* harmony import */ var _global_constants__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../global-constants */ "TqJ6");
/* harmony import */ var _services_current_ip_port_service__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../services/current-ip-port.service */ "kKPw");
/* harmony import */ var _services_cleandata_service__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../../services/cleandata.service */ "oEKA");
/* harmony import */ var _services_currently_viewing_service__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../../services/currently-viewing.service */ "1Aq0");











let MsTeamsPage = class MsTeamsPage {
    constructor(currViewCheck, cleanData, currentIPPORT, modalController, httpClient, apiService, globals) {
        this.currViewCheck = currViewCheck;
        this.cleanData = cleanData;
        this.currentIPPORT = currentIPPORT;
        this.modalController = modalController;
        this.httpClient = httpClient;
        this.apiService = apiService;
        this.globals = globals;
        this.mic = localStorage.getItem("teamsMic");
        this.camera = localStorage.getItem("teamsCamera");
        this.hand = localStorage.getItem("teamsHand");
        this.netflixPlay = localStorage.getItem("netflixPlay");
        this.commandData = {
            appId: '',
            windowId: '',
            command: ''
        };
        this.commandDataSend = {};
        this.specificAppData = {};
        this.specificAppWindowData = [];
    }
    ;
    dismiss() {
        this.modalController.dismiss({
            'dismissed': true
        });
    }
    setCurrentAppLocalStorage(lsName, data) {
        localStorage.setItem(lsName, JSON.stringify(data));
    }
    getCurrentAppLocalStorage(lsName) {
        return JSON.parse(localStorage.getItem(lsName));
    }
    // Get window specific data
    getSpecificApp(app) {
        if (app.appType == 'single') {
            this.currViewCheck.checkCurrentlyViewing(app, 'single');
        }
        if (app.appType == 'multiple') {
            this.currViewCheck.checkCurrentlyViewing(app, 'multiple');
        }
        if (this.getCurrentAppLocalStorage('appID' + app.appID + '-' + app.windowsID) == null) {
            this.setCurrentAppLocalStorage('appID' + app.appID + '-' + app.windowsID, app);
            this.currState = this.getCurrentAppLocalStorage('appID' + app.appID + '-' + app.windowsID);
        }
        else {
            this.currState = this.getCurrentAppLocalStorage('appID' + app.appID + '-' + app.windowsID);
        }
        this.currentIPPORT.setViewingNow(app);
        this.globals.APPS_AVAILABLE_SINGULAR.forEach((key, value) => {
            if (key[0].appName == app.appName) {
                this.specificAppData = key[0];
                key[0].currentlyViewing = true;
                this.globals.APP_CURRENTLY_VIEWING = key[0];
            }
        });
        this.globals.APPS_AVAILABLE_MULTIPLE.forEach((key, value) => {
            if (key[0].appName == app.appName) {
                this.specificAppData = key[0];
                this.globals.APP_CURRENTLY_VIEWING = key[0];
            }
        });
    }
    doExecuteCommand(params) {
        this.apiService.executeCommand(params).subscribe((data) => {
        });
    }
    //Teams
    leaveMeeting() {
        var myOpt = JSON.parse(localStorage.getItem('currentAppID'));
        this.commandDataSend = {
            appId: this.commandData.appId,
            windowId: this.commandData.windowId,
            command: "Leave"
        };
        myOpt.appCommand = "Leave";
        this.doExecuteCommand(myOpt);
    }
    switchMic() {
        if (this.currState.mic == "false" || !this.currState.mic) {
            this.currState.mic = "true";
            this.setCurrentAppLocalStorage('appID' + this.currState.appID + '-' + this.currState.windowsID, this.currState);
        }
        else {
            this.currState.mic = "false";
            this.setCurrentAppLocalStorage('appID' + this.currState.appID + '-' + this.currState.windowsID, this.currState);
        }
        var myOpt = JSON.parse(localStorage.getItem('currentAppID'));
        this.commandDataSend = {
            appId: this.commandData.appId,
            windowId: this.commandData.windowId,
            command: "Mute Unmute mic"
        };
        myOpt.appCommand = "Mute Unmute mic";
        this.doExecuteCommand(myOpt);
    }
    switchCamera() {
        if (this.currState.camera == "false" || !this.currState.camera) {
            this.currState.camera = "true";
            this.setCurrentAppLocalStorage('appID' + this.currState.appID + '-' + this.currState.windowsID, this.currState);
        }
        else {
            this.currState.camera = "false";
            this.setCurrentAppLocalStorage('appID' + this.currState.appID + '-' + this.currState.windowsID, this.currState);
        }
        var myOpt = JSON.parse(localStorage.getItem('currentAppID'));
        this.commandDataSend = {
            appId: this.commandData.appId,
            windowId: this.commandData.windowId,
            command: "Camera"
        };
        myOpt.appCommand = "Camera";
        this.doExecuteCommand(myOpt);
    }
    switchHand() {
        if (this.currState.hand == "false" || !this.currState.hand) {
            this.currState.hand = "true";
            this.setCurrentAppLocalStorage('appID' + this.currState.appID + '-' + this.currState.windowsID, this.currState);
        }
        else {
            this.currState.hand = "false";
            this.setCurrentAppLocalStorage('appID' + this.currState.appID + '-' + this.currState.windowsID, this.currState);
        }
        var myOpt = JSON.parse(localStorage.getItem('currentAppID'));
        this.commandDataSend = {
            appId: this.commandData.appId,
            windowId: this.commandData.windowId,
            command: "Raise"
        };
        myOpt.appCommand = "Raise";
        this.doExecuteCommand(myOpt);
    }
    //Powerpoint
    ppPlayFromStart() {
        var myOpt = JSON.parse(localStorage.getItem('currentAppID'));
        this.commandDataSend = {
            appId: this.commandData.appId,
            windowId: this.commandData.windowId,
            command: "PlayFromStart"
        };
        myOpt.appCommand = "PlayFromStart";
        this.doExecuteCommand(myOpt);
    }
    ppPlayFromCurrentSlide() {
        var myOpt = JSON.parse(localStorage.getItem('currentAppID'));
        this.commandDataSend = {
            appId: this.commandData.appId,
            windowId: this.commandData.windowId,
            command: "PlayFromCurrentSlide"
        };
        myOpt.appCommand = "PlayFromCurrentSlide";
        this.doExecuteCommand(myOpt);
    }
    ppPrint() {
        var myOpt = JSON.parse(localStorage.getItem('currentAppID'));
        this.commandDataSend = {
            appId: this.commandData.appId,
            windowId: this.commandData.windowId,
            command: "Print"
        };
        myOpt.appCommand = "Print";
        this.doExecuteCommand(myOpt);
    }
    ppSave() {
        var myOpt = JSON.parse(localStorage.getItem('currentAppID'));
        this.commandDataSend = {
            appId: this.commandData.appId,
            windowId: this.commandData.windowId,
            command: "Save"
        };
        myOpt.appCommand = "Save";
        this.doExecuteCommand(myOpt);
    }
    ppNewSlide() {
        var myOpt = JSON.parse(localStorage.getItem('currentAppID'));
        this.commandDataSend = {
            appId: this.commandData.appId,
            windowId: this.commandData.windowId,
            command: "NewSlide"
        };
        myOpt.appCommand = "NewSlide";
        this.doExecuteCommand(myOpt);
    }
    ppDuplicateSlide() {
        var myOpt = JSON.parse(localStorage.getItem('currentAppID'));
        this.commandDataSend = {
            appId: this.commandData.appId,
            windowId: this.commandData.windowId,
            command: "DuplicateSlide"
        };
        myOpt.appCommand = "DuplicateSlide";
        this.doExecuteCommand(myOpt);
    }
    //Netflix
    netflixRewind() {
        var myOpt = JSON.parse(localStorage.getItem('currentAppID'));
        this.commandDataSend = {
            appId: this.commandData.appId,
            windowId: this.commandData.windowId,
            command: "Rewind10"
        };
        myOpt.appCommand = "Rewind10";
        this.doExecuteCommand(myOpt);
    }
    netflixPause() {
        if (localStorage.getItem("netflixPlay") == "false") {
            localStorage.setItem("netflixPlay", "true");
            this.netflixPlay = "true";
        }
        else {
            localStorage.setItem("netflixPlay", "false");
            this.netflixPlay = "false";
        }
        ;
        var myOpt = JSON.parse(localStorage.getItem('currentAppID'));
        this.commandDataSend = {
            appId: this.commandData.appId,
            windowId: this.commandData.windowId,
            command: "PlayPause"
        };
        myOpt.appCommand = "PlayPause";
        this.doExecuteCommand(myOpt);
    }
    netflixStop() {
        var myOpt = JSON.parse(localStorage.getItem('currentAppID'));
        this.commandDataSend = {
            appId: this.commandData.appId,
            windowId: this.commandData.windowId,
            command: "Stop"
        };
        myOpt.appCommand = "Stop";
        this.doExecuteCommand(myOpt);
    }
    // Spotify
    spotifyShuffle() {
        var myOpt = JSON.parse(localStorage.getItem('currentAppID'));
        this.commandDataSend = {
            appId: this.commandData.appId,
            windowId: this.commandData.windowId,
            command: "Shuffle"
        };
        myOpt.appCommand = "Shuffle";
        this.doExecuteCommand(myOpt);
    }
    spotifyPlay() {
        var myOpt = JSON.parse(localStorage.getItem('currentAppID'));
        this.commandDataSend = {
            appId: this.commandData.appId,
            windowId: this.commandData.windowId,
            command: "Play"
        };
        myOpt.appCommand = "Play";
        this.doExecuteCommand(myOpt);
    }
    spotifyStop() {
        var myOpt = JSON.parse(localStorage.getItem('currentAppID'));
        this.commandDataSend = {
            appId: this.commandData.appId,
            windowId: this.commandData.windowId,
            command: "Stop"
        };
        myOpt.appCommand = "Stop";
        this.doExecuteCommand(myOpt);
    }
    ngOnInit() {
        if (!localStorage.getItem("teamsHand") == true) {
            localStorage.setItem("teamsHand", "false");
            this.hand = "false";
        }
        if (!localStorage.getItem("teamsCamera") == true) {
            localStorage.setItem("teamsCamera", "false");
            this.camera = "false";
        }
        if (!localStorage.getItem("teamsMic") == true) {
            localStorage.setItem("teamsMic", "false");
            this.mic = "false";
        }
        if (!localStorage.getItem("netflixPlay") == true) {
            localStorage.setItem("netflixPlay", "false");
            this.netflixPlay = "false";
        }
        this.commandData = JSON.parse(localStorage.getItem('currentAppID'));
        // Initial call to get running apps
        this.getSpecificApp(this.commandData);
    }
};
MsTeamsPage.ctorParameters = () => [
    { type: _services_currently_viewing_service__WEBPACK_IMPORTED_MODULE_10__["CurrentlyViewingService"] },
    { type: _services_cleandata_service__WEBPACK_IMPORTED_MODULE_9__["CleandataService"] },
    { type: _services_current_ip_port_service__WEBPACK_IMPORTED_MODULE_8__["CurrentIpPortService"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["ModalController"] },
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_5__["HttpClient"] },
    { type: _services_api_service__WEBPACK_IMPORTED_MODULE_6__["ApiService"] },
    { type: _global_constants__WEBPACK_IMPORTED_MODULE_7__["GlobalConstants"] }
];
MsTeamsPage.propDecorators = {
    app: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["Input"] }]
};
MsTeamsPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-ms-teams',
        template: _raw_loader_ms_teams_page_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_ms_teams_page_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], MsTeamsPage);



/***/ })

}]);
//# sourceMappingURL=default~home-home-module~modal-modals-ms-teams-module.js.map
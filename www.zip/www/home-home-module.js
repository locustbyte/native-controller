(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["home-home-module"],{

/***/ "A3+G":
/*!*********************************************!*\
  !*** ./src/app/home/home-routing.module.ts ***!
  \*********************************************/
/*! exports provided: HomePageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "HomePageRoutingModule", function() { return HomePageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _home_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./home.page */ "zpKS");




const routes = [
    {
        path: '',
        component: _home_page__WEBPACK_IMPORTED_MODULE_3__["HomePage"],
    }
];
let HomePageRoutingModule = class HomePageRoutingModule {
};
HomePageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
    })
], HomePageRoutingModule);



/***/ }),

/***/ "WcN3":
/*!***************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/home/home.page.html ***!
  \***************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header [translucent]=\"true\">\n  <ion-toolbar class=\"custom-toolbar\">\n    <ion-buttons slot=\"start\">\n      <ion-button\n        (click)=\"presentIPModal();\"\n        style=\"color: white; font-size: 24px\"\n      >\n        <ion-icon style=\"color: white\" name=\"settings-outline\"></ion-icon>\n      </ion-button>\n    </ion-buttons>\n    <ion-title class=\"text-center\"\n      >Active Apps ({{globals.APPS_AVAILABLE_SINGULAR.length +\n      globals.APPS_AVAILABLE_MULTIPLE.length}})<br />\n      <small>Machine {{currentIP}}:{{currentPort}}</small></ion-title\n    >\n  </ion-toolbar>\n</ion-header>\n\n<ion-content [fullscreen]=\"true\">\n  <ion-row class=\"loading-screen text-center\" *ngIf=\"this.globals.LOADING\">\n    <ion-col>\n      <div>\n        <h1>Fetching your apps...</h1>\n        <img src=\"assets/images/svg-css-loaders/ball-triangle.svg\" />\n      </div>\n    </ion-col>\n  </ion-row>\n  <ion-row\n    class=\"m-t-30\"\n    *ngFor=\"let appSingular of globals.APPS_AVAILABLE_SINGULAR| keyvalue; let appIndex=index\"\n  >\n    <ion-col>\n      <ion-row>\n        <ion-col size=\"2\" class=\"text-center\">\n          <img\n            width=\"40px\"\n            src=\"assets/images/{{appSingular.value[0].name}}-icon.png\"\n          />\n        </ion-col>\n        <ion-col size=\"10\" style=\"text-align: left\">\n          <p class=\"app-title\">{{appSingular.value[0].name}}</p>\n          <p class=\"app-description\" *ngIf=\"appSingular.value.length > 1\">\n            {{appSingular.value.length}} open window(s)\n          </p>\n        </ion-col>\n      </ion-row>\n      <ion-slides\n        [options]=\"{ slidesPerView: 'auto', zoom: false, grabCursor: true }\"\n        class=\"horizontal-slides height-auto\"\n      >\n        <ion-slide\n          *ngFor=\"let appSingularInstance of appSingular.value | keyvalue; let appInstance=index\"\n          style=\"\n            width: 90%;\n            height: 280px;\n            border: 0px;\n            margin: 0;\n            margin-top: -40px;\n          \"\n        >\n          <ion-col style=\"text-align: left\">\n            <!--doFocusWindow (click)=\"doFocusWindow({'appID': appSingularInstance.value.id, 'windowsID': appSingularInstance.value.windows[0].id});\"-->\n\n            <div>\n              <div\n                class=\"recent-item\"\n                [id]=\"appSingularInstance.value.id\"\n                (click)=\"isAllowedApp({'appName': appSingularInstance.value.appName,'appID': appSingularInstance.value.id, 'windowsID': appSingularInstance.value.windows[0].id});\"\n              >\n                <img src=\"assets/images/{{appSingular.value[0].name}}.jpg\" />\n                <div\n                  style=\"\n                    position: absolute;\n                    bottom: 5px;\n                    width: 100%;\n                    background: rgba(0, 0, 0, 0.85);\n                    padding: 0px;\n                  \"\n                >\n                  <p\n                    style=\"\n                      padding: 0px 10px 0px 10px;\n                      font-size: 14px;\n                      margin: 10px 0px 5px 0px;\n                      color: #929292;\n                    \"\n                  >\n                    Viewing now\n                  </p>\n                  <p\n                    style=\"\n                      padding: 0px 10px 0px 10px;\n                      font-size: 14px;\n                      margin: 0px 0px 10px 0px;\n                      white-space: nowrap;\n                      overflow: hidden;\n                      text-overflow: ellipsis;\n                      width: 100%;\n                    \"\n                  >\n                    {{appSingularInstance.value.title}}\n                  </p>\n                </div>\n              </div>\n            </div>\n          </ion-col>\n        </ion-slide>\n        <ion-slide> </ion-slide>\n      </ion-slides>\n    </ion-col>\n  </ion-row>\n\n  <ion-row\n    *ngFor=\"let appMultiple of globals.APPS_AVAILABLE_MULTIPLE| keyvalue; let appIndex=index\"\n  >\n    <ion-col>\n      <ion-row>\n        <ion-col size=\"2\">\n          <img\n            width=\"40px\"\n            src=\"assets/images/{{appMultiple.value[0].name}}-icon.png\"\n          />\n        </ion-col>\n        <ion-col size=\"10\">\n          <p class=\"app-title\">{{appMultiple.value[0].appName}}</p>\n          <p\n            class=\"app-description\"\n            *ngIf=\"appMultiple.value[0].windows.length > 1\"\n          >\n            {{appMultiple.value[0].windows.length }} open window(s)\n          </p>\n        </ion-col>\n      </ion-row>\n      <ion-slides\n        [options]=\"{ slidesPerView: 'auto', zoom: false, grabCursor: true }\"\n        class=\"horizontal-slides height-auto\"\n      >\n        <ion-slide\n          *ngFor=\"let appMultipleInstance of appMultiple.value[0].windows | keyvalue; let appMultipleKey=index\"\n          style=\"\n            width: 90%;\n            height: 280px;\n            border: 0px;\n            margin: 0;\n            margin-top: -40px;\n          \"\n        >\n          <ion-col style=\"text-align: left\">\n            <!--doFocusWindow (click)=\"doFocusWindow({'appID': appSingularInstance.value.id, 'windowsID': appSingularInstance.value.windows[0].id});\"-->\n\n            <div\n              class=\"recent-item\"\n              [id]=\"appMultipleInstance.value.id\"\n              (click)=\"isAllowedApp({'appName': appMultiple.value[0].appName, 'appID': appMultiple.value[0].id, 'windowsID': appMultipleInstance.value.id, appCommand: ''})\"\n            >\n              <img src=\"assets/images/{{appMultiple.value[0].name}}.jpg\" />\n              <div\n                style=\"\n                  position: absolute;\n                  bottom: 5px;\n                  width: 100%;\n                  background: rgba(0, 0, 0, 0.85);\n                  padding: 0px;\n                \"\n              >\n                <p\n                  style=\"\n                    padding: 0px 10px 0px 10px;\n                    font-size: 14px;\n                    margin: 10px 0px 5px 0px;\n                    color: #929292;\n                  \"\n                >\n                  Viewing now\n                </p>\n                <p\n                  style=\"\n                    padding: 0px 10px 0px 10px;\n                    font-size: 14px;\n                    margin: 0px 0px 10px 0px;\n                    white-space: nowrap;\n                    overflow: hidden;\n                    text-overflow: ellipsis;\n                    width: 100%;\n                  \"\n                >\n                  {{appMultipleInstance.value.title}}\n                </p>\n              </div>\n            </div>\n          </ion-col>\n        </ion-slide>\n        <ion-slide> </ion-slide>\n      </ion-slides>\n    </ion-col>\n  </ion-row>\n</ion-content>\n");

/***/ }),

/***/ "ct+p":
/*!*************************************!*\
  !*** ./src/app/home/home.module.ts ***!
  \*************************************/
/*! exports provided: HomePageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "HomePageModule", function() { return HomePageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "ofXK");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/forms */ "3Pt+");
/* harmony import */ var _home_page__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./home.page */ "zpKS");
/* harmony import */ var _home_routing_module__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./home-routing.module */ "A3+G");







let HomePageModule = class HomePageModule {
};
HomePageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["IonicModule"],
            _home_routing_module__WEBPACK_IMPORTED_MODULE_6__["HomePageRoutingModule"]
        ],
        declarations: [_home_page__WEBPACK_IMPORTED_MODULE_5__["HomePage"]]
    })
], HomePageModule);



/***/ }),

/***/ "f6od":
/*!*************************************!*\
  !*** ./src/app/home/home.page.scss ***!
  \*************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("#container {\n  text-align: center;\n  padding-left: 20px;\n}\n\n#container strong {\n  font-size: 20px;\n  line-height: 26px;\n}\n\n#container p {\n  font-size: 16px;\n  line-height: 22px;\n  color: #8c8c8c;\n  margin: 0;\n}\n\n.loading-screen {\n  position: absolute;\n  width: 100%;\n  background: rgba(0, 0, 0, 0.8);\n  height: 100%;\n  z-index: 2;\n}\n\n.loading-screen div {\n  position: relative;\n  top: 30%;\n  transform: translateY(-50%);\n}\n\n.custom-toolbar {\n  background: black;\n  background: linear-gradient(0deg, black 0%, #101010 100%, #101010 100%);\n}\n\n.broken {\n  height: 100%;\n  background: url('broken.jpg');\n  background-size: cover;\n  text-align: center;\n  padding: 100px;\n}\n\n#container a {\n  text-decoration: none;\n}\n\n.app-title {\n  color: white !important;\n  font-size: 16px;\n  margin: 0px;\n  font-weight: bold;\n  width: 80%;\n  white-space: nowrap;\n  overflow: hidden;\n  text-overflow: ellipsis;\n}\n\n.app-description {\n  color: #c1c1c1;\n  font-weight: bold;\n  margin: 0px;\n}\n\n.app-slide-description {\n  width: 90%;\n  padding: 0px 10px 0px 10px;\n  font-size: 14px;\n  white-space: nowrap;\n  overflow: hidden;\n  text-overflow: ellipsis;\n  color: white !important;\n  font-size: 18px !important;\n}\n\nion-content {\n  --ion-background-color: black !important;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy4uLy4uL2hvbWUucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0Usa0JBQUE7RUFDQSxrQkFBQTtBQUNGOztBQUVBO0VBQ0UsZUFBQTtFQUNBLGlCQUFBO0FBQ0Y7O0FBRUE7RUFDRSxlQUFBO0VBQ0EsaUJBQUE7RUFFQSxjQUFBO0VBRUEsU0FBQTtBQURGOztBQUdBO0VBQ0Usa0JBQUE7RUFDQSxXQUFBO0VBQ0EsOEJBQUE7RUFDQSxZQUFBO0VBQ0EsVUFBQTtBQUFGOztBQUNFO0VBQ0Usa0JBQUE7RUFDQSxRQUFBO0VBQ0EsMkJBQUE7QUFDSjs7QUFFQTtFQUNFLGlCQUFBO0VBQ0EsdUVBQUE7QUFDRjs7QUFDQTtFQUNFLFlBQUE7RUFDQSw2QkFBQTtFQUNBLHNCQUFBO0VBQ0Esa0JBQUE7RUFDQSxjQUFBO0FBRUY7O0FBQUE7RUFDRSxxQkFBQTtBQUdGOztBQURBO0VBQ0UsdUJBQUE7RUFDQSxlQUFBO0VBQ0EsV0FBQTtFQUNBLGlCQUFBO0VBQ0EsVUFBQTtFQUNBLG1CQUFBO0VBQ0EsZ0JBQUE7RUFDQSx1QkFBQTtBQUlGOztBQUZBO0VBQ0UsY0FBQTtFQUNBLGlCQUFBO0VBQ0EsV0FBQTtBQUtGOztBQUhBO0VBQ0UsVUFBQTtFQUNBLDBCQUFBO0VBQ0EsZUFBQTtFQUNBLG1CQUFBO0VBQ0EsZ0JBQUE7RUFDQSx1QkFBQTtFQUNBLHVCQUFBO0VBQ0EsMEJBQUE7QUFNRjs7QUFIQTtFQUNFLHdDQUFBO0FBTUYiLCJmaWxlIjoiaG9tZS5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIjY29udGFpbmVyIHtcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xuICBwYWRkaW5nLWxlZnQ6IDIwcHg7XG59XG5cbiNjb250YWluZXIgc3Ryb25nIHtcbiAgZm9udC1zaXplOiAyMHB4O1xuICBsaW5lLWhlaWdodDogMjZweDtcbn1cblxuI2NvbnRhaW5lciBwIHtcbiAgZm9udC1zaXplOiAxNnB4O1xuICBsaW5lLWhlaWdodDogMjJweDtcblxuICBjb2xvcjogIzhjOGM4YztcblxuICBtYXJnaW46IDA7XG59XG4ubG9hZGluZy1zY3JlZW4ge1xuICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gIHdpZHRoOiAxMDAlO1xuICBiYWNrZ3JvdW5kOiByZ2JhKDAsIDAsIDAsIDAuOCk7XG4gIGhlaWdodDogMTAwJTtcbiAgei1pbmRleDogMjtcbiAgZGl2IHtcbiAgICBwb3NpdGlvbjogcmVsYXRpdmU7XG4gICAgdG9wOiAzMCU7XG4gICAgdHJhbnNmb3JtOiB0cmFuc2xhdGVZKC01MCUpO1xuICB9XG59XG4uY3VzdG9tLXRvb2xiYXIge1xuICBiYWNrZ3JvdW5kOiByZ2IoMCwgMCwgMCk7XG4gIGJhY2tncm91bmQ6IGxpbmVhci1ncmFkaWVudCgwZGVnLCByZ2JhKDAsIDAsIDAsIDEpIDAlLCByZ2JhKDE2LCAxNiwgMTYsIDEpIDEwMCUsIHJnYmEoMTYsIDE2LCAxNiwgMSkgMTAwJSk7XG59XG4uYnJva2VuIHtcbiAgaGVpZ2h0OiAxMDAlO1xuICBiYWNrZ3JvdW5kOiB1cmwoXCIuLi8uLi9hc3NldHMvaW1hZ2VzL2Jyb2tlbi5qcGdcIik7XG4gIGJhY2tncm91bmQtc2l6ZTogY292ZXI7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgcGFkZGluZzogMTAwcHg7XG59XG4jY29udGFpbmVyIGEge1xuICB0ZXh0LWRlY29yYXRpb246IG5vbmU7XG59XG4uYXBwLXRpdGxlIHtcbiAgY29sb3I6IHdoaXRlICFpbXBvcnRhbnQ7XG4gIGZvbnQtc2l6ZTogMTZweDtcbiAgbWFyZ2luOiAwcHg7XG4gIGZvbnQtd2VpZ2h0OiBib2xkO1xuICB3aWR0aDogODAlO1xuICB3aGl0ZS1zcGFjZTogbm93cmFwO1xuICBvdmVyZmxvdzogaGlkZGVuO1xuICB0ZXh0LW92ZXJmbG93OiBlbGxpcHNpcztcbn1cbi5hcHAtZGVzY3JpcHRpb24ge1xuICBjb2xvcjogI2MxYzFjMTtcbiAgZm9udC13ZWlnaHQ6IGJvbGQ7XG4gIG1hcmdpbjogMHB4O1xufVxuLmFwcC1zbGlkZS1kZXNjcmlwdGlvbiB7XG4gIHdpZHRoOiA5MCU7XG4gIHBhZGRpbmc6IDBweCAxMHB4IDBweCAxMHB4O1xuICBmb250LXNpemU6IDE0cHg7XG4gIHdoaXRlLXNwYWNlOiBub3dyYXA7XG4gIG92ZXJmbG93OiBoaWRkZW47XG4gIHRleHQtb3ZlcmZsb3c6IGVsbGlwc2lzO1xuICBjb2xvcjogd2hpdGUgIWltcG9ydGFudDtcbiAgZm9udC1zaXplOiAxOHB4ICFpbXBvcnRhbnQ7XG59XG5cbmlvbi1jb250ZW50IHtcbiAgLS1pb24tYmFja2dyb3VuZC1jb2xvcjogYmxhY2sgIWltcG9ydGFudDtcbn1cbiJdfQ== */");

/***/ }),

/***/ "zpKS":
/*!***********************************!*\
  !*** ./src/app/home/home.page.ts ***!
  \***********************************/
/*! exports provided: HomePage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "HomePage", function() { return HomePage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_home_page_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./home.page.html */ "WcN3");
/* harmony import */ var _home_page_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./home.page.scss */ "f6od");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var _modal_ms_teams_ms_teams_page__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./../modal/ms-teams/ms-teams.page */ "oz6t");
/* harmony import */ var _modal_ipconfig_ipconfig_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./../modal/ipconfig/ipconfig.page */ "xG7c");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/common/http */ "tk/3");
/* harmony import */ var _services_api_service__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../services/api.service */ "H+bZ");
/* harmony import */ var _global_constants__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./../global-constants */ "TqJ6");
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/platform-browser */ "jhN1");











class RunningProcesses {
}
const httpOptions = {
    headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_7__["HttpHeaders"]({
        'Content-Type': 'application/xml',
        'Authorization': 'jwt-token'
    })
};
let HomePage = class HomePage {
    constructor(sanitizer, modalController, httpClient, apiService, globals) {
        this.sanitizer = sanitizer;
        this.modalController = modalController;
        this.httpClient = httpClient;
        this.apiService = apiService;
        this.globals = globals;
        this.theRunningApps = [];
        this.theRunningApps2 = [];
        this.appsSingular = [];
        this.appsMultiple = [];
        this.theRunningAppsSorted = [];
        this.currentModal = null;
        this.randTest = [];
        this.dataReturned = [];
        this.allowedApps = [
            "Microsoft Teams", "TEAMS", "Netflix", "PowerPoint", "Spotify", "NOTEPAD", "APPLICATIONFRAMEHOST", "POWERPNT"
        ];
        this.preStripArr = [];
        this.theAppData = [];
    }
    isAllowedAppName(appName) {
        return this.allowedApps.includes(appName) == true;
    }
    isAllowedApp(appName) {
        console.log(appName);
        if (this.allowedApps.includes(appName.appName) == true) {
            this.presentModal(appName, 'true');
        }
        else {
            this.doFocusWindow(appName);
        }
    }
    presentIPModal() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const modal = yield this.modalController.create({
                component: _modal_ipconfig_ipconfig_page__WEBPACK_IMPORTED_MODULE_6__["IpconfigPage"],
                cssClass: 'my-custom-class'
            });
            modal.onDidDismiss().then((dataReturned) => {
                if (dataReturned !== null) {
                    if (dataReturned.data.dismissed == true) {
                        this.dataReturned = dataReturned.data;
                        this.appsSingular = [];
                        this.appsMultiple = [];
                        this.getRunningProcesses();
                    }
                    //alert('Modal Sent Data :'+ dataReturned);
                }
            });
            return yield modal.present();
            this.currentModal = modal;
        });
    }
    presentModal(event, trusted) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            this.doFocusWindow(event);
            localStorage.setItem('currentAppID', JSON.stringify(event));
            const modal = yield this.modalController.create({
                component: _modal_ms_teams_ms_teams_page__WEBPACK_IMPORTED_MODULE_5__["MsTeamsPage"],
                cssClass: 'my-custom-class',
                componentProps: {
                    'app': event.path
                }
            });
            modal.onDidDismiss().then((dataReturned) => {
                if (dataReturned !== null) {
                    if (dataReturned.data.dismissed == true) {
                        this.dataReturned = dataReturned.data;
                        // Should think about syncing the new app list here
                        // this.appsSingular = []
                        // this.appsMultiple = []
                        // this.getRunningProcesses()
                    }
                }
            });
            return yield modal.present();
            this.currentModal = modal;
            //this.doFocusWindow(event)
        });
    }
    shallShowModal(params) {
        if (params.appName == 'Microsoft Teams' || params.appName == 'Netflix' || params.appName == 'Powerpoint' || params.appName == 'Spotify') {
            this.presentModal(params, false);
        }
        else {
            this.doFocusWindow(params);
        }
    }
    getSnapshot(params) {
        this.apiService.getSnapshot(params)
            .subscribe((baseImage) => {
            alert(JSON.stringify(baseImage));
            let objectURL = 'data:image/jpeg;base64,' + baseImage.image;
            this.thumbnail = this.sanitizer.bypassSecurityTrustUrl(objectURL);
        });
    }
    doFocusWindow(params) {
        this.apiService.doSetWindowFocus(params).subscribe((data) => {
        });
    }
    getRunningProcesses() {
        this.globals.APPS_AVAILABLE_SINGULAR = [];
        this.globals.APPS_AVAILABLE_MULTIPLE = [];
        this.apiService.getAppsRunning().subscribe((data) => {
            this.preStripArr = data;
            for (const [i, v] of this.preStripArr.entries()) {
                var allowed = this.isAllowedAppName(v.name);
                if (v.name == "APPLICATIONFRAMEHOST") {
                    for (const [ii, vv] of v.windowTitles.entries()) {
                        var allowed = this.isAllowedAppName(vv);
                        if (allowed === true) {
                            v.title = vv;
                            v.appName = vv;
                            v.name = vv.toUpperCase();
                            v.switched = true;
                            v.windowTitles = [];
                            var [windowTitleTemp] = [vv];
                            v.windowTitles = ([windowTitleTemp]);
                            v.windows = [v.windows[ii]];
                            this.theAppData.push(v);
                        }
                    }
                }
                else {
                    if (allowed === true) {
                        this.theAppData.push(v);
                    }
                }
            }
            let group = this.theAppData.reduce((r, a) => {
                //
                // 
                r[a.name] = [...r[a.name] || [], a];
                return r;
            }, {});
            const objectArray = Object.entries(group);
            objectArray.forEach(([key, value]) => {
                if (value[0].windows.length > 1) {
                    this.globals.APPS_AVAILABLE_MULTIPLE.push(value);
                }
                if (value[0].windows.length == 1) {
                    this.globals.APPS_AVAILABLE_SINGULAR.push(value);
                }
            });
            // 
            // this.getItems(this.theRunningApps2, "Microsoft Teams")
        });
    }
    ngOnInit() {
        if (localStorage.getItem("currentIpAddress")) {
            this.currentIP = localStorage.getItem("currentIpAddress");
        }
        else {
            this.currentIP = this.globals.REST_API_IP;
        }
        if (localStorage.getItem("currentPortAddress")) {
            this.currentPort = localStorage.getItem("currentPortAddress");
        }
        else {
            this.currentPort = this.globals.REST_API_PORT;
        }
    }
};
HomePage.ctorParameters = () => [
    { type: _angular_platform_browser__WEBPACK_IMPORTED_MODULE_10__["DomSanitizer"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["ModalController"] },
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_7__["HttpClient"] },
    { type: _services_api_service__WEBPACK_IMPORTED_MODULE_8__["ApiService"] },
    { type: _global_constants__WEBPACK_IMPORTED_MODULE_9__["GlobalConstants"] }
];
HomePage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-home',
        template: _raw_loader_home_page_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_home_page_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], HomePage);



/***/ })

}]);
//# sourceMappingURL=home-home-module.js.map
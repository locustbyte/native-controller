(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["home-home-module"],{

/***/ "A3+G":
/*!*********************************************!*\
  !*** ./src/app/home/home-routing.module.ts ***!
  \*********************************************/
/*! exports provided: HomePageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "HomePageRoutingModule", function() { return HomePageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _home_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./home.page */ "zpKS");




const routes = [
    {
        path: '',
        component: _home_page__WEBPACK_IMPORTED_MODULE_3__["HomePage"],
    }
];
let HomePageRoutingModule = class HomePageRoutingModule {
};
HomePageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
    })
], HomePageRoutingModule);



/***/ }),

/***/ "WcN3":
/*!***************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/home/home.page.html ***!
  \***************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-toolbar class=\"custom-toolbar\">\n  <ion-buttons slot=\"start\">\n    <ion-button (click)=\"presentIPModal();\">\n      <ion-icon name=\"settings-outline\"></ion-icon>\n    </ion-button>\n  </ion-buttons>\n\n  <ion-title class=\"text-center\"\n    >Active Apps ({{appsSingular.length + appsMultiple.length}})</ion-title\n  >\n</ion-toolbar>\n<ion-content [fullscreen]=\"true\">\n  <div id=\"container\">\n    <div\n      *ngFor=\"let appSingular of appsSingular | keyvalue; let appIndex=index\"\n    >\n      <!-- SLIDE HEADER -->\n      <ion-row class=\"text-center\">\n        <ion-col size=\"2\">\n          <img\n            width=\"40px\"\n            src=\"assets/images/{{appSingular.value[0].name}}-icon.png\"\n          />\n        </ion-col>\n        <ion-col size=\"10\" style=\"text-align: left\">\n          <p class=\"app-title\">{{appSingular.value[0].appName}}</p>\n          <p class=\"app-description\" *ngIf=\"appSingular.value.length > 1\">\n            {{appSingular.value.length}} open window(s)\n          </p>\n        </ion-col>\n      </ion-row>\n\n      <!-- SLIDES -->\n\n      <ion-slides\n        [options]=\"{ slidesPerView: 'auto', zoom: false, grabCursor: true }\"\n        class=\"horizontal-slides height-auto\"\n      >\n        <ion-slide\n          *ngFor=\"let appSingularInstance of appSingular.value | keyvalue; let appInstance=index\"\n          style=\"\n            width: 90%;\n            height: 280px;\n            border: 0px;\n            margin: 0;\n            margin-top: -40px;\n          \"\n        >\n          <ion-col style=\"text-align: left\">\n            <!--doFocusWindow (click)=\"doFocusWindow({'appID': appSingularInstance.value.id, 'windowsID': appSingularInstance.value.windows[0].id});\"-->\n            <div *ngIf=\"appSingularInstance.value.windows.length != 0\">\n              <div\n                class=\"recent-item\"\n                [id]=\"appSingularInstance.value.id\"\n                (click)=\"shallShowModal({'appName': appSingularInstance.value.appName,'appID': appSingularInstance.value.id, 'windowsID': appSingularInstance.value.windows[0].id});\"\n              >\n                <img src=\"assets/images/{{appSingular.value[0].name}}.jpg\" />\n                <div\n                  style=\"\n                    position: absolute;\n                    bottom: 9px;\n                    width: 100%;\n                    background: rgba(0, 0, 0, 0.85);\n                    padding: 10px;\n                  \"\n                >\n                  <p>Viewing now</p>\n                  <p class=\"app-slide-description\">\n                    {{appSingularInstance.value.title}}\n                  </p>\n                </div>\n              </div>\n            </div>\n          </ion-col>\n        </ion-slide>\n        <ion-slide> </ion-slide>\n      </ion-slides>\n    </div>\n    <div\n      *ngFor=\"let appMultiple of appsMultiple | keyvalue; let appIndex=index\"\n    >\n      <!-- SLIDE HEADER -->\n      <ion-row class=\"text-center\">\n        <ion-col size=\"2\">\n          <img\n            width=\"40px\"\n            src=\"assets/images/{{appMultiple.value[0].name}}-icon.png\"\n          />\n        </ion-col>\n        <ion-col size=\"10\" style=\"text-align: left\">\n          <p style=\"color: white; font-size: 16px\">\n            {{appMultiple.value[0].appName}}\n          </p>\n          <p style=\"color: grey\">\n            {{appMultiple.value[0].windows.length }} open window(s)\n          </p>\n        </ion-col>\n      </ion-row>\n\n      <!-- SLIDES -->\n      <ion-slides\n        [options]=\"{ slidesPerView: 'auto', zoom: false, grabCursor: true }\"\n        class=\"horizontal-slides height-auto\"\n      >\n        <ion-slide\n          *ngFor=\"let appMultipleInstance of appMultiple.value[0].windows | keyvalue; let appMultipleKey=index\"\n          style=\"\n            width: 80%;\n            height: 280px;\n            border: 0px;\n            margin: 0;\n            margin-top: -40px;\n          \"\n        >\n          <ion-col style=\"text-align: left\">\n            <div>\n              <div\n                class=\"recent-item\"\n                [id]=\"appMultipleInstance.value.id\"\n                (click)=\"presentModal({'appID': appMultiple.value[0].id, 'windowsID': appMultipleInstance.value.id, appCommand: ''});\"\n              >\n                <img src=\"assets/images/{{appMultiple.value[0].name}}.jpg\" />\n                <div\n                  style=\"\n                    position: absolute;\n                    bottom: 9px;\n                    width: 100%;\n                    background: rgba(0, 0, 0, 0.85);\n                    padding: 10px;\n                  \"\n                >\n                  <p>Viewing now</p>\n                  <p class=\"app-slide-description\">\n                    {{appMultipleInstance.value.title}}\n                  </p>\n                </div>\n              </div>\n            </div>\n          </ion-col>\n        </ion-slide>\n        <ion-slide> </ion-slide>\n      </ion-slides>\n    </div>\n  </div>\n</ion-content>\n");

/***/ }),

/***/ "ct+p":
/*!*************************************!*\
  !*** ./src/app/home/home.module.ts ***!
  \*************************************/
/*! exports provided: HomePageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "HomePageModule", function() { return HomePageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "ofXK");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/forms */ "3Pt+");
/* harmony import */ var _home_page__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./home.page */ "zpKS");
/* harmony import */ var _home_routing_module__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./home-routing.module */ "A3+G");







let HomePageModule = class HomePageModule {
};
HomePageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["IonicModule"],
            _home_routing_module__WEBPACK_IMPORTED_MODULE_6__["HomePageRoutingModule"]
        ],
        declarations: [_home_page__WEBPACK_IMPORTED_MODULE_5__["HomePage"]]
    })
], HomePageModule);



/***/ }),

/***/ "f6od":
/*!*************************************!*\
  !*** ./src/app/home/home.page.scss ***!
  \*************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("#container {\n  text-align: center;\n  padding-left: 20px;\n}\n\n#container strong {\n  font-size: 20px;\n  line-height: 26px;\n}\n\n#container p {\n  font-size: 16px;\n  line-height: 22px;\n  color: #8c8c8c;\n  margin: 0;\n}\n\n#container a {\n  text-decoration: none;\n}\n\n.app-title {\n  color: white !important;\n  font-size: 16px;\n  font-weight: bold;\n  width: 80%;\n  white-space: nowrap;\n  overflow: hidden;\n  text-overflow: ellipsis;\n}\n\n.app-description {\n  color: #c1c1c1;\n  font-weight: bold;\n}\n\n.app-slide-description {\n  width: 90%;\n  white-space: nowrap;\n  overflow: hidden;\n  text-overflow: ellipsis;\n  color: white !important;\n  font-size: 18px !important;\n}\n\nion-content {\n  --ion-background-color: black !important;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy4uLy4uL2hvbWUucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0Usa0JBQUE7RUFDQSxrQkFBQTtBQUNGOztBQUVBO0VBQ0UsZUFBQTtFQUNBLGlCQUFBO0FBQ0Y7O0FBRUE7RUFDRSxlQUFBO0VBQ0EsaUJBQUE7RUFFQSxjQUFBO0VBRUEsU0FBQTtBQURGOztBQUlBO0VBQ0UscUJBQUE7QUFERjs7QUFHQTtFQUNFLHVCQUFBO0VBQ0EsZUFBQTtFQUNBLGlCQUFBO0VBQ0EsVUFBQTtFQUNBLG1CQUFBO0VBQ0EsZ0JBQUE7RUFDQSx1QkFBQTtBQUFGOztBQUVBO0VBQ0UsY0FBQTtFQUNBLGlCQUFBO0FBQ0Y7O0FBQ0E7RUFDRSxVQUFBO0VBQ0EsbUJBQUE7RUFDQSxnQkFBQTtFQUNBLHVCQUFBO0VBQ0EsdUJBQUE7RUFDQSwwQkFBQTtBQUVGOztBQUNBO0VBQ0Usd0NBQUE7QUFFRiIsImZpbGUiOiJob21lLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIiNjb250YWluZXIge1xuICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gIHBhZGRpbmctbGVmdDogMjBweDtcbn1cblxuI2NvbnRhaW5lciBzdHJvbmcge1xuICBmb250LXNpemU6IDIwcHg7XG4gIGxpbmUtaGVpZ2h0OiAyNnB4O1xufVxuXG4jY29udGFpbmVyIHAge1xuICBmb250LXNpemU6IDE2cHg7XG4gIGxpbmUtaGVpZ2h0OiAyMnB4O1xuXG4gIGNvbG9yOiAjOGM4YzhjO1xuXG4gIG1hcmdpbjogMDtcbn1cblxuI2NvbnRhaW5lciBhIHtcbiAgdGV4dC1kZWNvcmF0aW9uOiBub25lO1xufVxuLmFwcC10aXRsZSB7XG4gIGNvbG9yOiB3aGl0ZSAhaW1wb3J0YW50O1xuICBmb250LXNpemU6IDE2cHg7XG4gIGZvbnQtd2VpZ2h0OiBib2xkO1xuICB3aWR0aDogODAlO1xuICB3aGl0ZS1zcGFjZTogbm93cmFwO1xuICBvdmVyZmxvdzogaGlkZGVuO1xuICB0ZXh0LW92ZXJmbG93OiBlbGxpcHNpcztcbn1cbi5hcHAtZGVzY3JpcHRpb24ge1xuICBjb2xvcjogI2MxYzFjMTtcbiAgZm9udC13ZWlnaHQ6IGJvbGQ7XG59XG4uYXBwLXNsaWRlLWRlc2NyaXB0aW9uIHtcbiAgd2lkdGg6IDkwJTtcbiAgd2hpdGUtc3BhY2U6IG5vd3JhcDtcbiAgb3ZlcmZsb3c6IGhpZGRlbjtcbiAgdGV4dC1vdmVyZmxvdzogZWxsaXBzaXM7XG4gIGNvbG9yOiB3aGl0ZSAhaW1wb3J0YW50O1xuICBmb250LXNpemU6IDE4cHggIWltcG9ydGFudDtcbn1cblxuaW9uLWNvbnRlbnQge1xuICAtLWlvbi1iYWNrZ3JvdW5kLWNvbG9yOiBibGFjayAhaW1wb3J0YW50O1xufVxuIl19 */");

/***/ }),

/***/ "zpKS":
/*!***********************************!*\
  !*** ./src/app/home/home.page.ts ***!
  \***********************************/
/*! exports provided: HomePage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "HomePage", function() { return HomePage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_home_page_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./home.page.html */ "WcN3");
/* harmony import */ var _home_page_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./home.page.scss */ "f6od");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var _modal_ms_teams_ms_teams_page__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./../modal/ms-teams/ms-teams.page */ "oz6t");
/* harmony import */ var _modal_ipconfig_ipconfig_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./../modal/ipconfig/ipconfig.page */ "xG7c");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/common/http */ "tk/3");
/* harmony import */ var _services_api_service__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../services/api.service */ "H+bZ");
/* harmony import */ var _global_constants__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./../global-constants */ "TqJ6");










class RunningProcesses {
}
const httpOptions = {
    headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_7__["HttpHeaders"]({
        'Content-Type': 'application/xml',
        'Authorization': 'jwt-token'
    })
};
let HomePage = class HomePage {
    constructor(modalController, httpClient, apiService, globals) {
        this.modalController = modalController;
        this.httpClient = httpClient;
        this.apiService = apiService;
        this.globals = globals;
        this.theRunningApps = [];
        this.theRunningApps2 = [];
        this.appsSingular = [];
        this.appsMultiple = [];
        this.theRunningAppsSorted = [];
        this.currentModal = null;
        this.randTest = [];
        this.dataReturned = [];
    }
    presentIPModal() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            console.log(event);
            const modal = yield this.modalController.create({
                component: _modal_ipconfig_ipconfig_page__WEBPACK_IMPORTED_MODULE_6__["IpconfigPage"],
                cssClass: 'my-custom-class'
            });
            modal.onDidDismiss().then((dataReturned) => {
                console.log(dataReturned.data.dismissed);
                if (dataReturned !== null) {
                    if (dataReturned.data.dismissed == true) {
                        this.dataReturned = dataReturned.data;
                        this.appsSingular = [];
                        this.appsMultiple = [];
                        this.getRunningProcesses();
                    }
                    //alert('Modal Sent Data :'+ dataReturned);
                }
            });
            return yield modal.present();
            this.currentModal = modal;
        });
    }
    presentModal(event) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            localStorage.setItem('currentAppID', JSON.stringify(event));
            const modal = yield this.modalController.create({
                component: _modal_ms_teams_ms_teams_page__WEBPACK_IMPORTED_MODULE_5__["MsTeamsPage"],
                cssClass: 'my-custom-class',
                componentProps: {
                    'app': event.path
                }
            });
            return yield modal.present();
            this.currentModal = modal;
        });
    }
    shallShowModal(params) {
        if (params.appName == 'Microsoft Teams' || params.appName == 'Netflix' || params.appName == 'Powerpoint') {
            this.presentModal(params);
        }
        else {
            console.log("no commands");
            this.doFocusWindow(params);
        }
    }
    getSnapshot(id) {
        this.apiService.getSnapshot(4128).subscribe((data) => {
            console.log(data);
        });
    }
    doFocusWindow(params) {
        console.log(params);
        this.apiService.doSetWindowFocus(params).subscribe((data) => {
            console.log(data);
        });
    }
    getRunningProcesses() {
        this.apiService.getAppsRunning().subscribe((data) => {
            let group = data.reduce((r, a) => {
                // console.log("a", a);
                // console.log('r', r);
                r[a.name] = [...r[a.name] || [], a];
                return r;
            }, {});
            const objectArray = Object.entries(group);
            //console.log(objectArray)
            objectArray.forEach(([key, value]) => {
                if (value[0].windows.length > 1) {
                    this.appsMultiple.push(value);
                    console.log(value[0].windows.length);
                }
                if (value[0].windows.length == 1) {
                    this.appsSingular.push(value);
                }
            });
            console.log(this.appsSingular);
            console.log(this.appsMultiple);
            this.theRunningApps2 = this.appsMultiple;
            // console.log(this.theRunningApps2)
            // this.getItems(this.theRunningApps2, "Microsoft Teams")
        });
    }
    ngOnInit() {
        this.getRunningProcesses();
    }
};
HomePage.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["ModalController"] },
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_7__["HttpClient"] },
    { type: _services_api_service__WEBPACK_IMPORTED_MODULE_8__["ApiService"] },
    { type: _global_constants__WEBPACK_IMPORTED_MODULE_9__["GlobalConstants"] }
];
HomePage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-home',
        template: _raw_loader_home_page_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_home_page_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], HomePage);



/***/ })

}]);
//# sourceMappingURL=home-home-module.js.map
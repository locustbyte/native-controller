(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["home-home-module"],{

/***/ "A3+G":
/*!*********************************************!*\
  !*** ./src/app/home/home-routing.module.ts ***!
  \*********************************************/
/*! exports provided: HomePageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "HomePageRoutingModule", function() { return HomePageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _home_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./home.page */ "zpKS");




const routes = [
    {
        path: '',
        component: _home_page__WEBPACK_IMPORTED_MODULE_3__["HomePage"],
    }
];
let HomePageRoutingModule = class HomePageRoutingModule {
};
HomePageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
    })
], HomePageRoutingModule);



/***/ }),

/***/ "WcN3":
/*!***************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/home/home.page.html ***!
  \***************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-menu side=\"start\" type=\"push\" content-id=\"main-content\">\n  <ion-header class=\"menu-custom-header\">\n    <ion-toolbar translucent style=\"padding: 20px\">\n      <ion-buttons slot=\"end\">\n        <ion-menu-button style=\"color: white; font-size: 24px\">\n          <ion-icon (click)=\"dismiss();\" name=\"close-outline\"></ion-icon>\n        </ion-menu-button>\n      </ion-buttons>\n      <ion-title>HP Sidecar</ion-title>\n    </ion-toolbar>\n  </ion-header>\n  <ion-content style=\"background: #0e0e0e\">\n    <ion-list style=\"padding: 20px; background: transparent\">\n      <ion-item (click)=\"doPresentIPModal()\">\n        <ion-icon name=\"wifi-outline\" slot=\"start\"></ion-icon>\n        <ion-label>IP / PORT Settings</ion-label>\n      </ion-item>\n      <ion-item (click)=\"doReloadData()\">\n        <ion-icon name=\"refresh-outline\" slot=\"start\"></ion-icon>\n        <ion-label>Reload Apps</ion-label>\n      </ion-item>\n    </ion-list>\n    <div style=\"padding: 20px\">Sidecar v1.0.3</div>\n  </ion-content>\n</ion-menu>\n<ion-header [translucent]=\"true\">\n  <ion-toolbar class=\"custom-toolbar\">\n    <ion-buttons slot=\"start\">\n      <ion-menu-button style=\"color: white; font-size: 24px\">\n        <ion-icon style=\"color: white\" name=\"settings-outline\"></ion-icon>\n      </ion-menu-button>\n    </ion-buttons>\n\n    <ion-title class=\"text-center\">\n      You have {{globals.APPS_AVAILABLE_SINGULAR?.length +\n      globals.APPS_AVAILABLE_MULTIPLE?.length}}\n      <span\n        *ngIf=\"globals.APPS_AVAILABLE_SINGULAR?.length +\n      globals.APPS_AVAILABLE_MULTIPLE?.length == 1\"\n        >app</span\n      >\n      <span\n        *ngIf=\"globals.APPS_AVAILABLE_SINGULAR?.length +\n      globals.APPS_AVAILABLE_MULTIPLE?.length > 1\"\n        >apps</span\n      >\n      <span\n        *ngIf=\"globals.APPS_AVAILABLE_SINGULAR?.length +\n      globals.APPS_AVAILABLE_MULTIPLE?.length == 0\"\n        >apps\n      </span>\n      open<br />\n      <small style=\"color: grey\"\n        >Connected to\n        <span\n          class=\"error-ip\"\n          *ngIf=\"currMachine?.currIP == null || currMachine?.currIP == ''\"\n        >\n          Nothing entered\n        </span>\n        <span class=\"error-ip\" *ngIf=\"currMachine?.currIP\">\n          {{currMachine?.currIP }} </span\n        ><span *ngIf=\"currMachine?.currPORT\"\n          >:{{currMachine?.currPORT}}</span\n        ></small\n      ></ion-title\n    >\n  </ion-toolbar>\n</ion-header>\n\n<ion-content [fullscreen]=\"true\" id=\"main-content\">\n  <div class=\"loader-screen\" *ngIf=\"this.globals.LOADING == true\">\n    <h1>Locating Server...</h1>\n    <img src=\"assets/images/svg-css-loaders/ball-triangle.svg\" />\n  </div>\n  <div class=\"loader-screen\" *ngIf=\"this.globals.LOADINGDATA == true\">\n    <h1>Fetching Apps...</h1>\n    <img src=\"assets/images/svg-css-loaders/ball-triangle.svg\" />\n  </div>\n  <div\n    class=\"loader-screen\"\n    *ngIf=\"apiError?.active != true && apiError?.type == 'GETSERVER'\"\n  >\n    <h1>Locating server...</h1>\n    <img src=\"assets/images/svg-css-loaders/ball-triangle.svg\" />\n  </div>\n\n  <ion-row class=\"error-screen text-center\" *ngIf=\"apiError?.active == true\">\n    <ion-col>\n      <ion-card class=\"error-card\">\n        <img src=\"assets/images/broken-robot.png\" />\n        <ion-card-header>\n          <ion-card-title *ngIf=\"globals.API_ERROR[0].type == 'NOTFOUND'\"\n            >Cannot find API</ion-card-title\n          >\n        </ion-card-header>\n        <ion-card-header *ngIf=\"globals.API_ERROR[0].type == 'NOCONNECT'\">\n          <ion-card-title>Could not connect to PC</ion-card-title>\n        </ion-card-header>\n        <ion-card-content>\n          <div class=\"error-text\">\n            <div *ngIf=\"globals.API_ERROR[0].type == 'NOCONNECT'\">\n              It looks like we're having problems connecting to the<br />\n              PC at:\n              <p\n                class=\"error-ip\"\n                *ngIf=\"globals.REST_API_IP == null || this.globals.REST_API_IP\"\n              >\n                {{globals.REST_API_IP}}<span *ngIf=\"globals.REST_API_PORT\"\n                  >:{{globals.REST_API_PORT}}</span\n                >\n              </p>\n              <p class=\"m-t-10\" *ngIf=\"apiError?.active == true\">\n                Have you checked that the Broker service is running on the\n                server\n              </p>\n            </div>\n            <div *ngIf=\"globals.API_ERROR[0].type == 'NOTFOUND'\">\n              It looks like we're having problems connecting to the<br />\n              Api resource at:\n              <p\n                class=\"error-ip\"\n                *ngIf=\"globals.REST_API_IP == null || this.globals.REST_API_IP\"\n              >\n                {{globals.REST_API_SERVER + globals.API_CURRENT_PATH}}\n              </p>\n              <p class=\"m-t-10\" *ngIf=\"apiError?.active == true\">\n                Check the API resource exists\n              </p>\n            </div>\n          </div>\n          <ion-button\n            *ngIf=\"globals.API_ERROR[0].type == 'NOCONNECT'\"\n            color=\"success\"\n            size=\"small\"\n            class=\"m-t-20\"\n            (click)=\"doPresentIPModal()\"\n            >Check IP / PORT</ion-button\n          >\n          <ion-button\n            color=\"danger\"\n            size=\"small\"\n            class=\"m-t-20\"\n            (click)=\"getRunningProcesses()\"\n            >Retry API</ion-button\n          >\n        </ion-card-content>\n      </ion-card>\n    </ion-col>\n  </ion-row>\n\n  <ion-row\n    class=\"m-t-50\"\n    *ngIf=\"this.globals.LOADINGDATA == false && this.globals.LOADING == false\"\n  >\n    <ion-col>\n      <ion-row\n        *ngFor=\"let appSingular of globals.APPS_AVAILABLE_SINGULAR| keyvalue; let appIndex=index\"\n      >\n        <ion-col>\n          <ion-row>\n            <ion-col size=\"2\" class=\"text-center\">\n              <img\n                width=\"40px\"\n                src=\"assets/images/{{appSingular.value[0].name}}-icon.png\"\n              />\n            </ion-col>\n            <ion-col size=\"10\" style=\"text-align: left\">\n              <p\n                class=\"app-title\"\n                [class.vertically-align]=\"appSingular.value.length == 1\"\n              >\n                {{appSingular.value[0]?.appName}}\n              </p>\n              <p class=\"app-description\" *ngIf=\"appSingular.value.length > 1\">\n                {{appSingular.value.length}} open window(s)\n              </p>\n            </ion-col>\n          </ion-row>\n          <ion-slides\n            [options]=\"{ slidesPerView: 'auto', zoom: false, grabCursor: true }\"\n            class=\"horizontal-slides height-auto\"\n          >\n            <ion-slide\n              *ngFor=\"let appSingularInstance of appSingular.value | keyvalue; let appInstance=index\"\n              style=\"\n                width: 90%;\n                height: 280px;\n                border: 0px;\n                margin: 0;\n                margin-top: -40px;\n              \"\n            >\n              <ion-col\n                style=\"text-align: left\"\n                [class.col-selected]=\"appSingularInstance.value.windows[0]?.currentView == true\"\n              >\n                <div>\n                  <div\n                    class=\"recent-item\"\n                    [id]=\"appSingularInstance.value.id\"\n                    (click)=\"isAllowedApp({'appName': appSingularInstance.value.appName,'appID': appSingularInstance.value.id, 'windowTitle': appSingularInstance.value.windows[0].title, 'windowsID': appSingularInstance.value.windows[0].id, appType:'single'});\"\n                  >\n                    <img\n                      src=\"assets/images/{{appSingular.value[0].name}}.jpg\"\n                    />\n                    <div\n                      style=\"\n                        position: absolute;\n                        bottom: 5px;\n                        width: 98%;\n                        background: rgba(0, 0, 0, 0.85);\n                        padding: 0px;\n                      \"\n                    >\n                      <p\n                        style=\"\n                          padding: 0px 10px 0px 10px;\n                          font-size: 14px;\n                          margin: 10px 0px 5px 0px;\n                          color: #929292;\n                        \"\n                      >\n                        <span\n                          *ngIf=\"appSingularInstance.value.windows[0]?.currentView == true\"\n                          >Viewing now</span\n                        >\n                      </p>\n                      <p\n                        style=\"\n                          padding: 0px 10px 0px 10px;\n                          font-size: 14px;\n                          margin: 0px 0px 10px 0px;\n                          white-space: nowrap;\n                          overflow: hidden;\n                          text-overflow: ellipsis;\n                          width: 100%;\n                        \"\n                      >\n                        {{appSingularInstance.value.title}}\n                      </p>\n                    </div>\n                  </div>\n                </div>\n              </ion-col>\n            </ion-slide>\n            <ion-slide> </ion-slide>\n          </ion-slides>\n        </ion-col>\n      </ion-row>\n\n      <ion-row\n        *ngFor=\"let appMultiple of globals.APPS_AVAILABLE_MULTIPLE| keyvalue; let appIndex=index\"\n      >\n        <ion-col>\n          <ion-row>\n            <ion-col size=\"2\">\n              <img\n                width=\"40px\"\n                src=\"assets/images/{{appMultiple.value[0].name}}-icon.png\"\n              />\n            </ion-col>\n            <ion-col size=\"10\">\n              <p class=\"app-title\">{{appMultiple.value[0].appName}}</p>\n              <p\n                class=\"app-description\"\n                *ngIf=\"appMultiple.value[0].windows.length > 1\"\n              >\n                {{appMultiple.value[0].windows.length }} open windows\n              </p>\n            </ion-col>\n          </ion-row>\n          <ion-slides\n            [options]=\"{ slidesPerView: 'auto', zoom: false, grabCursor: true }\"\n            class=\"horizontal-slides height-auto\"\n          >\n            <ion-slide\n              *ngFor=\"let appMultipleInstance of appMultiple.value[0].windows | keyvalue; let appMultipleKey=index\"\n              style=\"\n                width: 90%;\n                height: 280px;\n                border: 0px;\n                margin: 0;\n                margin-top: -40px;\n              \"\n            >\n              <ion-col\n                style=\"text-align: left\"\n                [class.col-selected]=\"appMultipleInstance.value?.currentView == true\"\n              >\n                <div\n                  class=\"recent-item\"\n                  [id]=\"appMultipleInstance.value.id\"\n                  (click)=\"isAllowedApp({'appName': appMultiple.value[0].appName, 'appID': appMultiple.value[0].id, 'windowTitle': appMultipleInstance.value.title, 'windowsID': appMultipleInstance.value.id, appType:'multiple', appCommand: ''})\"\n                >\n                  <img src=\"assets/images/{{appMultiple.value[0].name}}.jpg\" />\n                  <div\n                    style=\"\n                      position: absolute;\n                      bottom: 5px;\n                      width: 98%;\n                      background: rgba(0, 0, 0, 0.85);\n                      padding: 0px;\n                    \"\n                  >\n                    <p\n                      style=\"\n                        padding: 0px 10px 0px 10px;\n                        font-size: 14px;\n                        margin: 10px 0px 5px 0px;\n                        color: #929292;\n                      \"\n                    >\n                      <span\n                        *ngIf=\"appMultipleInstance.value?.currentView == true\"\n                        >Viewing now</span\n                      >\n                    </p>\n                    <p\n                      style=\"\n                        padding: 0px 10px 0px 10px;\n                        font-size: 14px;\n                        margin: 0px 0px 10px 0px;\n                        white-space: nowrap;\n                        overflow: hidden;\n                        text-overflow: ellipsis;\n                        width: 100%;\n                      \"\n                    >\n                      {{appMultipleInstance.value.title}}\n                    </p>\n                  </div>\n                </div>\n              </ion-col>\n            </ion-slide>\n            <ion-slide> </ion-slide>\n          </ion-slides>\n        </ion-col>\n      </ion-row>\n    </ion-col>\n  </ion-row>\n</ion-content>\n");

/***/ }),

/***/ "ct+p":
/*!*************************************!*\
  !*** ./src/app/home/home.module.ts ***!
  \*************************************/
/*! exports provided: HomePageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "HomePageModule", function() { return HomePageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "ofXK");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/forms */ "3Pt+");
/* harmony import */ var _home_page__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./home.page */ "zpKS");
/* harmony import */ var _home_routing_module__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./home-routing.module */ "A3+G");







let HomePageModule = class HomePageModule {
};
HomePageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["IonicModule"],
            _home_routing_module__WEBPACK_IMPORTED_MODULE_6__["HomePageRoutingModule"]
        ],
        declarations: [_home_page__WEBPACK_IMPORTED_MODULE_5__["HomePage"]]
    })
], HomePageModule);



/***/ }),

/***/ "f6od":
/*!*************************************!*\
  !*** ./src/app/home/home.page.scss ***!
  \*************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("#container {\n  text-align: center;\n  padding-left: 20px;\n}\n\n#container strong {\n  font-size: 20px;\n  line-height: 26px;\n}\n\n.error-card .error-text {\n  color: #d0d0d0;\n  font-weight: bold;\n}\n\n.error-card .error-text .error-ip {\n  margin-top: 10px;\n  color: white;\n  font-size: 14px;\n  font-weight: bold;\n}\n\n@keyframes border-pulsate {\n  0% {\n    border-color: aqua;\n  }\n  50% {\n    border-color: rgba(0, 255, 255, 0);\n  }\n  100% {\n    border-color: aqua;\n  }\n}\n\n.col-selected {\n  border: 2px solid cyan;\n  animation: border-pulsate 2s infinite;\n}\n\n#container p {\n  font-size: 16px;\n  line-height: 22px;\n  color: #8c8c8c;\n  margin: 0;\n}\n\n.vertically-align {\n  position: relative;\n  top: 50%;\n  transform: translateY(-60%);\n}\n\n.error-screen {\n  padding: 20px;\n}\n\n.loader-screen {\n  text-align: center;\n  height: 100%;\n  width: 100%;\n  position: relative;\n  margin-top: 50%;\n  transform: translateY(-50%);\n}\n\nion-footer,\n.custom-footer {\n  height: 45px !important;\n  padding: 0px 10px 0px 10px;\n  background: #0e0e0e;\n}\n\n.broken {\n  height: 100%;\n  background: url('broken.jpg');\n  background-size: cover;\n  text-align: center;\n  padding: 100px;\n}\n\n#container a {\n  text-decoration: none;\n}\n\n.app-title {\n  color: white !important;\n  font-size: 16px;\n  margin: 0px;\n  font-weight: bold;\n  width: 80%;\n  white-space: nowrap;\n  overflow: hidden;\n  text-overflow: ellipsis;\n}\n\n.app-description {\n  color: #c1c1c1;\n  font-weight: bold;\n  margin: 0px;\n}\n\n.app-slide-description {\n  width: 90%;\n  padding: 0px 10px 0px 10px;\n  font-size: 14px;\n  white-space: nowrap;\n  overflow: hidden;\n  text-overflow: ellipsis;\n  color: white !important;\n  font-size: 18px !important;\n}\n\nion-content {\n  --ion-background-color: black !important;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy4uLy4uL2hvbWUucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0Usa0JBQUE7RUFDQSxrQkFBQTtBQUNGOztBQUNBO0VBQ0UsZUFBQTtFQUNBLGlCQUFBO0FBRUY7O0FBQ0U7RUFDRSxjQUFBO0VBQ0EsaUJBQUE7QUFFSjs7QUFESTtFQUNFLGdCQUFBO0VBQ0EsWUFBQTtFQUNBLGVBQUE7RUFDQSxpQkFBQTtBQUdOOztBQUNBO0VBQ0U7SUFDRSxrQkFBQTtFQUVGO0VBQUE7SUFDRSxrQ0FBQTtFQUVGO0VBQUE7SUFDRSxrQkFBQTtFQUVGO0FBQ0Y7O0FBQUE7RUFDRSxzQkFBQTtFQUNBLHFDQUFBO0FBRUY7O0FBQUE7RUFDRSxlQUFBO0VBQ0EsaUJBQUE7RUFDQSxjQUFBO0VBQ0EsU0FBQTtBQUdGOztBQURBO0VBQ0Usa0JBQUE7RUFDQSxRQUFBO0VBQ0EsMkJBQUE7QUFJRjs7QUFGQTtFQUNFLGFBQUE7QUFLRjs7QUFIQTtFQUNFLGtCQUFBO0VBQ0EsWUFBQTtFQUNBLFdBQUE7RUFDQSxrQkFBQTtFQUNBLGVBQUE7RUFDQSwyQkFBQTtBQU1GOztBQUpBOztFQUVFLHVCQUFBO0VBQ0EsMEJBQUE7RUFDQSxtQkFBQTtBQU9GOztBQURBO0VBQ0UsWUFBQTtFQUNBLDZCQUFBO0VBQ0Esc0JBQUE7RUFDQSxrQkFBQTtFQUNBLGNBQUE7QUFJRjs7QUFGQTtFQUNFLHFCQUFBO0FBS0Y7O0FBSEE7RUFDRSx1QkFBQTtFQUNBLGVBQUE7RUFDQSxXQUFBO0VBQ0EsaUJBQUE7RUFDQSxVQUFBO0VBQ0EsbUJBQUE7RUFDQSxnQkFBQTtFQUNBLHVCQUFBO0FBTUY7O0FBSkE7RUFDRSxjQUFBO0VBQ0EsaUJBQUE7RUFDQSxXQUFBO0FBT0Y7O0FBTEE7RUFDRSxVQUFBO0VBQ0EsMEJBQUE7RUFDQSxlQUFBO0VBQ0EsbUJBQUE7RUFDQSxnQkFBQTtFQUNBLHVCQUFBO0VBQ0EsdUJBQUE7RUFDQSwwQkFBQTtBQVFGOztBQU5BO0VBQ0Usd0NBQUE7QUFTRiIsImZpbGUiOiJob21lLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIiNjb250YWluZXIge1xuICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gIHBhZGRpbmctbGVmdDogMjBweDtcbn1cbiNjb250YWluZXIgc3Ryb25nIHtcbiAgZm9udC1zaXplOiAyMHB4O1xuICBsaW5lLWhlaWdodDogMjZweDtcbn1cbi5lcnJvci1jYXJkIHtcbiAgLmVycm9yLXRleHQge1xuICAgIGNvbG9yOiAjZDBkMGQwO1xuICAgIGZvbnQtd2VpZ2h0OiBib2xkO1xuICAgIC5lcnJvci1pcCB7XG4gICAgICBtYXJnaW4tdG9wOiAxMHB4O1xuICAgICAgY29sb3I6IHdoaXRlO1xuICAgICAgZm9udC1zaXplOiAxNHB4O1xuICAgICAgZm9udC13ZWlnaHQ6IGJvbGQ7XG4gICAgfVxuICB9XG59XG5Aa2V5ZnJhbWVzIGJvcmRlci1wdWxzYXRlIHtcbiAgMCUge1xuICAgIGJvcmRlci1jb2xvcjogcmdiYSgwLCAyNTUsIDI1NSwgMSk7XG4gIH1cbiAgNTAlIHtcbiAgICBib3JkZXItY29sb3I6IHJnYmEoMCwgMjU1LCAyNTUsIDApO1xuICB9XG4gIDEwMCUge1xuICAgIGJvcmRlci1jb2xvcjogcmdiYSgwLCAyNTUsIDI1NSwgMSk7XG4gIH1cbn1cbi5jb2wtc2VsZWN0ZWQge1xuICBib3JkZXI6IDJweCBzb2xpZCBjeWFuO1xuICBhbmltYXRpb246IGJvcmRlci1wdWxzYXRlIDJzIGluZmluaXRlO1xufVxuI2NvbnRhaW5lciBwIHtcbiAgZm9udC1zaXplOiAxNnB4O1xuICBsaW5lLWhlaWdodDogMjJweDtcbiAgY29sb3I6ICM4YzhjOGM7XG4gIG1hcmdpbjogMDtcbn1cbi52ZXJ0aWNhbGx5LWFsaWduIHtcbiAgcG9zaXRpb246IHJlbGF0aXZlO1xuICB0b3A6IDUwJTtcbiAgdHJhbnNmb3JtOiB0cmFuc2xhdGVZKC02MCUpO1xufVxuLmVycm9yLXNjcmVlbiB7XG4gIHBhZGRpbmc6IDIwcHg7XG59XG4ubG9hZGVyLXNjcmVlbiB7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgaGVpZ2h0OiAxMDAlO1xuICB3aWR0aDogMTAwJTtcbiAgcG9zaXRpb246IHJlbGF0aXZlO1xuICBtYXJnaW4tdG9wOiA1MCU7XG4gIHRyYW5zZm9ybTogdHJhbnNsYXRlWSgtNTAlKTtcbn1cbmlvbi1mb290ZXIsXG4uY3VzdG9tLWZvb3RlciB7XG4gIGhlaWdodDogNDVweCAhaW1wb3J0YW50O1xuICBwYWRkaW5nOiAwcHggMTBweCAwcHggMTBweDtcbiAgYmFja2dyb3VuZDogIzBlMGUwZTtcbn1cbi5jdXN0b20tdG9vbGJhciB7XG4gIC8vYmFja2dyb3VuZDogcmdiKDMwLCAzMCwgMzIpO1xuICAvLyBiYWNrZ3JvdW5kOiBsaW5lYXItZ3JhZGllbnQoMGRlZywgYmxhY2sgMCUsICM0YzQ2NDYgMTAwJSwgIzdiMWUxZSAxMDAlKTtcbn1cbi5icm9rZW4ge1xuICBoZWlnaHQ6IDEwMCU7XG4gIGJhY2tncm91bmQ6IHVybChcIi4uLy4uL2Fzc2V0cy9pbWFnZXMvYnJva2VuLmpwZ1wiKTtcbiAgYmFja2dyb3VuZC1zaXplOiBjb3ZlcjtcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xuICBwYWRkaW5nOiAxMDBweDtcbn1cbiNjb250YWluZXIgYSB7XG4gIHRleHQtZGVjb3JhdGlvbjogbm9uZTtcbn1cbi5hcHAtdGl0bGUge1xuICBjb2xvcjogd2hpdGUgIWltcG9ydGFudDtcbiAgZm9udC1zaXplOiAxNnB4O1xuICBtYXJnaW46IDBweDtcbiAgZm9udC13ZWlnaHQ6IGJvbGQ7XG4gIHdpZHRoOiA4MCU7XG4gIHdoaXRlLXNwYWNlOiBub3dyYXA7XG4gIG92ZXJmbG93OiBoaWRkZW47XG4gIHRleHQtb3ZlcmZsb3c6IGVsbGlwc2lzO1xufVxuLmFwcC1kZXNjcmlwdGlvbiB7XG4gIGNvbG9yOiAjYzFjMWMxO1xuICBmb250LXdlaWdodDogYm9sZDtcbiAgbWFyZ2luOiAwcHg7XG59XG4uYXBwLXNsaWRlLWRlc2NyaXB0aW9uIHtcbiAgd2lkdGg6IDkwJTtcbiAgcGFkZGluZzogMHB4IDEwcHggMHB4IDEwcHg7XG4gIGZvbnQtc2l6ZTogMTRweDtcbiAgd2hpdGUtc3BhY2U6IG5vd3JhcDtcbiAgb3ZlcmZsb3c6IGhpZGRlbjtcbiAgdGV4dC1vdmVyZmxvdzogZWxsaXBzaXM7XG4gIGNvbG9yOiB3aGl0ZSAhaW1wb3J0YW50O1xuICBmb250LXNpemU6IDE4cHggIWltcG9ydGFudDtcbn1cbmlvbi1jb250ZW50IHtcbiAgLS1pb24tYmFja2dyb3VuZC1jb2xvcjogYmxhY2sgIWltcG9ydGFudDtcbn1cbiJdfQ== */");

/***/ }),

/***/ "zpKS":
/*!***********************************!*\
  !*** ./src/app/home/home.page.ts ***!
  \***********************************/
/*! exports provided: HomePage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "HomePage", function() { return HomePage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_home_page_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./home.page.html */ "WcN3");
/* harmony import */ var _home_page_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./home.page.scss */ "f6od");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var _modal_modals_ms_teams_page__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../modal/modals/ms-teams.page */ "qdIs");
/* harmony import */ var _modal_ipconfig_ipconfig_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./../modal/ipconfig/ipconfig.page */ "xG7c");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/common/http */ "tk/3");
/* harmony import */ var _services_api_service__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../services/api.service */ "H+bZ");
/* harmony import */ var _global_constants__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./../global-constants */ "TqJ6");
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/platform-browser */ "jhN1");
/* harmony import */ var _services_cleandata_service__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../services/cleandata.service */ "oEKA");
/* harmony import */ var _services_current_ip_port_service__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ../services/current-ip-port.service */ "kKPw");
/* harmony import */ var _services_currently_viewing_service__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ../services/currently-viewing.service */ "1Aq0");















const httpOptions = {
    headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_7__["HttpHeaders"]({
        'Content-Type': 'application/xml',
        'Authorization': 'jwt-token'
    })
};
let HomePage = class HomePage {
    constructor(menu, currViewCheck, currentIPPORT, cleanData, sanitizer, modalController, httpClient, apiService, globals) {
        this.menu = menu;
        this.currViewCheck = currViewCheck;
        this.currentIPPORT = currentIPPORT;
        this.cleanData = cleanData;
        this.sanitizer = sanitizer;
        this.modalController = modalController;
        this.httpClient = httpClient;
        this.apiService = apiService;
        this.globals = globals;
        this.theRunningApps = [];
        this.theRunningApps2 = [];
        this.appsSingular = [];
        this.appsMultiple = [];
        this.theRunningAppsSorted = [];
        this.currentModal = null;
        this.randTest = [];
        this.dataReturned = [];
    }
    openFirst() {
        this.menu.enable(true, 'first');
        this.menu.open('first');
    }
    isAllowedAppName(appName) {
        return this.globals.APPS_ALLOWED_APPS.includes(appName) == true;
    }
    isAllowedApp(appName) {
        if (this.globals.APPS_ALLOWED_APPS.includes(appName.appName) == true) {
            this.presentModal(appName, 'true', _modal_modals_ms_teams_page__WEBPACK_IMPORTED_MODULE_5__["MsTeamsPage"]);
        }
        else {
            if (appName.appType == 'single') {
                this.currViewCheck.checkCurrentlyViewing(appName, 'single');
            }
            if (appName.appType == 'multiple') {
                this.currViewCheck.checkCurrentlyViewing(appName, 'multiple');
            }
            this.doFocusWindow(appName);
        }
    }
    doPresentIPModal() {
        this.presentModal(null, null, _modal_ipconfig_ipconfig_page__WEBPACK_IMPORTED_MODULE_6__["IpconfigPage"]);
    }
    dismiss() {
        this.modalController.dismiss({
            'dismissed': 'updatedIpPort'
        });
    }
    presentModal(event, trusted, type) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            var options;
            if (type.name == 'MsTeamsPage') {
                options = {
                    component: type,
                    cssClass: 'my-custom-class',
                    componentProps: {
                        'app': event.path
                    }
                };
                this.doFocusWindow(event);
            }
            if (type.name == 'IpconfigPage') {
                options = {
                    component: _modal_ipconfig_ipconfig_page__WEBPACK_IMPORTED_MODULE_6__["IpconfigPage"],
                    cssClass: 'my-custom-class'
                };
            }
            localStorage.setItem('currentAppID', JSON.stringify(event));
            this.globals.CURRENT_MODAL = yield this.modalController.create(options);
            this.globals.CURRENT_MODAL.onDidDismiss().then((dataReturned) => {
                this.menu.close();
                //this.globals.API_DELAY_CALL = true;
                this.currentIPPORT.subscription = this.currentIPPORT.getAsyncData().subscribe(u => (this.currMachine = u));
                //this.cleanData.cleanUpData('LoadData');
                if (dataReturned.data.dismissed == 'leaveTeamsCall' || dataReturned.data.dismissed == 'updatedIpPort') {
                    this.globals.API_DELAY_CALL = true;
                    this.currentIPPORT.subscription = this.currentIPPORT.getAsyncData().subscribe(u => (this.currMachine = u));
                    this.cleanData.cleanUpData('LoadData');
                }
            });
            this.currentModal = this.globals.CURRENT_MODAL;
            return yield this.globals.CURRENT_MODAL.present();
        });
    }
    doFocusWindow(params) {
        this.apiService.doSetWindowFocus(params).subscribe((data) => {
        });
    }
    getRunningProcesses() {
        this.cleanData.cleanUpData('LoadData');
    }
    ngOnInit() {
        this.currentIPPORT.subscription = this.currentIPPORT.getAsyncData().subscribe(u => (this.currMachine = u));
        this.currentIPPORT.subscriptionApiError = this.currentIPPORT.checkIfApiError(this.globals.API_ERROR).subscribe(u => (this.apiError = u));
        this.currentIPPORT.getValue().subscribe((value) => {
            this.apiError = value;
        });
    }
};
HomePage.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["MenuController"] },
    { type: _services_currently_viewing_service__WEBPACK_IMPORTED_MODULE_13__["CurrentlyViewingService"] },
    { type: _services_current_ip_port_service__WEBPACK_IMPORTED_MODULE_12__["CurrentIpPortService"] },
    { type: _services_cleandata_service__WEBPACK_IMPORTED_MODULE_11__["CleandataService"] },
    { type: _angular_platform_browser__WEBPACK_IMPORTED_MODULE_10__["DomSanitizer"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["ModalController"] },
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_7__["HttpClient"] },
    { type: _services_api_service__WEBPACK_IMPORTED_MODULE_8__["ApiService"] },
    { type: _global_constants__WEBPACK_IMPORTED_MODULE_9__["GlobalConstants"] }
];
HomePage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-home',
        template: _raw_loader_home_page_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_home_page_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], HomePage);



/***/ })

}]);
//# sourceMappingURL=home-home-module.js.map